import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  // Иначе при открытии через http://127.0.0.1:3000 (или LAN-IP) Next 16 режет
  // кросс-origin дев-ресурсы и страница остаётся без JS: кнопки не работают.
  allowedDevOrigins: ["localhost", "127.0.0.1"],
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
