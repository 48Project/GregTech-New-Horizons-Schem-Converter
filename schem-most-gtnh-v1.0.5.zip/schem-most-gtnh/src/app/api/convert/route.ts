import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { detectAndParse } from '@/lib/mc/formats'
import { analyzePalette } from '@/lib/mc/mapper'
import { convertSchematic, type Decision } from '@/lib/mc/convert'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData()
    const file = form.get('file') as File | null
    const profileId = (form.get('profileId') as string | null) || null
    const decisionsRaw = form.get('decisions') as string | null
    const outName = ((form.get('name') as string | null) || 'schematic').replace(/[^\w\-а-яА-ЯёЁ ]+/g, '').trim() || 'schematic'
    if (!file) return NextResponse.json({ error: 'Файл схемы не получен' }, { status: 400 })

    let decisions: Record<string, Decision> = {}
    if (decisionsRaw) {
      decisions = JSON.parse(decisionsRaw) as Record<string, Decision>
    }

    const data = new Uint8Array(await file.arrayBuffer())
    const result = detectAndParse(data, file.name || 'schematic.litematic')
    if (!result.ok) {
      return NextResponse.json(
        { error: `Не удалось разобрать файл: ${result.error}` },
        { status: 400 },
      )
    }

    // load profile
    let profile: {
      blocks: Record<string, number>
      byId: Record<number, string>
      mods: Record<string, number>
      blockCount: number
      modCount: number
      levelName: string
    } | null = null
    if (profileId) {
      const p = await db.profile.findUnique({ where: { id: profileId } })
      if (p) {
        const parsed = JSON.parse(p.data) as {
          blocks: Record<string, number>
          mods: Record<string, number>
        }
        const byId: Record<number, string> = {}
        for (const [name, id] of Object.entries(parsed.blocks)) byId[id] = name
        profile = {
          blocks: parsed.blocks,
          byId,
          mods: parsed.mods,
          blockCount: p.blockCount,
          modCount: p.modCount,
          levelName: p.levelName ?? '',
        }
      }
    }

    const analysis = analyzePalette(result.sch, profile)
    const converted = convertSchematic(result.sch, analysis, decisions)

    if (converted.unresolved.length > 0) {
      return NextResponse.json(
        {
          error: `Не назначена замена для блоков: ${converted.unresolved.join(', ')}`,
          unresolved: converted.unresolved,
        },
        { status: 422 },
      )
    }

    const blob = new Blob([new Uint8Array(converted.file)], {
      type: 'application/octet-stream',
    })
    return new NextResponse(blob, {
      headers: {
        'Content-Disposition': `attachment; filename="${encodeURIComponent(outName)}.schematic"`,
        'X-Total-Blocks': String(converted.totalBlocks),
        'X-Materials': encodeURIComponent(
          JSON.stringify(converted.materials.slice(0, 200)),
        ),
      },
    })
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Ошибка конвертации' },
      { status: 500 },
    )
  }
}
