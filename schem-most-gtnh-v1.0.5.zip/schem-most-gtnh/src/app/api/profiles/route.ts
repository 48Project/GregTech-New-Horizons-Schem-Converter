import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { parseLevelDat } from '@/lib/mc/leveldat'

export const runtime = 'nodejs'

export async function GET() {
  const profiles = await db.profile.findMany({
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      name: true,
      levelName: true,
      modCount: true,
      blockCount: true,
      createdAt: true,
    },
  })
  return NextResponse.json({ profiles })
}

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData()
    const file = form.get('file') as File | null
    const name = (form.get('name') as string | null)?.trim() || 'Профиль сборки'
    if (!file) {
      return NextResponse.json({ error: 'Файл level.dat не получен' }, { status: 400 })
    }
    const data = new Uint8Array(await file.arrayBuffer())
    const info = parseLevelDat(data)

    const profile = await db.profile.create({
      data: {
        name,
        levelName: info.levelName,
        modCount: info.modCount,
        blockCount: info.blockCount,
        data: JSON.stringify({
          blocks: info.blocks,
          mods: info.mods,
        }),
      },
    })

    return NextResponse.json({
      profile: {
        id: profile.id,
        name: profile.name,
        levelName: profile.levelName,
        modCount: profile.modCount,
        blockCount: profile.blockCount,
        createdAt: profile.createdAt,
      },
    })
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Не удалось разобрать level.dat' },
      { status: 400 },
    )
  }
}
