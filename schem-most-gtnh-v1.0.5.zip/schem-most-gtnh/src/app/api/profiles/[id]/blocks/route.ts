import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { LevelDatInfo } from '@/lib/mc/leveldat'

export const runtime = 'nodejs'

/** Search blocks of a profile by registry name (for the picker UI). */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const q = (req.nextUrl.searchParams.get('q') ?? '').toLowerCase().trim()
  const profile = await db.profile.findUnique({ where: { id } })
  if (!profile) return NextResponse.json({ error: 'Профиль не найден' }, { status: 404 })

  const parsed = JSON.parse(profile.data) as {
    blocks: Record<string, number>
    mods: Record<string, number>
  }
  const info: LevelDatInfo = {
    levelName: profile.levelName ?? '',
    blocks: parsed.blocks,
    byId: {},
    mods: parsed.mods,
    blockCount: profile.blockCount,
    modCount: profile.modCount,
  }

  const entries = Object.entries(parsed.blocks)
  const filtered = q
    ? entries.filter(([name]) => name.toLowerCase().includes(q)).slice(0, 100)
    : entries.slice(0, 100)
  return NextResponse.json({
    blocks: filtered.map(([name, blockId]) => ({ name, id: blockId })),
    total: entries.length,
  })
}
