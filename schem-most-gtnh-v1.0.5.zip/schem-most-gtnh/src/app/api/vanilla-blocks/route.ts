import { NextRequest, NextResponse } from 'next/server'
import { getVanillaTargets } from '@/lib/mc/legacy-map'

export const runtime = 'nodejs'

/** Search valid vanilla 1.7.10 (id, meta) targets for the block picker. */
export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get('q') ?? '').toLowerCase().trim()
  const all = getVanillaTargets()
  const filtered = q
    ? all.filter(
        (t) =>
          t.name.includes(q) ||
          String(t.id) === q ||
          `${t.id}:${t.meta}` === q,
      )
    : all
  return NextResponse.json({
    blocks: filtered.slice(0, 300),
    total: filtered.length,
  })
}
