import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { detectAndParse, headHex } from '@/lib/mc/formats'
import { analyzePalette } from '@/lib/mc/mapper'
import type { LevelDatInfo } from '@/lib/mc/leveldat'

export const runtime = 'nodejs'

/** Shared helper: load profile info from DB. */
export async function loadProfile(profileId: string | null) {
  if (!profileId) return null
  const profile = await db.profile.findUnique({ where: { id: profileId } })
  if (!profile) return null
  const parsed = JSON.parse(profile.data) as {
    blocks: Record<string, number>
    mods: Record<string, number>
  }
  const byId: Record<number, string> = {}
  for (const [name, id] of Object.entries(parsed.blocks)) byId[id] = name
  const info: LevelDatInfo = {
    levelName: profile.levelName ?? '',
    blocks: parsed.blocks,
    byId,
    mods: parsed.mods,
    blockCount: profile.blockCount,
    modCount: profile.modCount,
  }
  return info
}

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData()
    const file = form.get('file') as File | null
    const profileId = (form.get('profileId') as string | null) || null
    if (!file) {
      console.warn('[analyze] файл не получен: поля формы =', [...form.keys()])
      return NextResponse.json({ error: 'Файл схемы не получен' }, { status: 400 })
    }

    const data = new Uint8Array(await file.arrayBuffer())
    const result = detectAndParse(data, file.name || 'schematic.litematic')
    if (!result.ok) {
      // Полная диагностика — в консоль сервера: по этому логу видно
      // причину отказа даже без доступа к файлу.
      console.warn(
        `[analyze] отказ: файл "${file.name}", ${data.length} байт, начало: [${headHex(data)}]`,
      )
      for (const d of result.details) console.warn(`[analyze]   · ${d}`)
      return NextResponse.json(
        { error: result.error, details: result.details.join(' | ') },
        { status: 400 },
      )
    }
    console.log(
      `[analyze] ok: "${file.name}" → ${result.format}, ${result.sch.width}x${result.sch.height}x${result.sch.length}, палитра ${result.sch.palette.length}`,
    )
    const profile = await loadProfile(profileId)
    const analysis = analyzePalette(result.sch, profile)

    return NextResponse.json({
      format: result.format,
      title: result.sch.title,
      author: result.sch.author,
      width: result.sch.width,
      height: result.sch.height,
      length: result.sch.length,
      regionCount: result.sch.regionCount,
      totalBlocks: result.sch.totalBlocks,
      palette: analysis,
    })
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Ошибка анализа схемы' },
      { status: 500 },
    )
  }
}
