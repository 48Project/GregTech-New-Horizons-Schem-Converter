import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'

export async function GET(req: NextRequest) {
  const profileId = req.nextUrl.searchParams.get('profileId')
  const presets = await db.preset.findMany({
    where: profileId ? { profileId } : undefined,
    orderBy: { createdAt: 'desc' },
    select: { id: true, name: true, profileId: true, mappings: true, createdAt: true },
  })
  return NextResponse.json({ presets })
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      name?: string
      profileId?: string | null
      mappings?: unknown
    }
    const name = body.name?.trim()
    if (!name || !body.mappings) {
      return NextResponse.json({ error: 'Нужны name и mappings' }, { status: 400 })
    }
    const preset = await db.preset.create({
      data: {
        name,
        profileId: body.profileId || null,
        mappings: JSON.stringify(body.mappings),
      },
    })
    return NextResponse.json({ preset })
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Не удалось сохранить пресет' },
      { status: 500 },
    )
  }
}
