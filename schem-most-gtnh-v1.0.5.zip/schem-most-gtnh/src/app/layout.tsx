import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Схем-Мост GTNH — конвертер схем для Minecraft 1.7.10",
  description:
    "Конвертер .litematic и .schem в legacy .schematic для GregTech New Horizons: карта ID из level.dat твоего мира, авто-подбор аналогов для блоков 1.8+, сохранение ротаций, пресеты замен.",
  keywords: ["GTNH", "Minecraft 1.7.10", "litematic", "schematic", "Schematica", "конвертер"],
  icons: {
    icon: "/mascot-avatar.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
