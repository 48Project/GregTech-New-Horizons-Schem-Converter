'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import Image from 'next/image'
import { useToast } from '@/hooks/use-toast'
import { StepProfile } from '@/components/converter/step-profile'
import { StepSchematic } from '@/components/converter/step-schematic'
import { StepMapping } from '@/components/converter/step-mapping'
import { StepExport } from '@/components/converter/step-export'
import type {
  AnalyzeResponse,
  Decision,
  PresetInfo,
  ProfileInfo,
} from '@/lib/converter-types'

const STEPS = ['Профиль', 'Схема', 'Замены', 'Экспорт'] as const

export default function Home() {
  const { toast } = useToast()
  const [step, setStep] = useState(1)
  const [maxStep, setMaxStep] = useState(1)

  const [profiles, setProfiles] = useState<ProfileInfo[]>([])
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null)

  const [file, setFile] = useState<File | null>(null)
  const [analysis, setAnalysis] = useState<AnalyzeResponse | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [decisions, setDecisions] = useState<Record<string, Decision>>({})

  const [presets, setPresets] = useState<PresetInfo[]>([])

  const profileName = useMemo(
    () => profiles.find((p) => p.id === selectedProfileId)?.name ?? null,
    [profiles, selectedProfileId],
  )

  const loadProfiles = useCallback(async () => {
    try {
      const res = await fetch('/api/profiles')
      const json = (await res.json()) as { profiles: ProfileInfo[] }
      setProfiles(json.profiles ?? [])
    } catch {
      /* ignore */
    }
  }, [])

  const loadPresets = useCallback(async () => {
    try {
      const res = await fetch('/api/presets')
      const json = (await res.json()) as { presets: PresetInfo[] }
      setPresets(json.presets ?? [])
    } catch {
      /* ignore */
    }
  }, [])

  useEffect(() => {
    void loadProfiles()
    void loadPresets()
  }, [loadProfiles, loadPresets])

  const analyze = useCallback(
    async (f: File, pid: string | null) => {
      setAnalyzing(true)
      try {
        const form = new FormData()
        form.set('file', f)
        if (pid) form.set('profileId', pid)
        const res = await fetch('/api/analyze', { method: 'POST', body: form })
        const json = await res.json()
        if (!res.ok) {
          // сервер теперь присылает details (размер, первые байты, ошибки парсеров)
          const details: string = typeof json.details === 'string' ? json.details : ''
          const base = json.error ?? 'Не удалось разобрать файл'
          throw new Error(details ? `${base} · ${details.slice(0, 280)}` : base)
        }
        const parsed = json as AnalyzeResponse
        setAnalysis(parsed)
        // keep decisions that still apply to the new palette
        setDecisions((prev) => {
          const keys = new Set(parsed.palette.map((p) => p.key))
          const next: Record<string, Decision> = {}
          for (const [k, v] of Object.entries(prev)) if (keys.has(k)) next[k] = v
          return next
        })
      } catch (e) {
        setAnalysis(null)
        setFile(null)
        toast({
          title: 'Ошибка разбора схемы',
          description: e instanceof Error ? e.message : String(e),
          variant: 'destructive',
        })
      } finally {
        setAnalyzing(false)
      }
    },
    [toast],
  )

  function goStep(n: number) {
    setStep(n)
    setMaxStep((m) => Math.max(m, n))
    if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function handleUploadSchematic(f: File) {
    setFile(f)
    setAnalysis(null)
    setDecisions({})
    void analyze(f, selectedProfileId)
  }

  function handleSelectProfile(id: string | null) {
    setSelectedProfileId(id)
    // re-analyze with the new profile
    if (file) void analyze(file, id)
  }

  function handleLoadPreset(preset: PresetInfo) {
    let applied = 0
    let total = 0
    try {
      const mappings = JSON.parse(preset.mappings) as Record<string, Decision>
      total = Object.keys(mappings).length
      setDecisions((prev) => {
        const next = { ...prev }
        for (const [key, d] of Object.entries(mappings)) {
          if (analysis?.palette.some((p) => p.key === key)) {
            next[key] = d
            applied++
          }
        }
        return next
      })
    } catch {
      toast({ title: 'Пресет повреждён', variant: 'destructive' })
      return
    }
    toast({
      title: `Пресет «${preset.name}»`,
      description: applied > 0 ? `Применено решений: ${applied} из ${total}` : 'Ни один блок пресета не встретился в этой схеме',
    })
  }

  async function handleSavePreset(name: string) {
    const own = Object.fromEntries(
      Object.entries(decisions).filter(([, d]) => d.kind !== 'default'),
    )
    if (Object.keys(own).length === 0) {
      toast({ title: 'Нечего сохранять', description: 'Сначала поменяй хотя бы одну замену' })
      return
    }
    try {
      const res = await fetch('/api/presets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, profileId: selectedProfileId, mappings: own }),
      })
      if (!res.ok) throw new Error('Ошибка сохранения')
      await loadPresets()
      toast({ title: 'Пресет сохранён', description: `${Object.keys(own).length} замен в «${name}»` })
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : String(e), variant: 'destructive' })
    }
  }

  async function handleDeletePreset(id: string) {
    try {
      const res = await fetch(`/api/presets/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Ошибка удаления')
      setPresets((ps) => ps.filter((p) => p.id !== id))
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : String(e), variant: 'destructive' })
    }
  }

  function restart() {
    setFile(null)
    setAnalysis(null)
    setDecisions({})
    setStep(2)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div className="relative min-h-screen overflow-x-clip">
      {/* underwater decor: mascot + light beams + bubbles */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="beam absolute -top-32 left-[8%] h-[70vh] w-40 rotate-12 bg-gradient-to-b from-[#4a7dd4]/14 to-transparent blur-2xl" />
        <div className="beam absolute -top-40 left-[30%] h-[80vh] w-24 rotate-6 bg-gradient-to-b from-[#67b0ff]/10 to-transparent blur-2xl" />
        <div className="beam absolute -top-24 right-[35%] h-[60vh] w-16 -rotate-12 bg-gradient-to-b from-[#67e0ff]/8 to-transparent blur-2xl" />
        <div className="absolute inset-y-0 right-0 hidden w-[46vw] lg:block">
          <Image
            src="/mascot-hero.png"
            alt=""
            fill
            priority
            sizes="46vw"
            className="object-cover object-top opacity-[0.13] [mask-image:linear-gradient(to_left,rgba(0,0,0,0.9),transparent_75%)]"
          />
        </div>
        <div className="bubble b1" />
        <div className="bubble b2" />
        <div className="bubble b3" />
        <div className="bubble b4" />
        <div className="bubble b5" />
      </div>

      <div className="relative z-10 mx-auto max-w-6xl px-4 pb-16 pt-8 sm:px-6">
        <header className="mb-8 flex flex-wrap items-center gap-4">
          <div className="relative">
            <div className="absolute -inset-1 rounded-full bg-[#3b6fd4]/40 blur-md" />
            <Image
              src="/mascot-avatar.png"
              alt="Хранительница глубин"
              width={56}
              height={59}
              priority
              className="relative rounded-full border border-[#3b6fd4]/60"
            />
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-tight text-[#e6ecff] sm:text-2xl">
              Схем-Мост <span className="text-[#7ea6ff]">GTNH</span>
            </h1>
            <p className="text-sm text-[#8fa1c9]">
              .litematic / .schem → .schematic для Minecraft 1.7.10 · с картой ID твоей сборки
            </p>
          </div>
          <div className="ml-auto hidden items-center gap-1.5 text-xs text-[#5a6b99] sm:flex">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-400/80 shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
            Schematica-совместимо · ротации блоков сохраняются
          </div>
        </header>

        {/* stepper */}
        <nav className="mb-6 flex items-center gap-1 sm:gap-2">
          {STEPS.map((label, i) => {
            const n = i + 1
            const active = step === n
            const done = step > n
            const reachable = n <= maxStep
            return (
              <button
                key={label}
                disabled={!reachable}
                onClick={() => reachable && goStep(n)}
                className={`flex flex-1 items-center gap-2 rounded-xl border px-3 py-2 text-left transition-all ${
                  active
                    ? 'border-[#7ea6ff] bg-[#7ea6ff]/10 shadow-[0_0_24px_rgba(126,166,255,0.15)]'
                    : reachable
                      ? 'border-[#233466] bg-[#0b1430]/60 hover:border-[#2a3c74]'
                      : 'border-[#1a2547] bg-[#0b1430]/30 opacity-50'
                }`}
              >
                <span
                  className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${
                    active
                      ? 'bg-[#3b6fd4] text-white'
                      : done
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-[#16234e] text-[#8fa1c9]'
                  }`}
                >
                  {done ? '✓' : n}
                </span>
                <span
                  className={`truncate text-sm ${
                    active ? 'font-medium text-[#e6ecff]' : 'text-[#8fa1c9]'
                  }`}
                >
                  {label}
                </span>
              </button>
            )
          })}
        </nav>

        {step === 1 && (
          <StepProfile
            profiles={profiles}
            selectedId={selectedProfileId}
            onSelect={handleSelectProfile}
            onUploaded={(p) => {
              setProfiles((ps) => [p, ...ps])
              if (file) void analyze(file, p.id)
            }}
            onDeleted={(id) => {
              setProfiles((ps) => ps.filter((p) => p.id !== id))
              setSelectedProfileId((cur) => (cur === id ? null : cur))
              if (file) void analyze(file, null)
            }}
            onNext={() => goStep(2)}
          />
        )}

        {step === 2 && (
          <StepSchematic
            file={file}
            analysis={analysis}
            analyzing={analyzing}
            profileName={profileName}
            onUpload={handleUploadSchematic}
            onClear={() => {
              setFile(null)
              setAnalysis(null)
              setDecisions({})
            }}
            onBack={() => goStep(1)}
            onNext={() => goStep(3)}
          />
        )}

        {step === 3 && analysis && file && (
          <StepMapping
            palette={analysis.palette}
            decisions={decisions}
            profileId={selectedProfileId}
            onDecide={(key, d) => setDecisions((prev) => ({ ...prev, [key]: d }))}
            onResetDecision={(key) =>
              setDecisions((prev) => {
                const next = { ...prev }
                delete next[key]
                return next
              })
            }
            presets={presets}
            onLoadPreset={handleLoadPreset}
            onSavePreset={handleSavePreset}
            onDeletePreset={handleDeletePreset}
            onBack={() => goStep(2)}
            onNext={() => goStep(4)}
          />
        )}

        {step === 4 && analysis && file && (
          <StepExport
            title={analysis.title}
            palette={analysis.palette}
            decisions={decisions}
            file={file}
            profileId={selectedProfileId}
            onBack={() => goStep(3)}
            onRestart={restart}
          />
        )}

        <footer className="mt-10 text-center text-xs text-[#3d4d78]">
          формат .schematic (MCEdit/Schematica) · карта ID из FML ItemData твоего level.dat ·
          таблица соответствий WorldEdit + ручные правила для дверей, кроватей и жидкостей
        </footer>
      </div>
    </div>
  )
}
