/**
 * NBT (Named Binary Tag) reader/writer for Minecraft files.
 * Supports both big-endian (classic: level.dat, .schematic) and
 * little-endian (modern: .litematic, .schem / Sponge) formats,
 * gzip-compressed, zstd-compressed (новые WorldEdit/FAWE, Node 22.15+)
 * or raw.
 */
import * as nodeZlib from 'node:zlib'
const { gzipSync, gunzipSync } = nodeZlib

export const TagType = {
  End: 0,
  Byte: 1,
  Short: 2,
  Int: 3,
  Long: 4,
  Float: 5,
  Double: 6,
  ByteArray: 7,
  String: 8,
  List: 9,
  Compound: 10,
  IntArray: 11,
  LongArray: 12,
} as const
export type TagTypeValue = (typeof TagType)[keyof typeof TagType]

export interface LongArrayValue {
  /** number of elements */
  length: number
  /** unsigned low 32 bits of element i */
  lo(i: number): number
  /** unsigned high 32 bits of element i */
  hi(i: number): number
  /** element i as bigint (signed, as in file) */
  big(i: number): bigint
}

export type NbtTag =
  | { type: 1; value: number }
  | { type: 2; value: number }
  | { type: 3; value: number }
  | { type: 4; value: bigint }
  | { type: 5; value: number }
  | { type: 6; value: number }
  | { type: 7; value: Uint8Array }
  | { type: 8; value: string }
  | { type: 9; itemType: number; value: NbtTag[] }
  | { type: 10; value: Record<string, NbtTag> }
  | { type: 11; value: Int32Array }
  | { type: 12; value: LongArrayValue }

export interface NbtFile {
  /** root tag name (often "" for litematic/schem, "Schematic"/"" otherwise) */
  rootName: string
  root: NbtTag // always a Compound in practice
  /** endianness that was used to read the file */
  littleEndian: boolean
}

/* ------------------------------------------------------------------ */
/* Reader                                                              */
/* ------------------------------------------------------------------ */

class Reader {
  offset = 0
  dv: DataView
  constructor(
    public buf: Uint8Array,
    public le: boolean,
  ) {
    this.dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength)
  }
  private need(n: number) {
    if (this.offset + n > this.buf.length)
      throw new Error(`NBT: unexpected end of data at ${this.offset} (+${n})`)
  }
  byte(): number {
    this.need(1)
    return this.dv.getInt8(this.offset++)
  }
  ubyte(): number {
    this.need(1)
    return this.dv.getUint8(this.offset++)
  }
  short(): number {
    this.need(2)
    const v = this.dv.getInt16(this.offset, this.le)
    this.offset += 2
    return v
  }
  ushort(): number {
    this.need(2)
    const v = this.dv.getUint16(this.offset, this.le)
    this.offset += 2
    return v
  }
  int(): number {
    this.need(4)
    const v = this.dv.getInt32(this.offset, this.le)
    this.offset += 4
    return v
  }
  long(): bigint {
    this.need(8)
    const v = this.dv.getBigInt64(this.offset, this.le)
    this.offset += 8
    return v
  }
  float(): number {
    this.need(4)
    const v = this.dv.getFloat32(this.offset, this.le)
    this.offset += 4
    return v
  }
  double(): number {
    this.need(8)
    const v = this.dv.getFloat64(this.offset, this.le)
    this.offset += 8
    return v
  }
  byteArray(): Uint8Array {
    const len = this.int()
    if (len < 0) throw new Error('NBT: negative byte array length')
    this.need(len)
    const v = this.buf.subarray(this.offset, this.offset + len)
    this.offset += len
    return v
  }
  string(): string {
    const len = this.ushort()
    if (len < 0) throw new Error('NBT: negative string length')
    this.need(len)
    const v = new TextDecoder('utf-8', { fatal: false }).decode(
      this.buf.subarray(this.offset, this.offset + len),
    )
    this.offset += len
    return v
  }
}

function makeLongArray(raw: BigInt64Array): LongArrayValue {
  return {
    length: raw.length,
    lo(i) {
      return Number(raw[i] & 0xffffffffn) >>> 0
    },
    hi(i) {
      return Number((raw[i] >> 32n) & 0xffffffffn) >>> 0
    },
    big(i) {
      return raw[i]
    },
  }
}

function readPayload(r: Reader, type: number): NbtTag {
  switch (type) {
    case TagType.Byte:
      return { type: 1, value: r.byte() }
    case TagType.Short:
      return { type: 2, value: r.short() }
    case TagType.Int:
      return { type: 3, value: r.int() }
    case TagType.Long:
      return { type: 4, value: r.long() }
    case TagType.Float:
      return { type: 5, value: r.float() }
    case TagType.Double:
      return { type: 6, value: r.double() }
    case TagType.ByteArray:
      return { type: 7, value: r.byteArray() }
    case TagType.String:
      return { type: 8, value: r.string() }
    case TagType.List: {
      const itemType = r.ubyte()
      const len = r.int()
      if (len < 0) throw new Error('NBT: negative list length')
      if (itemType === TagType.End) {
        if (len !== 0) throw new Error('NBT: End-typed list with length > 0')
        return { type: 9, itemType: 0, value: [] }
      }
      const items: NbtTag[] = []
      for (let i = 0; i < len; i++) items.push(readPayload(r, itemType))
      return { type: 9, itemType, value: items }
    }
    case TagType.Compound: {
      const value: Record<string, NbtTag> = {}
      for (;;) {
        const t = r.ubyte()
        if (t === TagType.End) break
        if (t > 12) throw new Error(`NBT: unknown tag type ${t}`)
        const name = r.string()
        value[name] = readPayload(r, t)
      }
      return { type: 10, value }
    }
    case TagType.IntArray: {
      const len = r.int()
      if (len < 0) throw new Error('NBT: negative int array length')
      const v = new Int32Array(len)
      for (let i = 0; i < len; i++) v[i] = r.int()
      return { type: 11, value: v }
    }
    case TagType.LongArray: {
      const len = r.int()
      if (len < 0) throw new Error('NBT: negative long array length')
      const v = new BigInt64Array(len)
      for (let i = 0; i < len; i++) v[i] = r.long()
      return { type: 12, value: makeLongArray(v) }
    }
    default:
      throw new Error(`NBT: unknown tag type ${type}`)
  }
}

/** Auto-decompress gzip / zstd if needed */
export function decompressAuto(data: Uint8Array): Uint8Array {
  if (data.length >= 2 && data[0] === 0x1f && data[1] === 0x8b) {
    try {
      return new Uint8Array(gunzipSync(data))
    } catch (e) {
      throw new Error(
        `gzip: не удалось разжать — файл повреждён или скачан не полностью (${
          e instanceof Error ? e.message : String(e)
        })`,
      )
    }
  }
  // zstd: 28 B5 2F FD — так сохраняют .schem некоторые новые WorldEdit/FAWE
  if (
    data.length >= 4 &&
    data[0] === 0x28 && data[1] === 0xb5 && data[2] === 0x2f && data[3] === 0xfd
  ) {
    const zstd = (nodeZlib as unknown as {
      zstdDecompressSync?: (d: Uint8Array) => Buffer
    }).zstdDecompressSync
    if (typeof zstd === 'function') {
      return new Uint8Array(zstd(data))
    }
    throw new Error(
      'zstd: файл сжат zstd, но эта версия Node.js его не умеет (нужна Node 22.15+)',
    )
  }
  return data
}

/**
 * Parse an NBT file. Tries the requested endianness first; on failure,
 * falls back to the other one.
 */
export function parseNbt(data: Uint8Array, preferLittleEndian: boolean): NbtFile {
  let raw: Uint8Array
  try {
    raw = decompressAuto(data)
  } catch (e) {
    // ошибки сжатия одинаковы для обеих попыток endianness — сразу наружу
    throw new Error(`NBT parse failed: ${e instanceof Error ? e.message : String(e)}`)
  }
  const attempts: boolean[] = [preferLittleEndian, !preferLittleEndian]
  let lastErr: unknown = null
  for (const le of attempts) {
    try {
      const r = new Reader(raw, le)
      const t = r.ubyte()
      if (t !== TagType.Compound) throw new Error(`NBT: root tag is ${t}, not Compound`)
      const rootName = r.string()
      const root = readPayload(r, TagType.Compound)
      return { rootName, root, littleEndian: le }
    } catch (e) {
      lastErr = e
    }
  }
  throw new Error(`NBT parse failed: ${lastErr instanceof Error ? lastErr.message : String(lastErr)}`)
}

/**
 * Ключи корня похожи на нормальные идентификаторы?
 *
 * При разборе файла с НЕПРАВИЛЬНОЙ endianness парсер может «успешно»
 * прочитать данные в мусор: длина имени первого ключа читается задом
 * наперёд (например, 0x0010 → 4096), и все последующие ключи сливаются
 * в одно бинарное имя. Так ведут себя big-endian .schem от shulkr.com,
 * прочитанные как little-endian. Единственный надёжный признак такого
 * мусора — непечатаемые символы / аномальная длина в именах ключей корня.
 */
function looksLikeCleanKeys(nbt: NbtFile): boolean {
  if (nbt.root.type !== 10) return false
  const root = (nbt.root as { value: Record<string, NbtTag> }).value
  const keys = Object.keys(root)
  if (!keys.length) return false
  for (const k of keys) {
    if (!k.length || k.length > 128) return false
    for (let i = 0; i < k.length; i++) {
      const c = k.charCodeAt(i)
      if (c < 0x20 || c > 0x7e) return false
    }
  }
  return true
}

/**
 * Parse с проверкой здравости: пробуем предпочтительную endianness,
 * и если её разбор дал мусорные ключи корня — берём разбор в другой
 * endianness. Если оба варианта «мусорные», возвращаем предпочтительный
 * (ошибка formats/парсера выше будет той же, что и раньше).
 */
export function parseNbtSane(data: Uint8Array, preferLittleEndian: boolean): NbtFile {
  let preferred: NbtFile | undefined
  let preferredErr: unknown = null
  try {
    preferred = parseNbt(data, preferLittleEndian)
  } catch (e) {
    preferredErr = e
  }
  if (preferred && looksLikeCleanKeys(preferred)) return preferred
  let other: NbtFile | undefined
  try {
    other = parseNbt(data, !preferLittleEndian)
  } catch {
    // не удалось — ниже вернём то, что есть
  }
  if (other && looksLikeCleanKeys(other)) return other
  if (preferred) return preferred
  throw preferredErr instanceof Error
    ? preferredErr
    : new Error(`NBT parse failed: ${String(preferredErr)}`)
}

/* ------------------------------------------------------------------ */
/* Writer                                                              */
/* ------------------------------------------------------------------ */

class Writer {
  chunks: number[] = []
  writeByte(v: number) {
    this.chunks.push(v & 0xff)
  }
  writeShort(v: number) {
    this.writeByte(v >> 8)
    this.writeByte(v)
  }
  writeShortLE(v: number) {
    this.writeByte(v)
    this.writeByte(v >> 8)
  }
  writeInt(v: number) {
    this.writeByte(v >>> 24)
    this.writeByte(v >>> 16)
    this.writeByte(v >>> 8)
    this.writeByte(v)
  }
  writeIntLE(v: number) {
    this.writeByte(v)
    this.writeByte(v >>> 8)
    this.writeByte(v >>> 16)
    this.writeByte(v >>> 24)
  }
  writeLong(v: bigint, le = false) {
    if (le) {
      for (let i = 0; i < 8; i++) this.writeByte(Number((v >> BigInt(8 * i)) & 0xffn))
    } else {
      for (let i = 7; i >= 0; i--) this.writeByte(Number((v >> BigInt(8 * i)) & 0xffn))
    }
  }
  writeBytes(arr: Uint8Array) {
    for (let i = 0; i < arr.length; i++) this.chunks.push(arr[i])
  }
  writeString(s: string, le = false) {
    const bytes = new TextEncoder().encode(s)
    le ? this.writeShortLE(bytes.length) : this.writeShort(bytes.length)
    this.writeBytes(bytes)
  }
  toUint8(): Uint8Array {
    return new Uint8Array(this.chunks)
  }
}

function writePayload(w: Writer, tag: NbtTag, le: boolean) {
  switch (tag.type) {
    case TagType.Byte:
      w.writeByte(tag.value)
      break
    case TagType.Short:
      le ? w.writeShortLE(tag.value) : w.writeShort(tag.value)
      break
    case TagType.Int:
      le ? w.writeIntLE(tag.value) : w.writeInt(tag.value)
      break
    case TagType.Long:
      w.writeLong(tag.value, le)
      break
    case TagType.Float: {
      const b = new DataView(new ArrayBuffer(4))
      b.setFloat32(0, tag.value, le)
      w.writeBytes(new Uint8Array(b.buffer))
      break
    }
    case TagType.Double: {
      const b = new DataView(new ArrayBuffer(8))
      b.setFloat64(0, tag.value, le)
      w.writeBytes(new Uint8Array(b.buffer))
      break
    }
    case TagType.ByteArray:
      le ? w.writeIntLE(tag.value.length) : w.writeInt(tag.value.length)
      w.writeBytes(tag.value)
      break
    case TagType.String:
      w.writeString(tag.value, le)
      break
    case TagType.List: {
      w.writeByte(tag.itemType ?? 0)
      le ? w.writeIntLE(tag.value.length) : w.writeInt(tag.value.length)
      for (const item of tag.value) writePayload(w, item, le)
      break
    }
    case TagType.Compound: {
      for (const [k, v] of Object.entries(tag.value)) {
        w.writeByte(v.type)
        w.writeString(k, le)
        writePayload(w, v, le)
      }
      w.writeByte(TagType.End)
      break
    }
    case TagType.IntArray:
      le ? w.writeIntLE(tag.value.length) : w.writeInt(tag.value.length)
      for (let i = 0; i < tag.value.length; i++)
        le ? w.writeIntLE(tag.value[i]) : w.writeInt(tag.value[i])
      break
    case TagType.LongArray:
      le ? w.writeIntLE(tag.value.length) : w.writeInt(tag.value.length)
      for (let i = 0; i < tag.value.length; i++) w.writeLong(tag.value.big(i), le)
      break
  }
}

/** Serialize a compound to an NBT file (gzip-compressed) */
export function writeNbt(
  rootName: string,
  root: NbtTag,
  opts: { littleEndian?: boolean; gzip?: boolean } = {},
): Uint8Array {
  const w = new Writer()
  w.writeByte(TagType.Compound)
  w.writeString(rootName)
  writePayload(w, root, !!opts.littleEndian)
  const out = w.toUint8()
  return opts.gzip === false ? out : new Uint8Array(gzipSync(out))
}

/* ------------------------------------------------------------------ */
/* Convenience accessors                                               */
/* ------------------------------------------------------------------ */

export function getCompound(c: Record<string, NbtTag> | undefined, key: string): Record<string, NbtTag> | undefined {
  const t = c?.[key]
  return t && t.type === 10 ? t.value : undefined
}
export function getString(c: Record<string, NbtTag> | undefined, key: string): string | undefined {
  const t = c?.[key]
  return t && t.type === 8 ? t.value : undefined
}
export function getNumber(c: Record<string, NbtTag> | undefined, key: string): number | undefined {
  const t = c?.[key]
  if (!t) return undefined
  if (t.type === 1 || t.type === 2 || t.type === 3) return t.value
  if (t.type === 4) return Number(t.value)
  if (t.type === 5 || t.type === 6) return t.value
  return undefined
}
export function getByteArray(c: Record<string, NbtTag> | undefined, key: string): Uint8Array | undefined {
  const t = c?.[key]
  return t && t.type === 7 ? t.value : undefined
}
export function getList(c: Record<string, NbtTag> | undefined, key: string): NbtTag[] | undefined {
  const t = c?.[key]
  return t && t.type === 9 ? t.value : undefined
}
export function getLongArray(c: Record<string, NbtTag> | undefined, key: string): LongArrayValue | undefined {
  const t = c?.[key]
  return t && t.type === 12 ? t.value : undefined
}
export function getIntArray(c: Record<string, NbtTag> | undefined, key: string): Int32Array | undefined {
  const t = c?.[key]
  return t && t.type === 11 ? t.value : undefined
}
/** helper to build tags concisely */
export const tag = {
  byte: (v: number): NbtTag => ({ type: 1, value: v }),
  short: (v: number): NbtTag => ({ type: 2, value: v }),
  int: (v: number): NbtTag => ({ type: 3, value: v }),
  long: (v: bigint | number): NbtTag => ({ type: 4, value: BigInt(v) }),
  float: (v: number): NbtTag => ({ type: 5, value: v }),
  double: (v: number): NbtTag => ({ type: 6, value: v }),
  byteArray: (v: Uint8Array): NbtTag => ({ type: 7, value: v }),
  string: (v: string): NbtTag => ({ type: 8, value: v }),
  list: (itemType: number, v: NbtTag[]): NbtTag => ({ type: 9, itemType, value: v }),
  compound: (v: Record<string, NbtTag>): NbtTag => ({ type: 10, value: v }),
}
