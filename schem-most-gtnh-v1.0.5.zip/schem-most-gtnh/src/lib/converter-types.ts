/** Shared client-side types for the converter UI. */
import type { Decision } from '@/lib/mc/convert'
import type { PaletteStatus } from '@/lib/mc/mapper'

export type { Decision, PaletteStatus }

export interface ProfileInfo {
  id: string
  name: string
  levelName: string | null
  modCount: number
  blockCount: number
  createdAt: string
}

export interface AnalysisItem {
  key: string
  name: string
  props: Record<string, string>
  mod: string
  count: number
  status: PaletteStatus
  target: { id: number; meta: number } | null
  targetLabel: string | null
  reason: string | null
  legacyId?: { id: number; meta: number }
}

export interface AnalyzeResponse {
  format: 'litematic' | 'sponge' | 'legacy'
  title: string
  author?: string
  width: number
  height: number
  length: number
  regionCount: number
  totalBlocks: number
  palette: AnalysisItem[]
}

export interface PresetInfo {
  id: string
  name: string
  profileId: string | null
  mappings: string // JSON Record<stateKey, Decision>
  createdAt: string
}

export interface MaterialRow {
  id: number
  meta: number
  label: string
  count: number
}

export const STATUS_META: Record<
  PaletteStatus,
  { label: string; cls: string; hint: string }
> = {
  air: {
    label: 'воздух',
    cls: 'bg-slate-500/15 text-slate-300 border-slate-500/30',
    hint: 'пустота — пропускается',
  },
  auto: {
    label: 'точно',
    cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
    hint: 'блок есть в 1.7.10, маппинг по таблице',
  },
  approx: {
    label: 'примерно',
    cls: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
    hint: 'маппинг есть, но часть свойств (форма, вода) упрощена',
  },
  modmeta: {
    label: 'из сборки',
    cls: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
    hint: 'блок есть в твоей сборке; мета 0 — проверь вариант в игре',
  },
  suggest: {
    label: 'замена',
    cls: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
    hint: 'блока нет в 1.7.10 — предложен аналог, подтверди или поменяй',
  },
  manual: {
    label: 'выбери',
    cls: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
    hint: 'неизвестный блок — нужна замена вручную',
  },
  passthrough: {
    label: 'как есть',
    cls: 'bg-teal-500/15 text-teal-300 border-teal-500/30',
    hint: 'числовой ID валиден, проходит без изменений',
  },
  review: {
    label: 'проверь ID',
    cls: 'bg-orange-500/15 text-orange-300 border-orange-500/30',
    hint: 'ID не найден в профиле — вероятно, из чужой сборки',
  },
}
