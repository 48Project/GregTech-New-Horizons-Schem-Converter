import { PrismaClient } from '@prisma/client'
import { existsSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

/**
 * Абсолютный URL SQLite-базы для PrismaClient.
 *
 * Почему не просто env("DATABASE_URL") с относительным путём: на Windows
 * рантайм Prisma разрешает относительные file:-пути иначе, чем CLI
 * (получаем "Error code 14: Unable to open the database file"), а путь
 * с ".." в Windows-сборках движка вообще ненадёжен. Поэтому вычисляем
 * абсолютный путь сами: prisma/custom.db от cwd (dev-режим), с fallback'ами
 * на старое расположение db/ и на уровни выше (standalone-режим).
 */
function resolveDatabaseUrl(): string {
  const fromEnv = process.env.DATABASE_URL
  if (fromEnv?.startsWith('file:')) {
    const p = fromEnv.slice('file:'.length)
    // абсолютный путь (Unix /... или Windows C:\.../C:/...) — берём, только
    // если файл существует: окружение может тянуть устаревший путь
    if ((p.startsWith('/') || p.startsWith('\\') || /^[A-Za-z]:[\\/]/.test(p)) && existsSync(p)) {
      return 'file:' + p.split('\\').join('/')
    }
  }
  const cwd = process.cwd()
  const candidates = [
    join(cwd, 'prisma', 'custom.db'), // dev: <project>/prisma/custom.db
    join(cwd, 'db', 'custom.db'), // старое расположение (совместимость)
    join(cwd, '..', 'prisma', 'custom.db'), // standalone: .next/standalone
    join(cwd, '..', '..', 'prisma', 'custom.db'),
    join(cwd, '..', 'db', 'custom.db'),
  ]
  for (const c of candidates) {
    if (existsSync(c)) return 'file:' + c.split('\\').join('/')
  }
  // ничего не нашли — используем путь по умолчанию (пусть db:push создаст файл)
  const def = join(cwd, 'prisma', 'custom.db')
  mkdirSync(join(cwd, 'prisma'), { recursive: true })
  return 'file:' + def.split('\\').join('/')
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    datasourceUrl: resolveDatabaseUrl(),
    log: ['query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
