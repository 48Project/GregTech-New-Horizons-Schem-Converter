/**
 * Palette analysis: for every block state in the source schematic,
 * decide its 1.7.10 target (auto / suggestion / manual decision).
 */
import { stateKey, type PaletteState, type UnifiedSchematic } from './model'
import { mapState, isValid1710, legacyToModernLabel } from './legacy-map'
import { suggestReplacement } from './suggest'
import { ruLabel } from './ru-labels'
import type { LevelDatInfo } from './leveldat'

export type PaletteStatus =
  | 'air' // minecraft:air — nothing to do
  | 'auto' // mapped exactly by the vanilla table
  | 'approx' // mapped, but some state props were ignored (rotation nuance)
  | 'modmeta' // modded block found in profile (id from map, meta=0 — check variant!)
  | 'suggest' // not in 1.7.10, auto-replacement proposed
  | 'manual' // no idea — user must choose
  | 'passthrough' // legacy source: numeric id passes as-is
  | 'review' // legacy source: id not in profile — probably from another pack

export interface PaletteAnalysisItem {
  key: string
  name: string // base registry name (no props)
  props: Record<string, string>
  mod: string // namespace
  count: number
  status: PaletteStatus
  /** proposed target; null = needs decision */
  target: { id: number; meta: number } | null
  /** human-readable proposed target label */
  targetLabel: string | null
  reason: string | null
  /** for legacy sources: the original numeric id */
  legacyId?: { id: number; meta: number }
}

export function targetLabel(id: number, meta: number): string {
  if (id === 0) return 'воздух'
  const modern = legacyToModernLabel(id, meta)
  return modern ? `${ruLabel(modern)} (${id}:${meta})` : `id ${id}:${meta}`
}

export function analyzePalette(
  sch: UnifiedSchematic,
  profile?: LevelDatInfo | null,
): PaletteAnalysisItem[] {
  const counts = new Map<number, number>()
  for (let i = 0; i < sch.indices.length; i++) {
    const p = sch.indices[i]
    counts.set(p, (counts.get(p) ?? 0) + 1)
  }

  const items: PaletteAnalysisItem[] = []
  for (let p = 0; p < sch.palette.length; p++) {
    const st: PaletteState = sch.palette[p]
    const count = counts.get(p) ?? 0
    if (p !== 0 && count === 0) continue // unused palette entry
    const ns = st.name.includes(':') ? st.name.split(':', 1)[0] : 'minecraft'
    const base = st.name.includes(':') ? st.name.slice(ns.length + 1) : st.name

    const item: PaletteAnalysisItem = {
      key: stateKey(st),
      name: st.name,
      props: st.props,
      mod: ns,
      count,
      status: 'manual',
      target: null,
      targetLabel: null,
      reason: null,
    }

    if (sch.format === 'legacy') {
      const legacy = sch.legacyPalette[p] ?? { id: 0, meta: 0 }
      item.legacyId = legacy
      if (legacy.id === 0) {
        item.status = 'air'
        item.target = { id: 0, meta: 0 }
        item.targetLabel = 'воздух'
      } else if (isValid1710(legacy.id, legacy.meta)) {
        item.status = 'passthrough'
        item.target = { ...legacy }
        item.targetLabel = targetLabel(legacy.id, legacy.meta)
        item.reason = 'ванильный ID 1.7.10, проходит как есть'
      } else if (profile?.byId[legacy.id]) {
        item.status = 'passthrough'
        item.target = { ...legacy }
        item.targetLabel = `${profile.byId[legacy.id]} (${legacy.id}:${legacy.meta})`
        item.reason = 'ID найден в профиле сборки'
      } else {
        item.status = 'review'
        item.target = { ...legacy }
        item.targetLabel = targetLabel(legacy.id, legacy.meta)
        item.reason = profile
          ? 'ID не найден в профиле — вероятно, из чужой сборки. Проверь или замени.'
          : 'Без профиля нельзя проверить модовый ID — загрузи level.dat.'
      }
      items.push(item)
      continue
    }

    // --- modern formats (litematic / sponge) ---
    if (ns !== 'minecraft') {
      // modded block
      const profileId = profile?.blocks[st.name]
      if (profileId !== undefined) {
        item.status = 'modmeta'
        item.target = { id: profileId, meta: 0 }
        item.targetLabel = `${st.name} (${profileId}:0)`
        item.reason = 'блок есть в сборке; мета 0 — проверь вариант блока в игре'
      } else {
        const sug = suggestReplacement(base)
        item.status = sug ? 'suggest' : 'manual'
        item.target = sug ? { id: sug.id, meta: sug.meta } : null
        item.targetLabel = sug ? targetLabel(sug.id, sug.meta) : null
        item.reason = sug
          ? `мода ${ns} нет в сборке: ${sug.reason}`
          : profile
            ? `блока ${st.name} нет в профиле сборки — выбери замену`
            : 'загрузи профиль сборки (level.dat), чтобы искать блок автоматически'
      }
      items.push(item)
      continue
    }

    if (base === 'air' || base === 'cave_air' || base === 'void_air') {
      item.status = 'air'
      item.target = { id: 0, meta: 0 }
      item.targetLabel = 'воздух'
      items.push(item)
      continue
    }

    const mapped = mapState(st.name, st.props)
    if (mapped && isValid1710(mapped.id, mapped.meta)) {
      item.status = mapped.exact ? 'auto' : 'approx'
      item.target = { id: mapped.id, meta: mapped.meta }
      item.targetLabel = targetLabel(mapped.id, mapped.meta)
      item.reason = mapped.exact
        ? 'маппинг по таблице 1.7.10'
        : 'маппинг по таблице; часть свойств упрощена (форма/вода)'
    } else if (mapped) {
      // exists in legacy table but NOT in 1.7.10 (1.8-1.12 block)
      const sug = suggestReplacement(base)
      item.status = sug ? 'suggest' : 'manual'
      item.target = sug ? { id: sug.id, meta: sug.meta } : null
      item.targetLabel = sug ? targetLabel(sug.id, sug.meta) : null
      item.reason = sug ? `блока нет в 1.7.10: ${sug.reason}` : 'блока нет в 1.7.10 — выбери замену'
    } else {
      const sug = suggestReplacement(base)
      item.status = sug ? 'suggest' : 'manual'
      item.target = sug ? { id: sug.id, meta: sug.meta } : null
      item.targetLabel = sug ? targetLabel(sug.id, sug.meta) : null
      item.reason = sug ? `новый блок: ${sug.reason}` : 'неизвестный блок — выбери замену'
    }
    items.push(item)
  }
  return items
}
