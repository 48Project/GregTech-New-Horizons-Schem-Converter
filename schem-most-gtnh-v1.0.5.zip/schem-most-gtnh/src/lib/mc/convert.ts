/**
 * End-to-end conversion: unified schematic + user decisions -> legacy .schematic
 */
import type { UnifiedSchematic } from './model'
import { writeLegacySchematic } from './legacy'
import type { PaletteAnalysisItem } from './mapper'
import { targetLabel as mkLabel } from './mapper'

export type Decision =
  | { kind: 'default' } // use analysis target
  | { kind: 'air' }
  | { kind: 'target'; id: number; meta: number }

export interface MaterialRow {
  id: number
  meta: number
  label: string
  count: number
}

export interface ConvertResult {
  file: Uint8Array
  materials: MaterialRow[]
  /** non-air palette entries without any resolvable target */
  unresolved: string[]
  totalBlocks: number
}

export function convertSchematic(
  sch: UnifiedSchematic,
  analysis: PaletteAnalysisItem[],
  decisions: Record<string, Decision>,
): ConvertResult {
  // resolve target per palette index
  const byKey = new Map(analysis.map((a) => [a.key, a]))
  const targets: { id: number; meta: number }[] = new Array(sch.palette.length)
  const unresolvedSet = new Set<string>()

  const counts = new Map<number, number>()
  for (let i = 0; i < sch.indices.length; i++) {
    const p = sch.indices[i]
    counts.set(p, (counts.get(p) ?? 0) + 1)
  }

  // import { stateKey } inline to avoid cycle
  const keyOf = (p: number) => {
    const st = sch.palette[p]
    const keys = Object.keys(st.props).sort()
    return keys.length
      ? `${st.name}[${keys.map((k) => `${k}=${st.props[k]}`).join(',')}]`
      : st.name
  }

  for (let p = 0; p < sch.palette.length; p++) {
    const used = counts.get(p) ?? 0
    const key = keyOf(p)
    const item = byKey.get(key)
    const st = sch.palette[p]
    const isAirSource =
      st.name === 'minecraft:air' ||
      st.name === 'minecraft:cave_air' ||
      st.name === 'minecraft:void_air'

    const decision = decisions[key] ?? { kind: 'default' }
    let resolved: { id: number; meta: number } | null = null
    if (decision.kind === 'air') {
      resolved = { id: 0, meta: 0 }
    } else if (decision.kind === 'target') {
      resolved = { id: decision.id, meta: decision.meta }
    } else {
      resolved = item?.target ?? null
    }

    if (!resolved && isAirSource) resolved = { id: 0, meta: 0 }

    if (!resolved) {
      if (used > 0) unresolvedSet.add(key)
      resolved = { id: 0, meta: 0 }
    }
    targets[p] = resolved
  }

  // material stats
  const matCounts = new Map<string, MaterialRow>()
  for (const [p, used] of counts) {
    if (used === 0) continue
    const t = targets[p]
    if (t.id === 0) continue
    const k = `${t.id}:${t.meta}`
    const existing = matCounts.get(k)
    if (existing) {
      existing.count += used
    } else {
      // prefer the analysis label (knows modded names from the profile)
      const aItem = byKey.get(keyOf(p))
      const label =
        aItem && aItem.target?.id === t.id && aItem.target?.meta === t.meta && aItem.targetLabel
          ? aItem.targetLabel
          : mkLabel(t.id, t.meta)
      matCounts.set(k, { id: t.id, meta: t.meta, label, count: used })
    }
  }
  const materials = [...matCounts.values()].sort((a, b) => b.count - a.count)

  const file = writeLegacySchematic(sch, targets)
  let totalBlocks = 0
  for (const m of materials) totalBlocks += m.count

  return { file, materials, unresolved: [...unresolvedSet], totalBlocks }
}
