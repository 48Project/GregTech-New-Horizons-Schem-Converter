/**
 * level.dat (Forge 1.7.10 world save) FML ID-map extractor.
 *
 * Verified against real GTNH level.dat + Forge 1.7.10 sources
 * (FMLContainer.java + GameData.java):
 * root -> FML -> ItemData: TAG_List of TAG_Compound {K: String, V: Int}
 * (в реальных файлах FML лежит в КОРНЕ, рядом с Data; на всякий случай
 * поддерживаем и устаревший вариант Data -> FML)
 * where K = discriminator + registry name:
 *   '\u0001' + "modid:blockname"  -> BLOCK numeric id in V
 *   '\u0002' + "modid:itemname"   -> ITEM numeric id in V
 */
import {
  parseNbtSane,
  getCompound,
  getNumber,
  getString,
  getList,
  type NbtTag,
} from '@/lib/nbt'

export interface LevelDatInfo {
  levelName: string
  /** "modid:name" -> numeric block id */
  blocks: Record<string, number>
  /** numeric block id -> "modid:name" */
  byId: Record<number, string>
  /** modid -> number of blocks */
  mods: Record<string, number>
  blockCount: number
  modCount: number
}

export function parseLevelDat(data: Uint8Array): LevelDatInfo {
  // level.dat — big-endian; parseNbtSane отсекает мусорный разбор
  const nbt = parseNbtSane(data, false)
  const root = (nbt.root as { type: 10; value: Record<string, NbtTag> }).value
  const dataTag = getCompound(root, 'Data')
  if (!dataTag) throw new Error('level.dat: no Data compound (это точно level.dat?)')
  const levelName = getString(dataTag, 'LevelName') ?? 'unknown'

  // В реальных level.dat Forge 1.7.10 FML лежит в корне (рядом с Data).
  // Вариант Data -> FML оставлен как fallback.
  const fml = getCompound(root, 'FML') ?? getCompound(dataTag, 'FML')
  const itemData = fml && getList(fml, 'ItemData')
  if (!itemData) {
    throw new Error(
      'level.dat: не найдена FML-карта ItemData. Убедись, что это файл мира из Forge 1.7.10 (GTNH), а не из ванилы или новой версии.',
    )
  }

  const blocks: Record<string, number> = {}
  const byId: Record<number, string> = {}
  const mods: Record<string, number> = {}
  let blockCount = 0

  for (const entry of itemData) {
    if (entry.type !== 10) continue
    const k = getString(entry.value, 'K')
    const v = getNumber(entry.value, 'V')
    if (!k || v === undefined) continue
    if (!k.startsWith('\u0001')) continue // blocks only
    const name = k.slice(1)
    const mod = name.includes(':') ? name.split(':', 1)[0] : 'minecraft'
    blocks[name] = v
    byId[v] = name
    mods[mod] = (mods[mod] ?? 0) + 1
    blockCount++
  }

  if (blockCount === 0) {
    throw new Error('level.dat: FML ItemData не содержит блоков')
  }

  return {
    levelName,
    blocks,
    byId,
    mods,
    blockCount,
    modCount: Object.keys(mods).length,
  }
}
