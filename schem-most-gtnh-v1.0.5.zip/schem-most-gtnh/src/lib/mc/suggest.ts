/**
 * Suggestion engine: proposes a 1.7.10 replacement for blocks that
 * physically don't exist there (1.8+ vanilla or unknown modded blocks).
 * Users confirm or override every suggestion in the UI.
 */

export const DYE_COLORS = [
  'white', 'orange', 'magenta', 'light_blue', 'yellow', 'lime', 'pink',
  'gray', 'light_gray', 'cyan', 'purple', 'blue', 'brown', 'green',
  'red', 'black',
] as const

export interface Suggestion {
  id: number
  meta: number
  reason: string
}

const COLOR_REASON: Record<string, number> = {
  tube: 11, brain: 6, bubble: 10, fire: 14, horn: 4,
}

/** base name (no namespace) -> replacement; 'AIR' means suggest air */
const CURATED: Record<string, string | [number, number] | 'AIR'> = {
  // stone family (1.8)
  granite: [1, 0], polished_granite: [1, 0], diorite: [1, 0],
  polished_diorite: [1, 0], andesite: [4, 0], polished_andesite: [1, 0],
  coarse_dirt: [3, 0],
  smooth_red_sandstone: [24, 2], red_sandstone: [24, 0],
  // deepslate / 1.17-1.19
  deepslate: [1, 0], cobbled_deepslate: [4, 0], chiseled_deepslate: [1, 0],
  polished_deepslate: [1, 0], deepslate_bricks: [98, 0], deepslate_tiles: [98, 0],
  calcite: [1, 0], tuff: [1, 0], dripstone_block: [1, 0], pointed_dripstone: 'AIR',
  reinforced_deepslate: [49, 0], sculk: [49, 0], sculk_catalyst: [49, 0],
  sculk_vein: 'AIR', sculk_shrieker: [49, 0],
  // blackstone / basalt (1.16)
  blackstone: [49, 0], polished_blackstone: [49, 0],
  polished_blackstone_bricks: [112, 0], chiseled_polished_blackstone: [112, 0],
  gilded_blackstone: [112, 0], basalt: [49, 0], polished_basalt: [49, 0],
  smooth_basalt: [1, 0], soul_soil: [88, 0], soul_fire: [51, 0],
  // copper (1.17)
  copper_block: [41, 0], cut_copper: [41, 0], exposed_copper: [41, 0],
  exposed_cut_copper: [41, 0], weathered_copper: [41, 0],
  weathered_cut_copper: [41, 0], oxidized_copper: [41, 0],
  oxidized_cut_copper: [41, 0], waxed_copper_block: [41, 0],
  // amethyst (1.17)
  amethyst_block: [57, 0], budding_amethyst: 'AIR', amethyst_cluster: 'AIR',
  small_amethyst_bud: 'AIR', medium_amethyst_bud: 'AIR', large_amethyst_bud: 'AIR',
  // sea (1.8/1.13)
  sea_lantern: [89, 0], prismarine: [98, 0], prismarine_bricks: [98, 0],
  dark_prismarine: [98, 1], slime_block: [19, 0], iron_trapdoor: [96, 0],
  dried_kelp_block: [35, 13], sea_pickle: 'AIR', kelp: 'AIR', kelp_plant: 'AIR',
  seagrass: 'AIR', turtle_egg: 'AIR', sniffer_egg: 'AIR', frogspawn: 'AIR',
  conduit: [57, 0], heart_of_the_sea: [57, 0],
  // nether (1.16)
  crimson_nylium: [87, 0], warped_nylium: [35, 3],
  nether_gold_ore: [14, 0], ancient_debris: 'AIR', netherite_block: [42, 0],
  shroomlight: [89, 0], twisting_vines: 'AIR', weeping_vines: 'AIR',
  nether_sprouts: 'AIR', crimson_roots: 'AIR', warped_roots: 'AIR',
  crimson_fungus: 'AIR', warped_fungus: 'AIR', soul_lantern: [50, 5],
  soul_torch: [50, 5], soul_campfire: [50, 5], respawn_anchor: [49, 0],
  crying_obsidian: [49, 0], lodestone: [41, 0],
  quartz_bricks: [155, 0],
  // end (1.9)
  end_rod: [50, 5], chorus_plant: 'AIR', chorus_flower: 'AIR',
  purpur_block: [155, 0], purpur_pillar: [155, 2], end_stone_bricks: [121, 0],
  purpur_double_slab: [155, 0],
  // 1.10
  magma_block: [112, 0], nether_wart_block: [35, 14], red_nether_brick: [112, 0],
  bone_block: [155, 0],
  // 1.11
  observer: [41, 0], shulker_box: [54, 0],
  // functional (1.14+)
  barrel: [54, 0], smoker: [61, 2], blast_furnace: [61, 2], loom: [47, 0],
  cartography_table: [47, 0], fletching_table: [47, 0], smithing_table: [47, 0],
  lectern: [47, 0], stonecutter: [58, 0], grindstone: [58, 0],
  composter: [58, 0], scaffolding: [85, 0], bell: [41, 0],
  campfire: [50, 5], lantern: [50, 5], chain: [101, 0], lightning_rod: [101, 0],
  honey_block: [42, 0], honeycomb_block: [42, 0], beehive: [47, 0],
  bee_nest: [47, 0], sweet_berry_bush: 'AIR', target: [41, 0],
  // plants & misc (1.16-1.20)
  moss_block: [2, 0], moss_carpet: [171, 13], azalea: [18, 4],
  flowering_azalea: [18, 4], big_dripleaf: [18, 4], small_dripleaf: [18, 4],
  spore_blossom: 'AIR', glow_lichen: 'AIR', hanging_roots: 'AIR',
  cave_vines: 'AIR', cave_vines_plant: 'AIR', mangrove_roots: [17, 0],
  muddy_mangrove_roots: [17, 0], mud: [3, 0], packed_mud: [45, 0],
  mud_bricks: [45, 0], decorated_pot: [45, 0], suspicious_sand: [12, 0],
  suspicious_gravel: [13, 0], ochre_froglight: [89, 0],
  verdant_froglight: [89, 0], pearlescent_froglight: [89, 0],
  cherry_leaves: [18, 4], cherry_log: [17, 0], cherry_planks: [5, 0],
  cherry_wood: [17, 12], mangrove_leaves: [18, 4], mangrove_log: [17, 0],
  mangrove_planks: [5, 0], bamboo_block: [5, 0], bamboo_mosaic: [5, 0],
  bamboo_planks: [5, 0], crimson_planks: [5, 0], warped_planks: [5, 0],
  crimson_stem: [17, 0], warped_stem: [17, 0], crimson_hyphae: [17, 12],
  warped_hyphae: [17, 12], bamboo_mosaic_slab: [126, 0],
  // misc
  grass_path: [3, 0], dirt_path: [3, 0], tinted_glass: [20, 0],
  cobweb_alias: [30, 0],
  bubble_column: [9, 0], // 1.13 water mechanic -> plain water in 1.7.10
}

function colorMeta(name: string): number | null {
  // two-word colors first so "light_blue" is not read as "light"
  const colors = ['light_blue', 'light_gray', ...DYE_COLORS.filter((c) => c !== 'light_blue' && c !== 'light_gray')]
  for (const c of colors) {
    if (name.startsWith(`${c}_`) || name === c) {
      return (DYE_COLORS as readonly string[]).indexOf(c)
    }
  }
  return null
}

/**
 * Suggest a 1.7.10 replacement for a block that is missing there.
 * @param name modern name WITHOUT the minecraft: namespace
 */
export function suggestReplacement(name: string): Suggestion | null {
  // 0. direct curated hit
  const curated = CURATED[name]
  if (curated === 'AIR') return { id: 0, meta: 0, reason: 'нет в 1.7.10 — воздух' }
  if (Array.isArray(curated)) {
    return { id: curated[0], meta: curated[1], reason: 'аналог из ваниллы 1.7.10' }
  }

  // 1. colored families ("white_concrete", "magenta_glazed_terracotta", ...)
  const c = colorMeta(name)
  if (c !== null) {
    if (/_concrete_powder$/.test(name) || name === 'concrete_powder') return { id: 159, meta: c, reason: 'бетонной пыли нет — крашеная глина' }
    if (/_concrete$/.test(name) || name === 'concrete') return { id: 159, meta: c, reason: 'бетона нет в 1.7.10 — крашеная глина' }
    if (/_glazed_terracotta$/.test(name)) return { id: 159, meta: c, reason: 'глазурованной керамики нет — крашеная глина' }
    if (/_candle$/.test(name)) return { id: 50, meta: 5, reason: 'свечей нет — факел' }
    if (/_shulker_box$/.test(name)) return { id: 54, meta: 0, reason: 'шалкеров нет — сундук' }
    if (/_bed$/.test(name)) return { id: 26, meta: 0, reason: 'кровать 1.7.10 (без цвета)' }
    if (/_terracotta$/.test(name)) return { id: 159, meta: c, reason: 'крашеная глина' }
  }
  // 1b. coral colors
  for (const [k, meta] of Object.entries(COLOR_REASON)) {
    if (name.startsWith(`${k}_coral`)) {
      return { id: 159, meta, reason: 'кораллов нет в 1.7.10 — цветная глина' }
    }
  }
  if (name.includes('coral')) {
    return { id: 159, meta: 9, reason: 'кораллов нет в 1.7.10 — цветная глина' }
  }

  // 2. keyword fallbacks by suffix
  if (name.endsWith('_stairs')) return { id: 53, meta: 0, reason: 'ступени из дуба (аналог)' }
  if (name.endsWith('_slab')) return { id: 44, meta: 0, reason: 'каменная плита (аналог)' }
  if (name.endsWith('_wall')) return { id: 139, meta: 0, reason: 'булыжная стена (аналог)' }
  if (name.endsWith('_fence_gate')) return { id: 107, meta: 0, reason: 'калитка (аналог)' }
  if (name.endsWith('_fence')) return { id: 85, meta: 0, reason: 'дубовый забор (аналог)' }
  if (name.endsWith('_trapdoor')) return { id: 96, meta: 0, reason: 'деревянный люк (аналог)' }
  if (name.endsWith('_door')) return { id: 64, meta: 0, reason: 'дубовая дверь (аналог)' }
  if (name.endsWith('_button')) return { id: 72, meta: 5, reason: 'деревянная кнопка (аналог)' }
  if (name.endsWith('_pressure_plate')) return { id: 70, meta: 0, reason: 'плита давления (аналог)' }
  if (name.endsWith('_wall_sign')) return { id: 68, meta: 2, reason: 'табличка на стене (аналог)' }
  if (name.endsWith('_sign')) return { id: 63, meta: 0, reason: 'табличка (аналог)' }
  if (name.endsWith('_carpet')) return { id: 171, meta: 0, reason: 'ковёр (аналог)' }
  if (name.endsWith('_wood') || name.endsWith('_hyphae')) return { id: 17, meta: 12, reason: 'древесный блок (аналог)' }
  if (name.endsWith('_log') || name.endsWith('_stem')) return { id: 17, meta: 0, reason: 'дубовое бревно (аналог)' }
  if (name.endsWith('_leaves')) return { id: 18, meta: 4, reason: 'дубовая листва (аналог)' }
  if (name.endsWith('_planks')) return { id: 5, meta: 0, reason: 'дубовые доски (аналог)' }
  if (name.endsWith('_glass_pane')) return { id: 102, meta: 0, reason: 'стеклянная панель (аналог)' }
  if (name.endsWith('_stained_glass_pane')) return { id: 160, meta: 0, reason: 'цветная стеклянная панель' }
  if (name.endsWith('_stained_glass')) return { id: 95, meta: 0, reason: 'цветное стекло' }
  if (name.endsWith('_glass')) return { id: 20, meta: 0, reason: 'стекло' }
  if (name.endsWith('_wool')) return { id: 35, meta: 0, reason: 'белая шерсть' }
  if (name.endsWith('_terracotta')) return { id: 159, meta: 0, reason: 'крашеная глина' }
  if (name.includes('brick')) return { id: 45, meta: 0, reason: 'кирпичи (аналог)' }
  if (name.includes('copper')) return { id: 41, meta: 0, reason: 'медных блоков нет — золото' }
  if (name.includes('amethyst')) return { id: 57, meta: 0, reason: 'аметиста нет — алмазный блок' }
  if (name.includes('deepslate')) return { id: 1, meta: 0, reason: 'глубинного сланца нет — камень' }
  if (name.includes('blackstone')) return { id: 49, meta: 0, reason: 'чернита нет — обсидиан' }
  if (name.includes('basalt')) return { id: 49, meta: 0, reason: 'базальта нет — обсидиан' }
  if (name.includes('candle')) return { id: 50, meta: 5, reason: 'свечей нет — факел' }
  if (name.includes('_ore') || name.endsWith('ore')) {
    return { id: 15, meta: 0, reason: 'руды новой версии — железная руда' }
  }
  if (name.includes('torch')) return { id: 50, meta: 5, reason: 'факел' }
  if (name.includes('lamp') || name.includes('light')) return { id: 89, meta: 0, reason: 'светящийся камень' }
  if (name.includes('mushroom')) return { id: 100, meta: 0, reason: 'гриб (аналог)' }

  return null
}
