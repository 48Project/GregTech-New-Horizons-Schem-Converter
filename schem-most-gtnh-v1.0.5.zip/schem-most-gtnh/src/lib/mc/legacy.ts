/**
 * Legacy MCEdit .schematic reader/writer (the format Schematica on 1.7.10 eats).
 * - big-endian NBT, gzipped
 * - root tag "Schematic": Width/Height/Length (shorts), Materials "Alpha",
 *   Blocks (byte array, low byte of id), AddBlocks (optional nibble array with
 *   high bytes: entry i holds blocks 2i (low nibble) and 2i+1 (high nibble)),
 *   Data (byte array with metadata)
 * - cell order: (y * Length + z) * Width + x
 */
import {
  parseNbtSane,
  writeNbt,
  getCompound,
  getNumber,
  getByteArray,
  tag,
  type NbtTag,
} from '@/lib/nbt'
import { AIR_STATE, type PaletteState, type UnifiedSchematic } from './model'

export function parseLegacySchematic(data: Uint8Array): UnifiedSchematic {
  // legacy .schematic — big-endian; parseNbtSane отсекает «успешный»
  // мусорный разбор в неправильной endianness
  const nbt = parseNbtSane(data, false)
  const root = (nbt.root as { type: 10; value: Record<string, NbtTag> }).value
  // some writers use root name "Schematic" (compound child), others put data at root level
  const schematic = getCompound(root, 'Schematic') ?? root
  const width = getNumber(schematic, 'Width') ?? 0
  const height = getNumber(schematic, 'Height') ?? 0
  const length = getNumber(schematic, 'Length') ?? 0
  const blocks = getByteArray(schematic, 'Blocks')
  const blockData = getByteArray(schematic, 'Data')
  if (width <= 0 || height <= 0 || length <= 0 || !blocks) {
    throw new Error('schematic: bad legacy file')
  }
  const volume = width * height * length
  if (blocks.length !== volume) {
    throw new Error(
      `schematic: Blocks length ${blocks.length} != volume ${volume}`,
    )
  }
  const addBlocks = getByteArray(schematic, 'AddBlocks')
  const add = getByteArray(schematic, 'Add') // rare variant
  const extra = addBlocks ?? add

  const idToPalette = new Map<string, number>()
  const palette: PaletteState[] = [AIR_STATE]
  const legacyPalette: { id: number; meta: number }[] = [{ id: 0, meta: 0 }]
  const indices = new Uint32Array(volume)
  let totalBlocks = 0

  for (let i = 0; i < volume; i++) {
    let id = blocks[i] & 0xff
    if (extra && extra.length > (i >> 1)) {
      const nib = extra[i >> 1]
      const high = i & 1 ? (nib >> 4) & 0xf : nib & 0xf
      id |= high << 8
    }
    const meta = blockData ? blockData[i] & 0x0f : 0
    if (id === 0) {
      indices[i] = 0
      continue
    }
    const key = `${id}:${meta}`
    let p = idToPalette.get(key)
    if (p === undefined) {
      palette.push({ name: `legacy:${id}`, props: { meta: String(meta) } })
      legacyPalette.push({ id, meta })
      p = palette.length - 1
      idToPalette.set(key, p)
    }
    indices[i] = p
    totalBlocks++
  }

  return {
    format: 'legacy',
    title: 'Без названия',
    width,
    height,
    length,
    palette,
    indices,
    legacyPalette,
    totalBlocks,
    regionCount: 1,
  }
}

/**
 * Writes a legacy .schematic from per-palette-index numeric targets.
 * `targets[i]` = { id, meta } for palette index i.
 */
export function writeLegacySchematic(
  sch: UnifiedSchematic,
  targets: { id: number; meta: number }[],
): Uint8Array {
  const { width, height, length } = sch
  const volume = width * height * length
  if (width > 32767 || height > 32767 || length > 32767) {
    throw new Error('schematic: dimensions too large for legacy format')
  }
  const blocks = new Uint8Array(volume)
  const data = new Uint8Array(volume)
  let needsAdd = false
  for (let i = 0; i < volume; i++) {
    const t = targets[sch.indices[i]] ?? { id: 0, meta: 0 }
    blocks[i] = t.id & 0xff
    data[i] = t.meta & 0x0f
    if (t.id > 255) needsAdd = true
  }
  let addBlocks: Uint8Array | undefined
  if (needsAdd) {
    addBlocks = new Uint8Array(Math.ceil(volume / 2))
    for (let i = 0; i < volume; i++) {
      const t = targets[sch.indices[i]] ?? { id: 0, meta: 0 }
      const high = (t.id >> 8) & 0xf
      const byteIndex = i >> 1
      if (i & 1) {
        addBlocks[byteIndex] |= high << 4
      } else {
        addBlocks[byteIndex] |= high
      }
    }
  }

  const schematic: Record<string, NbtTag> = {
    Materials: tag.string('Alpha'),
    Width: tag.short(width),
    Height: tag.short(height),
    Length: tag.short(length),
    Blocks: tag.byteArray(blocks),
    Data: tag.byteArray(data),
    // empty lists with explicit compound type (valid NBT)
    TileEntities: tag.list(10, []),
    Entities: tag.list(10, []),
  }
  if (addBlocks) schematic.AddBlocks = tag.byteArray(addBlocks)

  return writeNbt('Schematic', tag.compound(schematic), {
    littleEndian: false,
    gzip: true,
  })
}
