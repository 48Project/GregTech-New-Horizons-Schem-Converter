/**
 * Format detection + single entry point for schematic parsing.
 *
 * Порядок работы:
 * 1. Сниффинг контейнера: ZIP / gzip / zstd / raw — чтобы дать
 *    человеческую ошибку до всякого парсинга (ZIP — самый частый случай).
 * 2. Один дешёвый NBT-парс и смотрим на ключи корня:
 *    Regions → litematic, Palette → sponge, Blocks → legacy,
 *    size+palette+blocks → structure block .nbt, format_version → Bedrock.
 * 3. Fallback: перебор всех трёх парсеров (по расширению файла).
 *
 * Любая ошибка возвращает { error } — короткое объяснение по-русски,
 * и { details } — технические подробности (имя, размер, первые байты,
 * ошибки каждого парсера) для лога сервера.
 */
import { parseNbt, parseNbtSane, type NbtTag } from '@/lib/nbt'
import type { UnifiedSchematic } from './model'
import { parseLitematic } from './litematic'
import { parseSponge } from './sponge'
import { parseLegacySchematic } from './legacy'

export type DetectResult =
  | { ok: true; format: 'litematic' | 'sponge' | 'legacy'; sch: UnifiedSchematic }
  | { ok: false; error: string; details: string[] }

/** первые n байт файла в hex — для диагностики в логе/тосте */
export function headHex(data: Uint8Array, n = 16): string {
  return Array.from(data.slice(0, n))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join(' ')
}

function isZip(data: Uint8Array): boolean {
  return (
    data.length >= 4 &&
    data[0] === 0x50 && // P
    data[1] === 0x4b && // K
    (data[2] === 0x03 || data[2] === 0x05 || data[2] === 0x07)
  )
}

/** похоже ли начало файла на текст (utf-8/ascii) — подсказка «это не NBT» */
function looksLikeText(data: Uint8Array): boolean {
  const n = Math.min(data.length, 64)
  let printable = 0
  for (let i = 0; i < n; i++) {
    const b = data[i]
    if (b === 9 || b === 10 || b === 13 || (b >= 32 && b < 127)) printable++
  }
  return n > 0 && printable / n > 0.85
}

interface RootInfo {
  keys: Set<string>
  /** вложенный compound "Schematic" (sponge v3 / legacy), если есть */
  childKeys: Set<string> | null
  /** sponge v3: блоки лежат в compound "Blocks" (в корне или под "Schematic"),
   *  а не в byteArray, как у legacy .schematic */
  blocksCompound: boolean
}

function inspectRoot(data: Uint8Array): RootInfo | null {
  try {
    // parseNbtSane: big-endian .schem (shulkr.com) при LE-разборе «успешно»
    // превращается в мусор — выбираем разбор с чистыми ключами корня
    const nbt = parseNbtSane(data, true)
    const root = (nbt.root as { type: 10; value: Record<string, NbtTag> }).value
    const keys = new Set(Object.keys(root))
    const child = root['Schematic']
    const childCompound = child && child.type === 10 ? child.value : null
    const childKeys = childCompound ? new Set(Object.keys(childCompound)) : null
    const blocksCompound =
      root['Blocks']?.type === 10 ||
      (childCompound ? childCompound['Blocks']?.type === 10 : false)
    return { keys, childKeys, blocksCompound }
  } catch {
    return null
  }
}

function describe(name: string, data: Uint8Array, extra: string[]): string[] {
  return [`файл "${name}", ${data.length} байт, начало: ${headHex(data)}`, ...extra]
}

export function detectAndParse(data: Uint8Array, filename: string): DetectResult {
  const name = filename.toLowerCase()

  if (!data.length) {
    return {
      ok: false,
      error: 'Файл пустой (0 байт) — похоже, схема не скачалась до конца.',
      details: describe(name, data, []),
    }
  }

  // 1) ZIP-архив: схемы с сайтов (Planet Minecraft и т.п.) часто лежат в архивах.
  if (isZip(data)) {
    return {
      ok: false,
      error:
        'Это ZIP-архив, а не файл схемы. Распакуй архив и загрузи сам файл .litematic / .schem / .schematic, который лежит внутри.',
      details: describe(name, data, ['сигнатура PK — ZIP-архив']),
    }
  }

  // 2) Смотрим на структуру NBT, если файл вообще NBT.
  const root = inspectRoot(data)

  if (!root) {
    // NBT не парсится даже с fallback по endianness.
    // Если это битый gzip/zstd — говорим об этом прямо.
    if (data[0] === 0x1f && data[1] === 0x8b) {
      try {
        parseNbt(data, true)
      } catch (e) {
        const m = e instanceof Error ? e.message : String(e)
        if (m.includes('gzip:')) {
          return {
            ok: false,
            error: `Файл повреждён или скачан не полностью: ${m.replace('NBT parse failed: ', '')}.`,
            details: describe(name, data, [m]),
          }
        }
      }
    }
    const hint = looksLikeText(data)
      ? 'Похоже, это текстовый файл (или HTML-страница вместо схемы) — проверь, что скачал именно файл схемы.'
      : 'Файл не похож на NBT-схему: возможно, он повреждён, скачан не до конца или это не схема Minecraft.'
    let extra = 'NBT не распознан'
    try {
      parseNbt(data, true)
    } catch (e) {
      extra += `: ${e instanceof Error ? e.message : String(e)}`
    }
    return { ok: false, error: hint, details: describe(name, data, [extra]) }
  }

  const k = root.keys
  const ck = root.childKeys

  // 3) Точечные подсказки для известных, но не поддерживаемых форматов.
  if (k.has('size') && k.has('palette') && k.has('blocks')) {
    return {
      ok: false,
      error:
        'Это structure block (.nbt из структурных блоков Minecraft), а не схема. Пересохрани постройку в .litematic (Litematica) или .schem (WorldEdit //schem save).',
      details: describe(name, data, ['ключи корня: size, palette, blocks — structure block .nbt']),
    }
  }
  if (k.has('format_version') && (k.has('structure') || k.has('size'))) {
    return {
      ok: false,
      error:
        'Это .mcstructure (Bedrock-формат). Конвертер ждёт форматы Java: .litematic / .schem / .schematic.',
      details: describe(name, data, ['ключи корня: format_version + structure/size — Bedrock .mcstructure']),
    }
  }

  // 4) Диспетчер по ключам корня — определяем формат наверняка.
  if (k.has('Regions')) {
    try {
      return { ok: true, format: 'litematic', sch: parseLitematic(data) }
    } catch (e) {
      return {
        ok: false,
        error: `Файл похож на .litematic (есть Regions), но не читается: ${
          e instanceof Error ? e.message : String(e)
        }`,
        details: describe(name, data, [
          `litematic: ${e instanceof Error ? e.message : String(e)}`,
          `ключи корня: ${[...k].join(', ')}`,
        ]),
      }
    }
  }
  if (
    k.has('Palette') ||
    ck?.has('Palette') ||
    k.has('PaletteMax') ||
    ck?.has('PaletteMax') ||
    root.blocksCompound
  ) {
    try {
      return { ok: true, format: 'sponge', sch: parseSponge(data) }
    } catch (e) {
      return {
        ok: false,
        error: `Файл похож на .schem (Sponge), но не читается: ${
          e instanceof Error ? e.message : String(e)
        }`,
        details: describe(name, data, [
          `sponge: ${e instanceof Error ? e.message : String(e)}`,
          `ключи корня: ${[...k].join(', ')}`,
        ]),
      }
    }
  }
  if (k.has('Blocks') || ck?.has('Blocks')) {
    try {
      return { ok: true, format: 'legacy', sch: parseLegacySchematic(data) }
    } catch (e) {
      return {
        ok: false,
        error: `Файл похож на legacy .schematic, но не читается: ${
          e instanceof Error ? e.message : String(e)
        }`,
        details: describe(name, data, [
          `legacy: ${e instanceof Error ? e.message : String(e)}`,
          `ключи корня: ${[...k].join(', ')}`,
        ]),
      }
    }
  }

  // 5) Fallback: пробуем все парсеры по порядку расширения (как раньше).
  const tryOrder: Array<'litematic' | 'sponge' | 'legacy'> = []
  if (name.endsWith('.litematic')) tryOrder.push('litematic', 'sponge', 'legacy')
  else if (name.endsWith('.schem')) tryOrder.push('sponge', 'litematic', 'legacy')
  else if (name.endsWith('.schematic')) tryOrder.push('legacy', 'sponge', 'litematic')
  else tryOrder.push('litematic', 'sponge', 'legacy')

  const errors: string[] = []
  for (const fmt of tryOrder) {
    try {
      const sch =
        fmt === 'litematic'
          ? parseLitematic(data)
          : fmt === 'sponge'
            ? parseSponge(data)
            : parseLegacySchematic(data)
      return { ok: true, format: fmt, sch }
    } catch (e) {
      errors.push(`${fmt}: ${e instanceof Error ? e.message : String(e)}`)
    }
  }
  return {
    ok: false,
    error:
      'Не удалось разобрать схему: файл — корректный NBT, но ни один формат (litematic / sponge / legacy) не подошёл.',
    details: describe(name, data, [`ключи корня: ${[...k].join(', ')}`, ...errors]),
  }
}
