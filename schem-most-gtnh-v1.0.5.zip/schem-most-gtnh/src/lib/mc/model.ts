/** Unified schematic model shared by all format parsers. */

export interface PaletteState {
  /** registry name, e.g. "minecraft:stone" or "chisel:marble" */
  name: string
  /** block state properties (empty for 1.7.10-era data) */
  props: Record<string, string>
}

export type SchematicFormat = 'litematic' | 'sponge' | 'legacy'

export interface UnifiedSchematic {
  format: SchematicFormat
  /** display name of the build */
  title: string
  author?: string
  width: number // X
  height: number // Y (up)
  length: number // Z
  /** unique block states; for legacy format synthetic names are used */
  palette: PaletteState[]
  /** per-cell palette index; cell index = (y * length + z) * width + x */
  indices: Uint32Array
  /** only for format === 'legacy': numeric id/meta aligned with palette */
  legacyPalette: { id: number; meta: number }[]
  totalBlocks: number
  regionCount: number
}

export const AIR_STATE: PaletteState = { name: 'minecraft:air', props: {} }

/** canonical key for a state: "name[k=v,...]" with sorted props */
export function stateKey(s: PaletteState): string {
  const keys = Object.keys(s.props).sort()
  if (!keys.length) return s.name
  return `${s.name}[${keys.map((k) => `${k}=${s.props[k]}`).join(',')}]`
}

export function parseStateKey(key: string): PaletteState {
  const i = key.indexOf('[')
  if (i < 0) return { name: key, props: {} }
  const name = key.slice(0, i)
  const inner = key.slice(i + 1, key.length - 1)
  const props: Record<string, string> = {}
  if (inner) {
    for (const kv of inner.split(',')) {
      const eq = kv.indexOf('=')
      if (eq > 0) props[kv.slice(0, eq)] = kv.slice(eq + 1)
    }
  }
  return { name, props }
}

export function cellIndex(s: { width: number; length: number }, x: number, y: number, z: number): number {
  return (y * s.length + z) * s.width + x
}

/** LEB128 varint reader (Sponge BlockData, старые .litematic BlockStates). */
export function readVarints(data: Uint8Array): number[] {
  const out: number[] = []
  let value = 0
  let shift = 0
  for (let i = 0; i < data.length; i++) {
    const b = data[i]
    value |= (b & 0x7f) << shift
    if ((b & 0x80) === 0) {
      out.push(value >>> 0)
      value = 0
      shift = 0
    } else {
      shift += 7
      if (shift > 35) throw new Error('varint слишком длинный')
    }
  }
  return out
}
