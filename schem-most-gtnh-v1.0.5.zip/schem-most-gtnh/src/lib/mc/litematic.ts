/**
 * .litematic (Litematica mod) parser.
 *
 * Format facts (verified against litemapy reference implementation):
 * - little-endian NBT, gzipped
 * - root: { Version, SubVersion, MinecraftDataVersion, Metadata, Regions }
 * - each Region: { Position:{x,y,z}, Size:{x,y,z} (may be negative!),
 *    BlockStatePalette: [{ Name, Properties? }], BlockStates: long array }
 * - bit packing: nbits = max(2, bit_length(len(palette)-1));
 *    entry i starts at bit i*nbits, entries MAY straddle 64-bit long
 *    boundaries (pre-1.16 vanilla paletted container style), LSB-first
 * - in-region index = (y * |w*l|) + z*|w| + x  (x fastest, y slowest)
 * - negative size flips the axis: store coord 0 corresponds to
 *   region coord min(0, size+1)
 */
import {
  parseNbtSane,
  getCompound,
  getString,
  getNumber,
  getList,
  getLongArray,
  getByteArray,
  type NbtTag,
  type LongArrayValue,
} from '@/lib/nbt'
import {
  AIR_STATE,
  stateKey,
  readVarints,
  type PaletteState,
  type UnifiedSchematic,
} from './model'

/** extract nbits bits starting at bitIndex (LSB-first, straddling allowed) */
function getBits(lo: Uint32Array, hi: Uint32Array, bitIndex: number, nbits: number): number {
  const mask = nbits >= 32 ? 0xffffffff : (1 << nbits) - 1
  const l = bitIndex >>> 6
  const o = bitIndex & 63
  if (o < 32) {
    if (o + nbits <= 32) return (lo[l] >>> o) & mask
    // spans lo -> hi
    const fromLo = lo[l] >>> o
    const fromHi = hi[l] << (32 - o)
    return (fromLo | fromHi) & mask
  }
  const oo = o - 32
  if (oo + nbits <= 32) return (hi[l] >>> oo) & mask
  // spans hi -> next long's lo
  const fromHi = hi[l] >>> oo
  const fromNext = lo[l + 1] << (32 - oo)
  return (fromHi | fromNext) & mask
}

function longArrayToHalves(arr: LongArrayValue): { lo: Uint32Array; hi: Uint32Array } {
  const lo = new Uint32Array(arr.length)
  const hi = new Uint32Array(arr.length)
  for (let i = 0; i < arr.length; i++) {
    lo[i] = arr.lo(i)
    hi[i] = arr.hi(i)
  }
  return { lo, hi }
}

interface RegionData {
  posX: number
  posY: number
  posZ: number
  w: number // abs
  h: number
  l: number
  /** per-region coords min offsets (negative sizes flip) */
  minX: number
  minY: number
  minZ: number
  palette: PaletteState[]
  indices: Uint32Array
}

function readRegion(regionNbt: Record<string, NbtTag>): RegionData {
  const pos = getCompound(regionNbt, 'Position')
  const size = getCompound(regionNbt, 'Size')
  if (!pos || !size) throw new Error('litematic: region missing Position/Size')
  const posX = getNumber(pos, 'x') ?? 0
  const posY = getNumber(pos, 'y') ?? 0
  const posZ = getNumber(pos, 'z') ?? 0
  const sw = getNumber(size, 'x') ?? 0
  const sh = getNumber(size, 'y') ?? 0
  const sl = getNumber(size, 'z') ?? 0
  const w = Math.abs(sw)
  const h = Math.abs(sh)
  const l = Math.abs(sl)

  const paletteNbt = getList(regionNbt, 'BlockStatePalette')
  if (!paletteNbt) throw new Error('litematic: region missing BlockStatePalette')
  const palette: PaletteState[] = paletteNbt.map((entry) => {
    if (entry.type !== 10) throw new Error('litematic: bad palette entry')
    const name = getString(entry.value, 'Name') ?? 'minecraft:air'
    const propsTag = getCompound(entry.value, 'Properties')
    const props: Record<string, string> = {}
    if (propsTag) {
      for (const [k, v] of Object.entries(propsTag)) {
        if (v.type === 8) props[k] = v.value
      }
    }
    return { name, props }
  })

  const volume = w * h * l
  const indices = new Uint32Array(volume)
  const states = getLongArray(regionNbt, 'BlockStates')
  if (states && volume > 0 && palette.length > 1) {
    // современный формат (1.16+): long array, битупаковка LSB-first,
    // записи могут пересекать границы 64-битных long'ов
    const nbits = Math.max(2, Math.ceil(Math.log2(palette.length)))
    const { lo, hi } = longArrayToHalves(states)
    for (let i = 0; i < volume; i++) {
      const v = getBits(lo, hi, i * nbits, nbits)
      indices[i] = v < palette.length ? v : 0
    }
  } else {
    // старый формат (Litematica для 1.12–1.15): BlockStates/BlockData —
    // массив байт с LEB128-varint-индексами палитры
    const bytes = getByteArray(regionNbt, 'BlockStates') ?? getByteArray(regionNbt, 'BlockData')
    if (bytes && bytes.length > 0 && volume > 0 && palette.length > 1) {
      const vars = readVarints(bytes)
      for (let i = 0; i < volume; i++) {
        const v = i < vars.length ? vars[i] : 0
        indices[i] = v < palette.length ? v : 0
      }
    } else if (volume > 0) {
      // одноэлементная палитра или нет данных: всё — palette[0]
      indices.fill(0)
    }
  }

  return {
    posX,
    posY,
    posZ,
    w,
    h,
    l,
    minX: Math.min(0, sw + 1),
    minY: Math.min(0, sh + 1),
    minZ: Math.min(0, sl + 1),
    palette,
    indices,
  }
}

export function parseLitematic(data: Uint8Array): UnifiedSchematic {
  // litematic-формат — little-endian, но shulkr.com экспортирует .litematic
  // в big-endian: при LE-разборе такой файл «успешно» превращается в мусор,
  // поэтому выбираем разбор с чистыми ключами корня (parseNbtSane)
  const nbt = parseNbtSane(data, true)
  const root = (nbt.root as { type: 10; value: Record<string, NbtTag> }).value
  const meta = getCompound(root, 'Metadata')
  const title = getString(meta, 'Name') || 'Без названия'
  const author = getString(meta, 'Author') || undefined
  const regionsNbt = getCompound(root, 'Regions')
  if (!regionsNbt) throw new Error('litematic: no Regions')

  const regions: RegionData[] = Object.values(regionsNbt)
    .filter((t): t is Extract<NbtTag, { type: 10 }> => t.type === 10)
    .map((t) => readRegion(t.value))
  if (!regions.length) throw new Error('litematic: empty Regions')

  // union bounding box over all regions (in absolute schematic coords)
  let minX = Infinity, minY = Infinity, minZ = Infinity
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity
  for (const r of regions) {
    minX = Math.min(minX, r.posX + r.minX)
    minY = Math.min(minY, r.posY + r.minY)
    minZ = Math.min(minZ, r.posZ + r.minZ)
    maxX = Math.max(maxX, r.posX + r.minX + r.w - 1)
    maxY = Math.max(maxY, r.posY + r.minY + r.h - 1)
    maxZ = Math.max(maxZ, r.posZ + r.minZ + r.l - 1)
  }
  const width = maxX - minX + 1
  const height = maxY - minY + 1
  const length = maxZ - minZ + 1

  // merged palette: [0] = air, then per-region palettes with offset
  const mergedPalette: PaletteState[] = [AIR_STATE]
  const paletteKeyToIndex = new Map<string, number>([[stateKey(AIR_STATE), 0]])
  const regionRemap: number[][] = regions.map((r) => {
    // map[regionPaletteIdx] -> mergedPaletteIdx (air maps to 0 by key)
    const map: number[] = []
    for (const st of r.palette) {
      const key = stateKey(st)
      let idx = paletteKeyToIndex.get(key)
      if (idx === undefined) {
        mergedPalette.push(st)
        idx = mergedPalette.length - 1
        paletteKeyToIndex.set(key, idx)
      }
      map.push(idx)
    }
    return map
  })

  const indices = new Uint32Array(width * height * length) // zero-filled = air
  let totalBlocks = 0
  for (let ri = 0; ri < regions.length; ri++) {
    const r = regions[ri]
    const remap = regionRemap[ri]
    const originX = r.posX + r.minX - minX
    const originY = r.posY + r.minY - minY
    const originZ = r.posZ + r.minZ - minZ
    for (let y = 0; y < r.h; y++) {
      for (let z = 0; z < r.l; z++) {
        for (let x = 0; x < r.w; x++) {
          const srcIdx = (y * r.l * r.w) + z * r.w + x
          const p = remap[r.indices[srcIdx]]
          if (p === 0) continue
          const gx = originX + x
          const gy = originY + y
          const gz = originZ + z
          indices[(gy * length + gz) * width + gx] = p
          totalBlocks++
        }
      }
    }
  }

  return {
    format: 'litematic',
    title,
    author,
    width,
    height,
    length,
    palette: mergedPalette,
    indices,
    legacyPalette: [],
    totalBlocks,
    regionCount: regions.length,
  }
}
