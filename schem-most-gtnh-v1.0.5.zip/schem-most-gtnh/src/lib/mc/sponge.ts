/**
 * Sponge .schem (WorldEdit 7+) parser, versions 1/2/3.
 * - NBT (обычно little-endian, но shulkr.com и некоторые инструменты пишут
 *   big-endian — разбор с проверкой здравости см. parseNbtSane), gzipped
 * - v1/v2: root compound directly holds the data
 *   v3: data is nested under root's "Schematic" child, а палитра и данные
 *   блоков — подcompound'ом "Blocks": { Palette, Data|BlockData, BlockEntities }
 * - Palette: { "blockstate string": index }
 * - BlockData: byte array of LEB128 varints
 * - cell order: (y * Length + z) * Width + x
 */
import {
  parseNbtSane,
  getCompound,
  getString,
  getNumber,
  getByteArray,
  type NbtTag,
} from '@/lib/nbt'
import { parseStateKey, readVarints, type PaletteState, type UnifiedSchematic } from './model'

export function parseSponge(data: Uint8Array): UnifiedSchematic {
  // Спецификация говорит little-endian, но некоторые писатели (shulkr.com)
  // пишут big-endian. Обычный fallback срабатывает только по исключению,
  // а LE-разбор BE-файла может «успешно» выдать мусор — поэтому выбираем
  // тот разбор, у которого ключи корня похожи на настоящие.
  const nbt = parseNbtSane(data, true)
  const root = (nbt.root as { type: 10; value: Record<string, NbtTag> }).value
  return parseSchematicCompound(root)
}

function parseSchematicCompound(root: Record<string, NbtTag>): UnifiedSchematic {
  // v3 nests everything under "Schematic"
  const schematic = getCompound(root, 'Schematic') ?? root
  const version = getNumber(schematic, 'Version') ?? 2
  if (version < 1 || version > 3) {
    throw new Error(`schem: unsupported version ${version}`)
  }
  const width = getNumber(schematic, 'Width') ?? 0
  const height = getNumber(schematic, 'Height') ?? 0
  const length = getNumber(schematic, 'Length') ?? 0
  if (width <= 0 || height <= 0 || length <= 0) {
    throw new Error('schem: bad dimensions')
  }

  // v3 прячет палитру и данные блоков в compound "Blocks"
  const blocksC = getCompound(schematic, 'Blocks')
  const paletteNbt =
    getCompound(schematic, 'Palette') ?? (blocksC && getCompound(blocksC, 'Palette'))
  if (!paletteNbt) throw new Error('schem: missing Palette')

  // PaletteMax бывает отсутствует (shulkr) — размер берём по факту индексов
  const paletteMax = getNumber(schematic, 'PaletteMax') ?? (blocksC && getNumber(blocksC, 'PaletteMax')) ?? 0
  let maxIdx = paletteMax
  for (const idxTag of Object.values(paletteNbt)) {
    if (idxTag.type === 3 && idxTag.value > maxIdx) maxIdx = idxTag.value
  }
  const palette: PaletteState[] = new Array(Math.max(maxIdx + 1, 1))
  const filled: boolean[] = new Array(palette.length)
  for (const [stateStr, idxTag] of Object.entries(paletteNbt)) {
    if (idxTag.type !== 3) continue
    const idx = idxTag.value
    palette[idx] = parseStateKey(stateStr)
    filled[idx] = true
  }
  for (let i = 0; i < palette.length; i++) {
    if (!filled[i]) palette[i] = { name: 'minecraft:air', props: {} }
  }

  const blockData =
    getByteArray(schematic, 'BlockData') ??
    (blocksC && (getByteArray(blocksC, 'BlockData') ?? getByteArray(blocksC, 'Data')))
  if (!blockData) throw new Error('schem: missing BlockData')
  const varints = readVarints(blockData)
  const volume = width * height * length
  if (varints.length !== volume) {
    throw new Error(
      `schem: BlockData has ${varints.length} entries, expected ${volume}`,
    )
  }
  const indices = new Uint32Array(volume)
  let totalBlocks = 0
  for (let i = 0; i < volume; i++) {
    const v = varints[i]
    indices[i] = v < palette.length ? v : 0
    if (indices[i] !== 0) totalBlocks++
  }

  const metaNbt = getCompound(schematic, 'Metadata')
  const title =
    (metaNbt && getString(metaNbt, 'Name')) || 'Без названия'
  const author = (metaNbt && getString(metaNbt, 'Author')) || undefined

  return {
    format: 'sponge',
    title,
    author,
    width,
    height,
    length,
    palette,
    indices,
    legacyPalette: [],
    totalBlocks,
    regionCount: 1,
  }
}
