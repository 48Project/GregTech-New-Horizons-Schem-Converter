/**
 * Modern block name/state -> legacy 1.7.10 (id, meta) mapping engine.
 * Built on top of the inverted WorldEdit legacy.json table.
 */
import tableJson from '@/lib/data/legacy-blocks.json'

export interface TableEntry {
  id: number
  meta: number
  props: Record<string, string>
}
type Table = Record<string, TableEntry[]>

const TABLE = tableJson as Table

/** Rename aliases: modern name -> name present in the WE table */
const ALIASES: Record<string, string> = {}
const WOODS = [
  'oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak',
  'mangrove', 'cherry', 'bamboo', 'crimson', 'warped',
]
for (const w of WOODS) {
  ALIASES[`${w}_sign`] = 'sign'
  ALIASES[`${w}_wall_sign`] = 'wall_sign'
}
ALIASES.short_grass = 'grass'
ALIASES.tall_grass_alias = 'tall_grass' // no-op, keeps linters calm
ALIASES.dirt_path = 'grass_path'
ALIASES.hardened_clay = 'terracotta'

/** state props that do not affect the 1.7.10 id/meta (dropped when matching) */
const IGNORED_PROPS = new Set([
  'waterlogged', 'persistent', 'distance', 'shape', 'powered',
  'conditional', 'in_wall', 'snowy', 'has_record', 'enabled', 'trigger',
  'drag', 'running', 'attachment', 'bites', 'honey_level', 'hanging',
  'signal_fire', // lit handled via separate furnace entry; base is fine
  'age', 'stage', 'delay', 'rotation', 'occupied', 'eye', // half handled by stairs/slabs candidates
  'face', 'slots_0', 'slots_1', 'slots_2', 'bottles', 'has_bottle_0',
  'has_bottle_1', 'has_bottle_2', 'down', 'east', 'north', 'south', 'west', 'up',
  'short', 'mode', 'charge', 'ominous', 'cracked', 'hatched', 'eggs',
])
// NOTE: 'half' IS meaningful (stairs top/bottom, doors upper/lower) and 'type'
// IS meaningful for slabs (bottom/top/double) — both stay OUT of this set.
IGNORED_PROPS.delete('half')
IGNORED_PROPS.delete('lit')

/** Was this legacy (id, meta) present in vanilla 1.7.10? */
export function isValid1710(id: number, meta: number): boolean {
  if (id > 175) return false
  if (id >= 165 && id <= 169) return false // slime, barrier, iron trapdoor, prismarine, sea lantern (1.8)
  if (id === 1 && meta >= 1 && meta <= 6) return false // granite/diorite/andesite (1.8)
  if (id === 3 && meta === 1) return false // coarse dirt (1.8)
  return true
}

/* ---- hand-coded mappings where the WorldEdit table is wrong or ambiguous ---- */

/** 1.7.10 door meta: lower = facing(0-3) + 4*open; upper = 8 + 4*hingeRight + facing.
 *  The WE table encodes upper halves incorrectly, so doors are mapped by hand.
 *  Wood variants beyond oak didn't exist in 1.7.10 and fall back to the oak door. */
const DOOR_FACING_BITS: Record<string, number> = { east: 0, south: 1, west: 2, north: 3 }
function mapDoor(resolved: string, props: Record<string, string>): MappedState {
  const isVanillaDoor = resolved === 'oak_door' || resolved === 'wooden_door' || resolved === 'iron_door'
  const id = resolved === 'iron_door' ? 71 : 64
  const facing = DOOR_FACING_BITS[props.facing ?? 'east'] ?? 0
  if (props.half === 'upper') {
    return {
      id,
      meta: 8 + (props.hinge === 'right' ? 4 : 0) + facing,
      exact: isVanillaDoor && props.facing !== undefined && props.hinge !== undefined,
    }
  }
  return {
    id,
    meta: facing + (props.open === 'true' ? 4 : 0),
    exact: isVanillaDoor && props.facing !== undefined,
  }
}

/** 1.7.10 bed meta: facing (0=south,1=west,2=north,3=east) + 8 for the head part.
 *  Beds are absent from the WE table (WorldEdit can't paste them), so map by hand. */
const BED_FACING_BITS: Record<string, number> = { south: 0, west: 1, north: 2, east: 3 }
function mapBed(props: Record<string, string>): MappedState {
  const facing = BED_FACING_BITS[props.facing ?? 'south'] ?? 0
  return {
    id: 26,
    meta: facing + (props.part === 'head' ? 8 : 0),
    exact: props.facing !== undefined && props.part !== undefined,
  }
}

/** water/lava: level 0 (or unknown) = source block (9/11); higher = flowing (8/10). */
function mapFluid(resolved: string, props: Record<string, string>): MappedState {
  const level = props.level !== undefined ? parseInt(props.level, 10) : 0
  if (Number.isNaN(level) || level <= 0) {
    return { id: resolved === 'water' ? 9 : 11, meta: 0, exact: props.level !== undefined }
  }
  return { id: resolved === 'water' ? 8 : 10, meta: level, exact: true }
}

export interface MappedState {
  id: number
  meta: number
  /** all meaningful props of the input matched a table entry */
  exact: boolean
}

function resolveAlias(name: string): string {
  if (ALIASES[name]) return ALIASES[name]
  if (name.startsWith('stripped_')) {
    const base = name.slice('stripped_'.length)
    if (TABLE[base]) return base
    if (base.endsWith('_stem')) return `${base.slice(0, -5)}_log` // stripped_crimson_stem -> crimson_log? not in table
  }
  return name
}

/**
 * Map a modern block name + props to a legacy (id, meta).
 * Returns null when the block has no legacy representation at all
 * (post-1.12 blocks like concrete — caller decides the replacement).
 */
export function mapState(name: string, props: Record<string, string>): MappedState | null {
  const base = name.includes(':') ? name.split(':').slice(1).join(':') : name
  if (name.split(':')[0] !== 'minecraft' && name.includes(':')) {
    // modded names never exist in the vanilla table
    return null
  }
  const resolved = resolveAlias(base)

  // hand-coded special cases (doors: WE table upper halves are wrong;
  // fluids: table can't distinguish source vs flowing without level prop)
  if (resolved.endsWith('_door') || resolved === 'wooden_door') {
    return mapDoor(resolved, props)
  }
  if (resolved.endsWith('_bed') || resolved === 'bed') {
    return mapBed(props)
  }
  if (resolved === 'water' || resolved === 'lava') {
    return mapFluid(resolved, props)
  }

  const candidates = TABLE[resolved]
  if (!candidates || !candidates.length) return null

  // double-slab style ids (43/125/182): a full block for a "slab" input —
  // only used when the input state is more specific than that
  const DOUBLE_IDS = new Set([43, 125, 182])

  let best: TableEntry | null = null
  let bestScore = -Infinity
  let bestTie = Infinity
  let bestExact = false
  for (const cand of candidates) {
    let score = 0
    let missing = 0
    let exact = true
    for (const [k, v] of Object.entries(cand.props)) {
      if (IGNORED_PROPS.has(k)) continue
      const input = props[k]
      if (input === v) {
        score += 2
      } else if (input === undefined) {
        // unknown prop: slight penalty, prefer candidates assuming less
        missing++
        exact = false
      } else {
        score -= 4
        exact = false
      }
    }
    score -= missing * 0.25
    // tie-breaks: non-double slabs first, then lower meta (usually default)
    const tie = (DOUBLE_IDS.has(cand.id) ? 1000 : 0) + cand.meta
    if (score > bestScore || (score === bestScore && tie < bestTie)) {
      bestScore = score
      best = cand
      bestTie = tie
      bestExact = exact
    }
  }
  if (!best) return null
  return { id: best.id, meta: best.meta, exact: bestExact }
}

/** reverse lookup: (id, meta) -> modern state key, for nice labels */
const reverseTable = new Map<string, string>()
for (const [name, entries] of Object.entries(TABLE)) {
  for (const e of entries) {
    const key = `${e.id}:${e.meta}`
    if (!reverseTable.has(key)) {
      const pk = Object.entries(e.props)
        .filter(([k]) => !IGNORED_PROPS.has(k))
        .map(([k, v]) => `${k}=${v}`)
        .join(',')
      reverseTable.set(key, pk ? `minecraft:${name}[${pk}]` : `minecraft:${name}`)
    }
  }
}
// the WE table encodes door upper halves incorrectly -> decode by vanilla rules
{
  const FACINGS = ['east', 'south', 'west', 'north']
  for (const [id, name] of [[64, 'oak_door'], [71, 'iron_door']] as const) {
    for (let meta = 0; meta < 16; meta++) {
      const facing = FACINGS[meta & 3]
      const state =
        meta < 8
          ? `facing=${facing},half=lower,open=${meta >= 4}`
          : `facing=${facing},half=upper,hinge=${(meta & 4) === 4 ? 'right' : 'left'}`
      reverseTable.set(`${id}:${meta}`, `minecraft:${name}[${state}]`)
    }
  }
}
export function legacyToModernLabel(id: number, meta: number): string | undefined {
  return reverseTable.get(`${id}:${meta}`)
}

/** All valid 1.7.10 targets derived from the table (for the picker UI). */
export interface VanillaTarget {
  id: number
  meta: number
  /** modern-ish label like "minecraft:white_wool" */
  label: string
  name: string
}
let vanillaTargets: VanillaTarget[] | null = null
export function getVanillaTargets(): VanillaTarget[] {
  if (vanillaTargets) return vanillaTargets
  const seen = new Set<string>()
  const out: VanillaTarget[] = []
  for (const [name, entries] of Object.entries(TABLE)) {
    for (const e of entries) {
      if (!isValid1710(e.id, e.meta)) continue
      const key = `${e.id}:${e.meta}`
      if (seen.has(key)) continue
      seen.add(key)
      out.push({ id: e.id, meta: e.meta, label: `minecraft:${name}`, name })
    }
  }
  vanillaTargets = out
  return out
}
