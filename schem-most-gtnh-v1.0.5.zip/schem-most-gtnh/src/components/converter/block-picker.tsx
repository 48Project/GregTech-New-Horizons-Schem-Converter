'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'

interface VanillaBlock {
  id: number
  meta: number
  label: string
  name: string
}

interface ProfileBlock {
  name: string
  id: number
}

interface BlockPickerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** block being replaced, shown in the title */
  sourceLabel: string
  profileId: string | null
  onPick: (id: number, meta: number) => void
  onPickAir: () => void
}

export function BlockPicker({ open, onOpenChange, sourceLabel, profileId, onPick, onPickAir }: BlockPickerProps) {
  const [q, setQ] = useState('')
  const [vanilla, setVanilla] = useState<VanillaBlock[] | null>(null)
  const [profileBlocks, setProfileBlocks] = useState<ProfileBlock[] | null>(null)
  const [tab, setTab] = useState<string>(profileId ? 'profile' : 'vanilla')
  const [loading, setLoading] = useState(false)
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null)

  const search = useCallback(
    (query: string) => {
      setLoading(true)
      const loadProfile = async () => {
        if (tab !== 'profile' || !profileId) return
        try {
          const res = await fetch(`/api/profiles/${profileId}/blocks?q=${encodeURIComponent(query)}`)
          const json = (await res.json()) as { blocks: ProfileBlock[] }
          setProfileBlocks(json.blocks ?? [])
        } catch {
          setProfileBlocks([])
        } finally {
          setLoading(false)
        }
      }
      if (tab === 'vanilla') {
        fetch(`/api/vanilla-blocks?q=${encodeURIComponent(query)}`)
          .then((r) => r.json())
          .then((json: { blocks: VanillaBlock[] }) => setVanilla(json.blocks ?? []))
          .catch(() => setVanilla([]))
          .finally(() => setLoading(false))
      } else {
        void loadProfile()
      }
    },
    [tab, profileId],
  )

  useEffect(() => {
    if (!open) return
    if (debounce.current) clearTimeout(debounce.current)
    debounce.current = setTimeout(() => search(q), 200)
    return () => {
      if (debounce.current) clearTimeout(debounce.current)
    }
  }, [q, open, search])

  useEffect(() => {
    if (open) {
      setTab(profileId ? 'profile' : 'vanilla')
      setQ('')
    }
  }, [open, profileId])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg border-border/40 bg-[#0c1531]/95 backdrop-blur-xl">
        <DialogHeader>
          <DialogTitle className="text-[#e6ecff]">
            Замена для <span className="text-[#7ea6ff]">{sourceLabel}</span>
          </DialogTitle>
          <DialogDescription className="text-xs text-[#8fa1c9]">
            Ванилла 1.7.10 или блоки из профиля сборки — поиск по имени или числовому ID
          </DialogDescription>
        </DialogHeader>
        <Input
          autoFocus
          placeholder="Поиск блока: quartz, 41:0, gregtech:gt.blo..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="border-[#2a3c74] bg-[#0a1128] text-[#e6ecff] placeholder:text-[#5a6b99]"
        />
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="grid w-full grid-cols-2 bg-[#0a1128]">
            <TabsTrigger value="vanilla" className="data-[state=active]:bg-[#1a2a5c]">Ванилла 1.7.10</TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-[#1a2a5c]" disabled={!profileId}>
              Блоки сборки
            </TabsTrigger>
          </TabsList>
          <TabsContent value="vanilla" className="mt-2">
            <ScrollArea className="h-72 rounded-lg border border-[#1c2b58] bg-[#0a1128]/60">
              <div className="p-1">
                {loading && !vanilla ? (
                  <div className="space-y-1 p-2">
                    <Skeleton className="h-9 w-full bg-[#13204a]" />
                    <Skeleton className="h-9 w-full bg-[#13204a]" />
                    <Skeleton className="h-9 w-full bg-[#13204a]" />
                  </div>
                ) : (
                  vanilla?.map((b) => (
                    <button
                      key={`${b.id}:${b.meta}`}
                      className="flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm text-[#c9d6f5] transition-colors hover:bg-[#16234e]"
                      onClick={() => {
                        onPick(b.id, b.meta)
                        onOpenChange(false)
                      }}
                    >
                      <span className="truncate">{b.label}</span>
                      <span className="ml-2 shrink-0 font-mono text-xs text-[#6d80b5]">
                        {b.id}:{b.meta}
                      </span>
                    </button>
                  ))
                )}
                {vanilla && vanilla.length === 0 && !loading && (
                  <p className="p-4 text-center text-sm text-[#5a6b99]">Ничего не найдено</p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          <TabsContent value="profile" className="mt-2">
            <ScrollArea className="h-72 rounded-lg border border-[#1c2b58] bg-[#0a1128]/60">
              <div className="p-1">
                {profileBlocks === null && loading ? (
                  <div className="space-y-1 p-2">
                    <Skeleton className="h-9 w-full bg-[#13204a]" />
                    <Skeleton className="h-9 w-full bg-[#13204a]" />
                  </div>
                ) : (
                  profileBlocks?.map((b) => (
                    <button
                      key={b.name}
                      className="flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm text-[#c9d6f5] transition-colors hover:bg-[#16234e]"
                      onClick={() => {
                        onPick(b.id, 0)
                        onOpenChange(false)
                      }}
                    >
                      <span className="truncate">{b.name}</span>
                      <Badge variant="outline" className="ml-2 shrink-0 border-[#2a3c74] font-mono text-xs text-[#6d80b5]">
                        id {b.id}
                      </Badge>
                    </button>
                  ))
                )}
                {profileBlocks && profileBlocks.length === 0 && !loading && (
                  <p className="p-4 text-center text-sm text-[#5a6b99]">Ничего не найдено</p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
        <button
          className="w-full rounded-lg border border-[#3a2a4a] bg-[#1c1226]/70 px-3 py-2 text-sm text-[#d8b4fe] transition-colors hover:bg-[#241634]"
          onClick={() => {
            onPickAir()
            onOpenChange(false)
          }}
        >
          Убрать блок (заменить воздухом)
        </button>
        {!profileId && (
          <p className="text-center text-xs text-[#5a6b99]">
            Чтобы искать блоки модов сборки, загрузи профиль (level.dat) на шаге 1
          </p>
        )}
      </DialogContent>
    </Dialog>
  )
}
