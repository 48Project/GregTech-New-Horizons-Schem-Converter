'use client'

import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { useToast } from '@/hooks/use-toast'
import type { ProfileInfo } from '@/lib/converter-types'

interface StepProfileProps {
  profiles: ProfileInfo[]
  selectedId: string | null
  onSelect: (id: string | null) => void
  onUploaded: (profile: ProfileInfo) => void
  onDeleted: (id: string) => void
  onNext: () => void
}

export function StepProfile({ profiles, selectedId, onSelect, onUploaded, onDeleted, onNext }: StepProfileProps) {
  const { toast } = useToast()
  const fileRef = useRef<HTMLInputElement>(null)
  const [name, setName] = useState('')
  const [busy, setBusy] = useState(false)
  const [dragOver, setDragOver] = useState(false)

  async function upload(file: File) {
    setBusy(true)
    try {
      const form = new FormData()
      form.set('file', file)
      if (name.trim()) form.set('name', name.trim())
      else form.set('name', file.name === 'level.dat' ? `Профиль от ${new Date().toLocaleDateString('ru-RU')}` : file.name)
      const res = await fetch('/api/profiles', { method: 'POST', body: form })
      const json = await res.json()
      if (!res.ok) throw new Error(json.error ?? 'Ошибка загрузки')
      onUploaded(json.profile as ProfileInfo)
      onSelect(json.profile.id)
      toast({
        title: 'Профиль загружен',
        description: `${json.profile.modCount} модов, ${json.profile.blockCount} блоков в карте ID`,
      })
    } catch (e) {
      toast({
        title: 'Не удалось загрузить level.dat',
        description: e instanceof Error ? e.message : String(e),
        variant: 'destructive',
      })
    } finally {
      setBusy(false)
    }
  }

  async function remove(id: string) {
    try {
      const res = await fetch(`/api/profiles/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Ошибка удаления')
      onDeleted(id)
    } catch (e) {
      toast({ title: 'Ошибка', description: e instanceof Error ? e.message : String(e), variant: 'destructive' })
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
      <Card className="border-[#1c2b58] bg-[#0b1430]/70 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#e6ecff]">
            <span className="text-[#7ea6ff]">①</span> Профиль сборки
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm leading-relaxed text-[#8fa1c9]">
            Фордж 1.7.10 назначает числовые ID модовым блокам{' '}
            <span className="text-[#c9d6f5]">динамически при запуске</span> — у каждой сборки они свои.
            Из-за этого «универсальные» конвертеры превращают камень в дверь. Возьмём карту ID из твоего
            мира: файл <code className="rounded bg-[#0a1128] px-1.5 py-0.5 font-mono text-xs text-[#67e0ff]">level.dat</code>{' '}
            лежит в папке мира: <code className="rounded bg-[#0a1128] px-1.5 py-0.5 font-mono text-xs text-[#9db4e8]">.minecraft/saves/&lt;имя мира&gt;/level.dat</code>{' '}
            (или <code className="rounded bg-[#0a1128] px-1.5 py-0.5 font-mono text-xs text-[#9db4e8]">instances/GTNH/saves/...</code>).
          </p>
          <Input
            placeholder="Имя профиля (необязательно), например «GTNH 2.7.0»"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border-[#2a3c74] bg-[#0a1128] text-[#e6ecff] placeholder:text-[#5a6b99]"
          />
          <div
            className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-8 transition-colors ${
              dragOver ? 'border-[#7ea6ff] bg-[#7ea6ff]/10' : 'border-[#233466] hover:border-[#4a63a8]'
            }`}
            onDragOver={(e) => {
              e.preventDefault()
              setDragOver(true)
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault()
              setDragOver(false)
              const f = e.dataTransfer.files?.[0]
              if (f) void upload(f)
            }}
            onClick={() => fileRef.current?.click()}
          >
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" className="text-[#7ea6ff]">
              <path
                d="M12 16V6m0 0l-4 4m4-4l4 4M4 20h16"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <p className="text-sm text-[#c9d6f5]">{busy ? 'Читаю FML-карту...' : 'Перетащи level.dat или нажми'}</p>
            <p className="text-xs text-[#5a6b99]">достаточно одного раза — профиль сохранится</p>
            <input
              ref={fileRef}
              type="file"
              accept=".dat,.level.dat"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) void upload(f)
                e.target.value = ''
              }}
            />
          </div>
          <div className="flex items-center justify-between pt-1">
            <button className="text-xs text-[#5a6b99] underline-offset-2 hover:text-[#8fa1c9] hover:underline" onClick={() => onSelect(null)}>
              Пропустить — без профиля (моды проверяться не будут)
            </button>
            <Button
              className="bg-[#2c4d9e] text-white hover:bg-[#3a5fc0]"
              onClick={onNext}
            >
              Дальше →
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-[#1c2b58] bg-[#0b1430]/70 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-[#8fa1c9]">Сохранённые профили</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {profiles.length === 0 && (
            <p className="py-6 text-center text-sm text-[#5a6b99]">Пока пусто — загрузи первый level.dat</p>
          )}
          {profiles.map((p) => (
            <div
              key={p.id}
              className={`group flex items-center gap-3 rounded-lg border p-3 transition-colors ${
                selectedId === p.id
                  ? 'border-[#7ea6ff] bg-[#7ea6ff]/10'
                  : 'border-[#1c2b58] bg-[#0a1128]/50 hover:border-[#2a3c74]'
              }`}
              onClick={() => onSelect(p.id)}
            >
              <div className="min-w-0 flex-1 cursor-pointer">
                <p className="truncate text-sm font-medium text-[#e6ecff]">{p.name}</p>
                <p className="truncate text-xs text-[#5a6b99]">
                  мир «{p.levelName}» · {p.modCount} модов · {p.blockCount} блоков
                </p>
              </div>
              <Badge variant="outline" className="shrink-0 border-[#2a3c74] text-xs text-[#9db4e8]">
                {new Date(p.createdAt).toLocaleDateString('ru-RU')}
              </Badge>
              <button
                className="shrink-0 rounded p-1 text-[#5a6b99] opacity-0 transition-opacity hover:text-rose-400 group-hover:opacity-100"
                title="Удалить профиль"
                onClick={(e) => {
                  e.stopPropagation()
                  void remove(p.id)
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </button>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
