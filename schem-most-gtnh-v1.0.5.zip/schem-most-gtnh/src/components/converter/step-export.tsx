'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { useToast } from '@/hooks/use-toast'
import type { AnalysisItem, Decision, MaterialRow } from '@/lib/converter-types'

interface StepExportProps {
  title: string
  palette: AnalysisItem[]
  decisions: Record<string, Decision>
  file: File
  profileId: string | null
  onBack: () => void
  onRestart: () => void
}

export function StepExport({ title, palette, decisions, file, profileId, onBack, onRestart }: StepExportProps) {
  const { toast } = useToast()
  const [name, setName] = useState(sanitize(title) || 'schematic')
  const [busy, setBusy] = useState(false)
  const [materials, setMaterials] = useState<MaterialRow[] | null>(null)
  const [total, setTotal] = useState<number | null>(null)

  const dropped = palette
    .filter((it) => decisions[it.key]?.kind === 'air')
    .reduce((s, it) => s + it.count, 0)

  async function doExport() {
    setBusy(true)
    setMaterials(null)
    try {
      const form = new FormData()
      form.set('file', file)
      form.set('name', name)
      if (profileId) form.set('profileId', profileId)
      form.set('decisions', JSON.stringify(decisions))
      const res = await fetch('/api/convert', { method: 'POST', body: form })
      if (res.status === 422) {
        const json = await res.json()
        throw new Error(json.error ?? 'Есть неразрешённые блоки')
      }
      if (!res.ok) {
        const json = await res.json().catch(() => ({ error: 'Ошибка конвертации' }))
        throw new Error(json.error ?? 'Ошибка конвертации')
      }
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${name}.schematic`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)

      const matsHeader = res.headers.get('X-Materials')
      if (matsHeader) {
        try {
          setMaterials(JSON.parse(decodeURIComponent(matsHeader)) as MaterialRow[])
        } catch {
          /* ignore */
        }
      }
      const tb = res.headers.get('X-Total-Blocks')
      if (tb) setTotal(Number(tb))
      toast({ title: 'Готово!', description: `${name}.schematic скачан` })
    } catch (e) {
      toast({
        title: 'Экспорт не удался',
        description: e instanceof Error ? e.message : String(e),
        variant: 'destructive',
      })
    } finally {
      setBusy(false)
    }
  }

  function copyMaterials() {
    if (!materials) return
    const text = ['Блок\tID\tКол-во', ...materials.map((m) => `${m.label}\t${m.id}:${m.meta}\t${m.count}`)].join('\n')
    void navigator.clipboard.writeText(text).then(() => toast({ title: 'Список материалов скопирован' }))
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
      <Card className="border-[#1c2b58] bg-[#0b1430]/70 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#e6ecff]">
            <span className="text-[#7ea6ff]">④</span> Экспорт
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border-[#2a3c74] bg-[#0a1128] text-[#e6ecff]"
              placeholder="имя файла"
            />
            <span className="flex items-center font-mono text-sm text-[#5a6b99]">.schematic</span>
          </div>
          <Button
            className="w-full bg-gradient-to-r from-[#2c4d9e] to-[#3b6fd4] text-lg font-medium text-white hover:from-[#3a5fc0] hover:to-[#4d80e8]"
            onClick={doExport}
            disabled={busy}
          >
            {busy ? 'Конвертирую...' : 'Скачать .schematic'}
          </Button>
          {dropped > 0 && (
            <p className="text-center text-xs text-[#8fa1c9]">
              {dropped} блоков будет убрано (заменено воздухом по твоим решениям)
            </p>
          )}

          {materials && (
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-[#e6ecff]">
                  Материалы {total !== null && <span className="text-[#5a6b99]">— {total.toLocaleString('ru-RU')} блоков всего</span>}
                </h3>
                <button
                  className="text-xs text-[#67e0ff] underline-offset-2 hover:underline"
                  onClick={copyMaterials}
                >
                  скопировать список
                </button>
              </div>
              <div className="overflow-hidden rounded-xl border border-[#1c2b58]">
                <div className="max-h-72 overflow-y-auto">
                  <table className="w-full text-sm">
                    <thead className="sticky top-0 bg-[#0a1128]/95 backdrop-blur">
                      <tr className="text-left text-xs uppercase tracking-wide text-[#5a6b99]">
                        <th className="px-3 py-2 font-medium">Блок</th>
                        <th className="w-20 px-2 py-2 font-medium">ID</th>
                        <th className="w-20 px-2 py-2 text-right font-medium">Кол-во</th>
                      </tr>
                    </thead>
                    <tbody>
                      {materials.map((m) => (
                        <tr key={`${m.id}:${m.meta}`} className="border-t border-[#141f44]">
                          <td className="px-3 py-1.5 text-[#c9d6f5]">{m.label}</td>
                          <td className="px-2 py-1.5 font-mono text-xs text-[#6d80b5]">
                            {m.id}:{m.meta}
                          </td>
                          <td className="px-2 py-1.5 text-right font-mono text-[#8fa1c9]">
                            {m.count.toLocaleString('ru-RU')}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="h-fit border-[#1c2b58] bg-[#0b1430]/70 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-[#8fa1c9]">Как поставить в игру</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-[#9db4e8]">
          <ol className="list-decimal space-y-2 pl-4 leading-relaxed">
            <li>
              Положи файл в папку <code className="rounded bg-[#0a1128] px-1.5 py-0.5 font-mono text-xs text-[#67e0ff]">schematics</code>{' '}
              внутри инстанса GTNH (если папки нет — создай).
            </li>
            <li>
              В игре (Schematica уже в сборке): загрузи схему через меню Schematica, ключ по умолчанию{' '}
              <kbd className="rounded border border-[#2a3c74] bg-[#0a1128] px-1.5 py-0.5 font-mono text-xs">M</kbd> → Schematics → Load.
            </li>
            <li>
              Включи рендер призрака и печатай по слоям (<kbd className="rounded border border-[#2a3c74] bg-[#0a1128] px-1.5 py-0.5 font-mono text-xs">,</kbd> — Printer).
            </li>
          </ol>
          <div className="rounded-lg border border-[#233466] bg-[#0a1128]/60 p-3 text-xs leading-relaxed text-[#8fa1c9]">
            <p className="mb-1 font-medium text-[#9db4e8]">Помни:</p>
            <ul className="list-disc space-y-1 pl-4">
              <li>инвентари (сундуки, машины) переносятся пустыми — так работает формат;</li>
              <li>блоки из сборки ставятся с метой 0 — вариант блока (например, конкретную машину GT) выбирай руками;</li>
              <li>модовые блоки, которых нет в твоей сборке, мы заменили по таблице — проверь стеклянные/механические места.</li>
            </ul>
          </div>
          <Button
            variant="outline"
            className="w-full border-[#2a3c74] bg-transparent text-[#9db4e8] hover:bg-[#13204a]"
            onClick={onBack}
          >
            ← К маппингу
          </Button>
          <Button variant="outline" className="w-full border-[#233466] bg-transparent text-[#5a6b99] hover:bg-[#13204a]" onClick={onRestart}>
            Конвертировать другую схему
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

function sanitize(s: string): string {
  return s.replace(/[^\w\-а-яА-ЯёЁ ]+/g, '').trim().slice(0, 60)
}
