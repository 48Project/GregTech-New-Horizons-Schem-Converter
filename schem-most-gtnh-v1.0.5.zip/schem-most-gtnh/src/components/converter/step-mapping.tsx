'use client'

import { useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useToast } from '@/hooks/use-toast'
import { BlockPicker } from './block-picker'
import type { AnalysisItem, Decision, PresetInfo } from '@/lib/converter-types'
import { STATUS_META } from '@/lib/converter-types'

interface StepMappingProps {
  palette: AnalysisItem[]
  decisions: Record<string, Decision>
  profileId: string | null
  onDecide: (key: string, decision: Decision) => void
  onResetDecision: (key: string) => void
  presets: PresetInfo[]
  onLoadPreset: (preset: PresetInfo) => void
  onSavePreset: (name: string) => void
  onDeletePreset: (id: string) => void
  onBack: () => void
  onNext: () => void
}

export function StepMapping({
  palette,
  decisions,
  profileId,
  onDecide,
  onResetDecision,
  presets,
  onLoadPreset,
  onSavePreset,
  onDeletePreset,
  onBack,
  onNext,
}: StepMappingProps) {
  const { toast } = useToast()
  const [q, setQ] = useState('')
  const [statusFilter, setStatusFilter] = useState<Set<string>>(new Set())
  const [pickerFor, setPickerFor] = useState<AnalysisItem | null>(null)

  const statusCounts = useMemo(() => {
    const m = new Map<string, number>()
    for (const item of palette) m.set(item.status, (m.get(item.status) ?? 0) + 1)
    return m
  }, [palette])

  const filtered = useMemo(() => {
    const query = q.toLowerCase().trim()
    return palette
      .filter((it) => statusFilter.size === 0 || statusFilter.has(it.status))
      .filter((it) => !query || it.key.toLowerCase().includes(query))
      .sort((a, b) => b.count - a.count)
  }, [palette, q, statusFilter])

  const manualLeft = palette.filter((it) => it.status === 'manual' && !decisions[it.key]).length
  const decidedCount = palette.filter((it) => decisions[it.key] && decisions[it.key].kind !== 'default').length

  function currentTarget(it: AnalysisItem): { id: number; meta: number } | null {
    const d = decisions[it.key]
    if (!d || d.kind === 'default') return it.target
    if (d.kind === 'air') return { id: 0, meta: 0 }
    return { id: d.id, meta: d.meta }
  }

  function targetText(it: AnalysisItem): string {
    const t = currentTarget(it)
    if (!t) return '— выбрать —'
    if (t.id === 0) return 'воздух (убрано)'
    if (decisions[it.key] && decisions[it.key].kind === 'target' && !it.targetLabel?.includes(`(${t.id}:${t.meta})`)) {
      return `id ${t.id}:${t.meta}`
    }
    return it.targetLabel ?? `id ${t.id}:${t.meta}`
  }

  function toggleStatus(s: string) {
    const next = new Set(statusFilter)
    if (next.has(s)) next.delete(s)
    else next.add(s)
    setStatusFilter(next)
  }

  return (
    <Card className="border-[#1c2b58] bg-[#0b1430]/70 backdrop-blur-xl">
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <CardTitle className="flex items-center gap-2 text-[#e6ecff]">
          <span className="text-[#7ea6ff]">③</span> Замены блоков
          {decidedCount > 0 && (
            <Badge variant="outline" className="border-[#7ea6ff]/40 bg-[#7ea6ff]/10 text-[#9dc2ff]">
              своих решений: {decidedCount}
            </Badge>
          )}
        </CardTitle>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="border-[#2a3c74] bg-transparent text-[#9db4e8] hover:bg-[#13204a]">
                Пресеты ({presets.length})
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="border-[#2a3c74] bg-[#0c1531]">
              {presets.length === 0 && (
                <p className="px-3 py-2 text-xs text-[#5a6b99]">Сохранённых пресетов пока нет</p>
              )}
              {presets.map((p) => (
                <DropdownMenuItem
                  key={p.id}
                  className="gap-2 text-[#c9d6f5] focus:bg-[#16234e]"
                  onClick={() => onLoadPreset(p)}
                >
                  <span className="flex-1 truncate">{p.name}</span>
                  <button
                    className="text-[#5a6b99] hover:text-rose-400"
                    onClick={(e) => {
                      e.stopPropagation()
                      onDeletePreset(p.id)
                    }}
                    title="Удалить"
                  >
                    ✕
                  </button>
                </DropdownMenuItem>
              ))}
              <DropdownMenuItem
                className="gap-2 border-t border-[#1c2b58] text-[#67e0ff] focus:bg-[#16234e]"
                onClick={() => {
                  const name = prompt('Имя пресета:', 'Мои замены')
                  if (name?.trim()) onSavePreset(name.trim())
                }}
              >
                + Сохранить текущие замены
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            variant="outline"
            className="border-[#2a3c74] bg-transparent text-[#9db4e8] hover:bg-[#13204a]"
            onClick={() => {
              let n = 0
              for (const it of palette) {
                if (it.status === 'manual' && !decisions[it.key]) {
                  onDecide(it.key, { kind: 'air' })
                  n++
                }
              }
              toast({
                title: n ? 'Ручные блоки убраны' : 'Ручных блоков нет',
                description: n ? `${n} типов заменено воздухом` : undefined,
              })
            }}
          >
            «Выбери» → воздух
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <Input
            placeholder="Поиск: chisel, concrete, oak_log..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="w-64 border-[#2a3c74] bg-[#0a1128] text-[#e6ecff] placeholder:text-[#5a6b99]"
          />
          <div className="flex flex-wrap gap-1.5">
            {[...statusCounts.entries()]
              .sort((a, b) => b[1] - a[1])
              .map(([s, n]) => (
                <button
                  key={s}
                  onClick={() => toggleStatus(s)}
                  className={`rounded-full border px-2.5 py-0.5 text-xs transition-all ${
                    statusFilter.size === 0 || statusFilter.has(s)
                      ? STATUS_META[s as keyof typeof STATUS_META].cls
                      : 'border-[#233466] text-[#5a6b99] opacity-60'
                  }`}
                >
                  {STATUS_META[s as keyof typeof STATUS_META].label} · {n}
                </button>
              ))}
          </div>
        </div>

        <div className="overflow-hidden rounded-xl border border-[#1c2b58]">
          <div className="max-h-[52vh] overflow-y-auto overflow-x-hidden">
            <table className="w-full table-fixed text-sm">
              <thead className="sticky top-0 z-10 bg-[#0a1128]/95 backdrop-blur">
                <tr className="text-left text-xs uppercase tracking-wide text-[#5a6b99]">
                  <th className="px-3 py-2 font-medium">Блок</th>
                  <th className="w-14 px-2 py-2 text-right font-medium">Шт.</th>
                  <th className="w-24 px-2 py-2 font-medium">Статус</th>
                  <th className="w-[27%] px-3 py-2 font-medium">Будет в 1.7.10</th>
                  <th className="w-40 px-2 py-2 font-medium">Действие</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((it) => {
                  const d = decisions[it.key]
                  const custom = d && d.kind !== 'default'
                  const target = currentTarget(it)
                  return (
                    <tr
                      key={it.key}
                      className={`border-t border-[#141f44] transition-colors hover:bg-[#0e1a3d] ${
                        it.status === 'manual' && !target ? 'bg-rose-500/5' : ''
                      }`}
                    >
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-2">
                          {it.mod !== 'minecraft' && (
                            <Badge variant="outline" className="shrink-0 border-purple-500/30 bg-purple-500/10 text-[#c084fc]">
                              {it.mod}
                            </Badge>
                          )}
                          <span className="min-w-0 flex-1 truncate font-mono text-xs text-[#c9d6f5]" title={it.key}>
                            {it.name}
                            {Object.keys(it.props).length > 0 && (
                              <span className="text-[#5a6b99]">
                                [{Object.entries(it.props).map(([k, v]) => `${k}=${v}`).join(', ')}]
                              </span>
                            )}
                          </span>
                        </div>
                        {it.reason && <p className="mt-0.5 truncate text-xs text-[#6d80b5]" title={it.reason}>{it.reason}</p>}
                      </td>
                      <td className="px-2 py-2 text-right font-mono text-xs text-[#8fa1c9]">{it.count}</td>
                      <td className="px-2 py-2">
                        <Badge
                          variant="outline"
                          className={STATUS_META[it.status].cls}
                          title={STATUS_META[it.status].hint}
                        >
                          {STATUS_META[it.status].label}
                        </Badge>
                      </td>
                      <td className="px-3 py-2">
                        {target ? (
                          <span className="block truncate" title={targetText(it)}>
                            <span className={target.id === 0 ? 'text-[#5a6b99]' : 'text-[#e6ecff]'}>
                              {targetText(it)}
                            </span>
                            {target.id !== 0 && (
                              <span className="ml-1.5 font-mono text-xs text-[#6d80b5]">
                                {target.id}:{target.meta}
                              </span>
                            )}
                          </span>
                        ) : (
                          <span className="text-rose-400">не выбрано</span>
                        )}
                        {custom && (
                          <button
                            className="ml-1.5 text-xs text-[#67e0ff] underline-offset-2 hover:underline"
                            onClick={() => onResetDecision(it.key)}
                            title="Вернуть предложение конвертера"
                          >
                            сброс
                          </button>
                        )}
                      </td>
                      <td className="px-2 py-2">
                        <div className="flex gap-1">
                          <button
                            className="whitespace-nowrap rounded-md border border-[#2a3c74] px-2 py-1 text-[11px] text-[#9db4e8] transition-colors hover:bg-[#13204a]"
                            onClick={() => setPickerFor(it)}
                          >
                            Заменить
                          </button>
                          <button
                            className={`whitespace-nowrap rounded-md border px-2 py-1 text-[11px] transition-colors ${
                              d?.kind === 'air'
                                ? 'border-[#3a2a4a] bg-[#241634] text-[#d8b4fe]'
                                : 'border-[#2a3c74] text-[#9db4e8] hover:bg-[#13204a]'
                            }`}
                            onClick={() => onDecide(it.key, { kind: 'air' })}
                            title="Убрать блок из схемы"
                          >
                            Воздух
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-3 py-8 text-center text-sm text-[#5a6b99]">
                      Ничего не найдено по фильтрам
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <Button variant="outline" className="border-[#2a3c74] bg-transparent text-[#9db4e8] hover:bg-[#13204a]" onClick={onBack}>
            ← Схема
          </Button>
          <div className="flex items-center gap-3">
            {manualLeft > 0 && (
              <p className="text-sm text-amber-300">
                осталось {manualLeft} нерешённых — экспорт не пройдёт, пока не выберешь замену или не уберёшь их в воздух
              </p>
            )}
            <Button className="bg-[#2c4d9e] text-white hover:bg-[#3a5fc0]" onClick={onNext}>
              К экспорту →
            </Button>
          </div>
        </div>
      </CardContent>
      {pickerFor && (
        <BlockPicker
          open
          onOpenChange={(o) => {
            if (!o) setPickerFor(null)
          }}
          sourceLabel={pickerFor.name}
          profileId={profileId}
          onPick={(id, meta) => {
            onDecide(pickerFor.key, { kind: 'target', id, meta })
            setPickerFor(null)
          }}
          onPickAir={() => {
            onDecide(pickerFor.key, { kind: 'air' })
            setPickerFor(null)
          }}
        />
      )}
    </Card>
  )
}
