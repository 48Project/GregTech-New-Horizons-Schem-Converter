'use client'

import { useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import type { AnalyzeResponse, PaletteStatus } from '@/lib/converter-types'
import { STATUS_META } from '@/lib/converter-types'

const FORMAT_LABEL: Record<AnalyzeResponse['format'], string> = {
  litematic: '.litematic (Litematica)',
  sponge: '.schem (Sponge / WorldEdit 7+)',
  legacy: '.schematic (MCEdit legacy)',
}

interface StepSchematicProps {
  file: File | null
  analysis: AnalyzeResponse | null
  analyzing: boolean
  profileName: string | null
  onUpload: (file: File) => void
  onClear: () => void
  onNext: () => void
  onBack: () => void
}

export function StepSchematic({
  file,
  analysis,
  analyzing,
  profileName,
  onUpload,
  onClear,
  onNext,
  onBack,
}: StepSchematicProps) {
  const { toast } = useToast()
  const fileRef = useRef<HTMLInputElement>(null)
  const [dragOver, setDragOver] = useState(false)

  const counts = new Map<PaletteStatus, number>()
  if (analysis) {
    for (const item of analysis.palette) {
      counts.set(item.status, (counts.get(item.status) ?? 0) + 1)
    }
  }

  return (
    <Card className="border-[#1c2b58] bg-[#0b1430]/70 backdrop-blur-xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-[#e6ecff]">
          <span className="text-[#7ea6ff]">②</span> Схема
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div
          className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-8 transition-colors ${
            dragOver ? 'border-[#7ea6ff] bg-[#7ea6ff]/10' : 'border-[#233466] hover:border-[#4a63a8]'
          }`}
          onDragOver={(e) => {
            e.preventDefault()
            setDragOver(true)
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault()
            setDragOver(false)
            const f = e.dataTransfer.files?.[0]
            if (f) onUpload(f)
          }}
          onClick={() => fileRef.current?.click()}
        >
          {file ? (
            <>
              <p className="font-mono text-sm text-[#67e0ff]">{file.name}</p>
              <p className="text-xs text-[#5a6b99]">{(file.size / 1024).toFixed(1)} КБ — нажми, чтобы заменить</p>
            </>
          ) : (
            <>
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" className="text-[#7ea6ff]">
                <path
                  d="M4 4h7l2 2h7a1 1 0 011 1v11a1 1 0 01-1 1H4a1 1 0 01-1-1V5a1 1 0 011-1z"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinejoin="round"
                />
              </svg>
              <p className="text-sm text-[#c9d6f5]">Перетащи схему или нажми</p>
              <p className="text-xs text-[#5a6b99]">.litematic · .schem · .schematic</p>
            </>
          )}
          <input
            ref={fileRef}
            type="file"
            accept=".litematic,.schem,.schematic"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0]
              if (f) onUpload(f)
              e.target.value = ''
            }}
          />
        </div>

        {analyzing && <p className="text-center text-sm text-[#8fa1c9]">Разбираю палитру...</p>}

        {analysis && !analyzing && (
          <div className="space-y-4 rounded-xl border border-[#1c2b58] bg-[#0a1128]/60 p-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="border-[#7ea6ff]/40 bg-[#7ea6ff]/10 text-[#9dc2ff]">
                {FORMAT_LABEL[analysis.format]}
              </Badge>
              <p className="text-sm font-medium text-[#e6ecff]">{analysis.title}</p>
              {analysis.author && <p className="text-xs text-[#5a6b99]">от {analysis.author}</p>}
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-4">
              <div className="rounded-lg bg-[#0a1128] p-2 text-center">
                <p className="font-mono text-lg text-[#e6ecff]">
                  {analysis.width}×{analysis.height}×{analysis.length}
                </p>
                <p className="text-xs text-[#5a6b99]">размер (X·Y·Z)</p>
              </div>
              <div className="rounded-lg bg-[#0a1128] p-2 text-center">
                <p className="font-mono text-lg text-[#e6ecff]">{analysis.totalBlocks.toLocaleString('ru-RU')}</p>
                <p className="text-xs text-[#5a6b99]">блоков</p>
              </div>
              <div className="rounded-lg bg-[#0a1128] p-2 text-center">
                <p className="font-mono text-lg text-[#e6ecff]">{analysis.palette.length}</p>
                <p className="text-xs text-[#5a6b99]">типов блоков</p>
              </div>
              <div className="rounded-lg bg-[#0a1128] p-2 text-center">
                <p className="font-mono text-lg text-[#e6ecff]">{analysis.regionCount}</p>
                <p className="text-xs text-[#5a6b99]">регионов</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[...counts.entries()]
                .sort((a, b) => b[1] - a[1])
                .map(([status, n]) => (
                  <Badge key={status} variant="outline" className={STATUS_META[status].cls} title={STATUS_META[status].hint}>
                    {STATUS_META[status].label}: {n}
                  </Badge>
                ))}
            </div>
            {(counts.get('manual') ?? 0) > 0 && (
              <p className="text-sm text-amber-300">
                Есть блоки без замены ({counts.get('manual')} шт.) — выбери замены на следующем шаге.
              </p>
            )}
            {(counts.get('review') ?? 0) > 0 && !profileName && (
              <p className="text-sm text-orange-300">
                В схеме числовые ID модов, а профиль сборки не выбран — невозможно проверить, что ID совпадают с твоей сборкой.
              </p>
            )}
          </div>
        )}

        {file && (
          <div className="flex items-center justify-between">
            <Button variant="outline" className="border-[#2a3c74] bg-transparent text-[#9db4e8] hover:bg-[#13204a]" onClick={onBack}>
              ← Профиль
            </Button>
            <div className="flex gap-2">
              <Button variant="outline" className="border-[#2a3c74] bg-transparent text-[#9db4e8] hover:bg-[#13204a]" onClick={onClear}>
                Сбросить
              </Button>
              <Button className="bg-[#2c4d9e] text-white hover:bg-[#3a5fc0]" disabled={!analysis} onClick={onNext}>
                К маппингу →
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
