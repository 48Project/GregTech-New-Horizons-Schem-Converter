/**
 * Диагностика формата .schem от shulkr.com (angel-statue.schem):
 * полный дамп NBT-дерева с типами + проверка гипотезы:
 *   Blocks = List<String> (палитра-списком), Data = byteArray индексов.
 */
import { readFileSync } from 'node:fs'
import { parseNbt, type NbtTag } from '../src/lib/nbt'

const ROOT = dirname(new URL(import.meta.url).pathname)
const file = process.argv[2] ?? join(ROOT, '..', 'upload', 'angel-statue.schem')

import { dirname, join } from 'node:path'

function typeName(t: number): string {
  return (
    [
      'End',
      'Byte',
      'Short',
      'Int',
      'Long',
      'Float',
      'Double',
      'ByteArray',
      'String',
      'List',
      'Compound',
      'IntArray',
      'LongArray',
    ][t] ?? `type${t}`
  )
}

function dump(k: string, v: NbtTag, depth: number) {
  const pad = '  '.repeat(depth)
  switch (v.type) {
    case 1:
    case 2:
    case 3:
    case 5:
    case 6:
      console.log(`${pad}${k}: ${typeName(v.type)} = ${v.value}`)
      break
    case 4:
      console.log(`${pad}${k}: Long = ${v.value}`)
      break
    case 7: {
      console.log(`${pad}${k}: ByteArray[${v.value.length}]`)
      const hist = new Map<number, number>()
      for (const b of v.value) hist.set(b, (hist.get(b) ?? 0) + 1)
      const entries = [...hist.entries()].sort((a, b) => a[0] - b[0])
      console.log(
        `${pad}  значения (val:count): ${entries
          .slice(0, 60)
          .map(([b, c]) => `${b}:${c}`)
          .join(' ')}`,
      )
      break
    }
    case 8:
      console.log(`${pad}${k}: String = ${JSON.stringify(v.value)}`)
      break
    case 9: {
      console.log(`${pad}${k}: List<${typeName(v.itemType)}>[${v.value.length}]`)
      v.value.slice(0, 80).forEach((it, i) => {
        if (it.type === 8) console.log(`${pad}  [${i}] ${JSON.stringify(it.value)}`)
        else dump(`[${i}]`, it, depth + 1)
      })
      if (v.value.length > 80) console.log(`${pad}  ... ещё ${v.value.length - 80}`)
      break
    }
    case 10:
      console.log(`${pad}${k}: Compound`)
      for (const [k2, v2] of Object.entries(v.value)) dump(k2, v2, depth + 1)
      break
    case 11:
      console.log(
        `${pad}${k}: IntArray[${v.value.length}] = ${[...v.value].slice(0, 10).join(', ')}...`,
      )
      break
    case 12:
      console.log(`${pad}${k}: LongArray[${v.value.length}]`)
      break
  }
}

const data = new Uint8Array(readFileSync(file))
console.log(`=== ${file} (${data.length} байт) ===`)
const preferLE = process.argv[3] !== 'be'
const nbt = parseNbt(data, preferLE)
const root = (nbt.root as { type: 10; value: Record<string, NbtTag> }).value
console.log(`rootName = ${JSON.stringify(nbt.rootName)}, littleEndian = ${nbt.littleEndian}`)
for (const [k, v] of Object.entries(root)) dump(k, v, 1)

/* --- проверка гипотезы: Data[byteArray] — индексы в Blocks[List<String>] --- */
const w = (root.Width as { value: number } | undefined)?.value
const h = (root.Height as { value: number } | undefined)?.value
const l = (root.Length as { value: number } | undefined)?.value
const blocksTag = root.Blocks
const dataTag = root.Data
if (w && h && l && blocksTag?.type === 9 && dataTag?.type === 7) {
  const palette = blocksTag.value.map((t) => (t as { value: string }).value)
  const vol = w * h * l
  console.log(`\n--- ГИПОТЕЗА ---`)
  console.log(
    `W×H×L = ${w}×${h}×${l} = ${vol}; Data.length = ${dataTag.value.length}; палитра = ${palette.length}`,
  )
  console.log(`совпадает объём: ${dataTag.value.length === vol}`)
  // air — обычно индекс 0; сравним долю «0» в нижнем слое (y=0) и верхнем (y=h-1):
  const idxOfAir = palette.findIndex((p) => p === 'minecraft:air')
  const layer = w * l
  const airFrac = (y: number) => {
    let zero = 0
    for (let i = y * layer; i < (y + 1) * layer; i++)
      if (dataTag.value[i] === idxOfAir) zero++
    return zero / layer
  }
  console.log(
    `доля air в слое y=0: ${(airFrac(0) * 100).toFixed(1)}%, в слое y=${h - 1}: ${(
      airFrac(h - 1) * 100
    ).toFixed(1)}%`,
  )
  // максимальный индекс в Data vs размер палитры
  let maxIdx = 0
  for (const b of dataTag.value) if (b > maxIdx) maxIdx = b
  console.log(`макс. индекс в Data = ${maxIdx} (беззнаковый), палитра = ${palette.length}`)
  // укороченный дамп палитры для сверки с логом сервера
  console.log(`палитра: ${palette.map((p, i) => `${i}=${p}`).join(' | ')}`)
}
