/**
 * Inverts WorldEdit's legacy.json (legacyId:meta -> modern state string)
 * into modern-block-name -> [{id, meta, props}] lookup table.
 * Source: EngineHub/WorldEdit version/7.3.x worldedit-core resources
 * (com/sk89q/worldedit/world/registry/legacy.json)
 */
import fs from 'node:fs'
import path from 'node:path'

const REF = path.resolve('scripts/refs/legacy.json')
const OUT = path.resolve('src/lib/data/legacy-blocks.json')

const src = JSON.parse(fs.readFileSync(REF, 'utf8'))
const blocks = src.blocks // { "id:meta": "minecraft:name[k=v,...]" }

/** parse "minecraft:oak_log[axis=y]" -> { name, props } */
function parseState(s) {
  let name = s
  let props = {}
  const i = s.indexOf('[')
  if (i >= 0) {
    name = s.slice(0, i)
    const inner = s.slice(i + 1, s.length - 1)
    if (inner) {
      for (const kv of inner.split(',')) {
        const eq = kv.indexOf('=')
        if (eq > 0) props[kv.slice(0, eq)] = kv.slice(eq + 1)
      }
    }
  }
  if (!name.startsWith('minecraft:')) {
    // modded entries in WE's table are unexpected; skip
    return null
  }
  return { name: name.slice('minecraft:'.length), props }
}

const table = {}
let count = 0
for (const [key, stateStr] of Object.entries(blocks)) {
  const ci = key.indexOf(':')
  if (ci < 0) continue
  const id = parseInt(key.slice(0, ci), 10)
  const meta = parseInt(key.slice(ci + 1), 10)
  if (!Number.isFinite(id) || !Number.isFinite(meta)) continue
  const parsed = parseState(stateStr)
  if (!parsed) continue
  if (!table[parsed.name]) table[parsed.name] = []
  table[parsed.name].push({ id, meta, props: parsed.props })
  count++
}

fs.mkdirSync(path.dirname(OUT), { recursive: true })
fs.writeFileSync(OUT, JSON.stringify(table))
const names = Object.keys(table).length
console.log(`entries: ${count}, modern names: ${names}`)

// sanity checks
const mustHave = ['stone', 'oak_log', 'oak_stairs', 'white_wool', 'chest', 'oak_planks', 'smooth_stone_slab', 'petrified_oak_slab', 'oak_slab', 'white_terracotta', 'oak_door', 'ladder', 'wall_torch', 'sandstone', 'red_sandstone', 'granite', 'polished_andesite', 'slime_block', 'glazed_terracotta', 'white_concrete', 'observer', 'sea_lantern', 'prismarine']
for (const n of mustHave) {
  console.log(table[n] ? `OK  ${n} -> ${JSON.stringify(table[n][0])}` : `MISS ${n}`)
}
