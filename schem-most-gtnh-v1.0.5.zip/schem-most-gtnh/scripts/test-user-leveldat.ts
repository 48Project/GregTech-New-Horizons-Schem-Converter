/**
 * Диагностика реального level.dat пользователя (run: bun scripts/test-user-leveldat.ts)
 * Прогоняет parseLevelDat, при ошибке падает с полным стектрейсом и диагностикой.
 */
import { readFileSync } from 'fs'
import { join, dirname } from 'path'

import { parseNbt, getCompound, getString, getList, decompressAuto, type NbtTag } from '@/lib/nbt'
import { parseLevelDat } from '@/lib/mc/leveldat'

const FILE = join(dirname(import.meta.dir), 'upload', 'level.dat')
const raw = new Uint8Array(readFileSync(FILE))
console.log('file size:', raw.length, 'bytes')

// 1) Полный прогон парсера профиля
try {
  const info = parseLevelDat(raw)
  console.log('OK: levelName =', info.levelName)
  console.log('mods:', info.modCount, '| blocks:', info.blockCount)
  const top = Object.entries(info.mods).sort((a, b) => b[1] - a[1]).slice(0, 15)
  console.log('top mods:', top.map(([m, n]) => `${m}:${n}`).join(', '))
  const mc = Object.entries(info.blocks).filter(([k]) => k.startsWith('minecraft:')).length
  const modded = Object.entries(info.blocks).filter(([k]) => !k.startsWith('minecraft:')).length
  console.log('minecraft blocks:', mc, '| modded blocks:', modded)
  const ids = Object.values(info.blocks)
  console.log('id range:', Math.min(...ids), '..', Math.max(...ids))
} catch (e) {
  console.error('parseLevelDat FAILED:', e instanceof Error ? e.stack : e)
  // 2) Диагностика руками
  try {
    const nbt = parseNbt(raw, false)
    const root = (nbt.root as { type: 10; value: Record<string, NbtTag> }).value
    console.log('root keys:', Object.keys(root))
    const dataTag = getCompound(root, 'Data')
    console.log('Data keys:', dataTag ? Object.keys(dataTag).join(', ') : 'MISSING')
    if (dataTag) {
      console.log('LevelName:', getString(dataTag, 'LevelName'))
      const fml = getCompound(dataTag, 'FML')
      console.log('FML keys:', fml ? Object.keys(fml).join(', ') : 'MISSING')
      if (fml) {
        const itemData = getList(fml, 'ItemData')
        console.log('ItemData length:', itemData?.length ?? 'MISSING')
        if (itemData) {
          console.log('first 5 entries:')
          for (const entry of itemData.slice(0, 5)) {
            if (entry.type === 10) {
              const k = getString(entry.value, 'K')
              const v = entry.value.V
              console.log('  K =', JSON.stringify(k), 'V =', v)
            } else {
              console.log('  unexpected entry type', entry.type)
            }
          }
        }
      }
    }
  } catch (e2) {
    console.error('parseNbt also failed:', e2 instanceof Error ? e2.stack : e2)
    const dec = decompressAuto(raw)
    console.log('decompressed size:', dec.length, 'first bytes:', Array.from(dec.slice(0, 8)))
  }
  process.exit(1)
}
