/**
 * Edge-case тесты detectAndParse (v1.0.4):
 * генерирует кривые/нестандартные файлы в scripts/fixtures/edge/
 * и проверяет, что каждый даёт ПОНЯТНУЮ ошибку (или парсится, если должен).
 */
import { writeFileSync, mkdirSync, readFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import * as nodeZlib from 'node:zlib'
import { writeNbt, tag } from '../src/lib/nbt'
import { detectAndParse } from '../src/lib/mc/formats'

const ROOT = dirname(new URL(import.meta.url).pathname)
const EDGE = join(ROOT, 'fixtures', 'edge')
mkdirSync(EDGE, { recursive: true })

/* --- 1. structure block .nbt (vanilla) --- */
{
  const root = tag.compound({
    size: tag.list(3, [tag.int(3), tag.int(2), tag.int(3)]),
    palette: tag.list(10, [
      tag.compound({ Name: tag.string('minecraft:stone') }),
      tag.compound({ Name: tag.string('minecraft:dirt') }),
    ]),
    blocks: tag.list(10, [
      tag.compound({ state: tag.int(0), pos: tag.list(3, [tag.int(0), tag.int(0), tag.int(0)]) }),
      tag.compound({ state: tag.int(1), pos: tag.list(3, [tag.int(1), tag.int(0), tag.int(0)]) }),
    ]),
    DataVersion: tag.int(2975),
  })
  writeFileSync(join(EDGE, 'structure_block.nbt'), writeNbt('', root))
}

/* --- 2. Bedrock .mcstructure --- */
{
  const root = tag.compound({
    format_version: tag.int(1),
    size: tag.list(3, [tag.int(3), tag.int(3), tag.int(3)]),
    structure: tag.compound({
      block_indices: tag.list(9, [tag.list(3, [tag.int(1), tag.int(1), tag.int(1)])]),
      palette: tag.compound({ default: tag.compound({ block_palette: tag.list(10, []) }) }),
    }),
    structure_world_origin: tag.list(6, [tag.double(0), tag.double(0), tag.double(0)]),
  })
  writeFileSync(join(EDGE, 'bedrock.mcstructure'), writeNbt('', root, { littleEndian: true, gzip: false }))
}

/* --- 3. старый .litematic (BlockStates = byte array varint, 1.12–1.15) --- */
{
  const palette = [
    tag.compound({ Name: tag.string('minecraft:air') }),
    tag.compound({ Name: tag.string('minecraft:stone') }),
    tag.compound({ Name: tag.string('minecraft:oak_planks') }),
  ]
  // объём 3x2x3 = 18 ячеек: индексы палитры как varint (все < 128 → 1 байт)
  const cells = [0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 2, 2, 1, 0, 0, 1, 1]
  const root = tag.compound({
    Version: tag.int(4),
    MinecraftDataVersion: tag.int(1519),
    Metadata: tag.compound({ Name: tag.string('Old Format Farm'), Author: tag.string('masa') }),
    Regions: tag.compound({
      Main: tag.compound({
        Position: tag.compound({ x: tag.int(0), y: tag.int(0), z: tag.int(0) }),
        Size: tag.compound({ x: tag.int(3), y: tag.int(2), z: tag.int(3) }),
        BlockStatePalette: tag.list(10, palette),
        BlockStates: tag.byteArray(new Uint8Array(cells)),
        TileEntities: tag.list(10, []),
        Entities: tag.list(10, []),
      }),
    }),
  })
  writeFileSync(join(EDGE, 'old_format.litematic'), writeNbt('', root, { littleEndian: true }))
}

/* --- 4. несжатый .litematic с long-array BlockStates --- */
{
  // long array вручную: значения [0,1,1,0] по 2 бита в одном long:
  // cell1=1 → 1<<2=4, cell2=1 → 1<<4=16, итого 20
  const longVal = { length: 1, lo: () => 20, hi: () => 0, big: () => BigInt(20) }
  const root = tag.compound({
    Version: tag.int(5),
    Metadata: tag.compound({ Name: tag.string('Uncompressed') }),
    Regions: tag.compound({
      Main: tag.compound({
        Position: tag.compound({ x: tag.int(0), y: tag.int(0), z: tag.int(0) }),
        Size: tag.compound({ x: tag.int(2), y: tag.int(1), z: tag.int(2) }),
        BlockStatePalette: tag.list(10, [
          tag.compound({ Name: tag.string('minecraft:air') }),
          tag.compound({ Name: tag.string('minecraft:stone') }),
        ]),
        BlockStates: { type: 12, value: longVal } as never,
        TileEntities: tag.list(10, []),
        Entities: tag.list(10, []),
      }),
    }),
  })
  writeFileSync(join(EDGE, 'uncompressed.litematic'), writeNbt('', root, { littleEndian: true, gzip: false }))
}

/* --- 5. zstd .schem (если Node умеет) --- */
const zstdC = (nodeZlib as unknown as { zstdCompressSync?: (d: Uint8Array) => Buffer }).zstdCompressSync
if (typeof zstdC === 'function') {
  const gz = readFileSync(join(ROOT, 'fixtures', 'test_house.schem'))
  const raw = nodeZlib.gunzipSync(gz)
  writeFileSync(join(EDGE, 'zstd_house.schem'), new Uint8Array(zstdC(new Uint8Array(raw))))
} else {
  console.log('(!) эта Node не умеет zstdCompressSync — zstd-тест пропущен')
}

/* --- 6. текстовый «файл» (HTML вместо схемы) --- */
writeFileSync(join(EDGE, 'fake_download.html'), '<html><body>404 not found</body></html>')

/* --- 7. пустой файл --- */
writeFileSync(join(EDGE, 'empty.litematic'), new Uint8Array(0))

/* --- 8. битый gzip --- */
{
  const ok = readFileSync(join(ROOT, 'fixtures', 'test_house.litematic'))
  writeFileSync(join(EDGE, 'truncated.litematic'), ok.subarray(0, 25))
}

/* --- 9. sponge v3 «shulkr-стиль»: вложенный Blocks{Palette,Data} --- */
/* shulkr.com пишет .schem v3 в big-endian; cells 2x2x3 = 12 */
{
  const cells = [0, 1, 1, 0, 1, 2, 0, 1, 1, 0, 0, 1]
  const schematic = tag.compound({
    Version: tag.int(3),
    DataVersion: tag.int(5023),
    Width: tag.short(2),
    Height: tag.short(2),
    Length: tag.short(3),
    Metadata: tag.compound({ Name: tag.string('Shulkr-ish Cube'), Author: tag.string('ggia') }),
    Blocks: tag.compound({
      Palette: tag.compound({
        'minecraft:air': tag.int(0),
        'minecraft:stone_bricks': tag.int(1),
        'minecraft:dark_oak_leaves[persistent=true]': tag.int(2),
      }),
      Data: tag.byteArray(new Uint8Array(cells)),
      BlockEntities: tag.list(10, []),
    }),
  })
  const root = tag.compound({ Schematic: schematic })
  writeFileSync(join(EDGE, 'shulkr_v3_be.schem'), writeNbt('', root, { littleEndian: false }))
  writeFileSync(join(EDGE, 'shulkr_v3_le.schem'), writeNbt('', root, { littleEndian: true }))
}

/* --- прогон --- */
type Expect = 'ok' | { failIncludes: string }
const cases: Array<{ file: string; expect: Expect }> = [
  { file: 'structure_block.nbt', expect: { failIncludes: 'structure block' } },
  { file: 'bedrock.mcstructure', expect: { failIncludes: 'Bedrock' } },
  { file: 'old_format.litematic', expect: 'ok' },
  { file: 'uncompressed.litematic', expect: 'ok' },
  { file: 'zstd_house.schem', expect: 'ok' },
  { file: 'fake_download.html', expect: { failIncludes: 'текстовый файл' } },
  { file: 'empty.litematic', expect: { failIncludes: 'пустой' } },
  { file: 'truncated.litematic', expect: { failIncludes: 'gzip' } },
  { file: 'pack.zip', expect: { failIncludes: 'ZIP' } },
  { file: 'shulkr_v3_be.schem', expect: 'ok' },
  { file: 'shulkr_v3_le.schem', expect: 'ok' },
]

let fails = 0
for (const c of cases) {
  if (c.file === 'zstd_house.schem' && typeof zstdC !== 'function') continue
  const path = join(EDGE, c.file)
  let data: Uint8Array
  try {
    data = new Uint8Array(readFileSync(path))
  } catch {
    if (c.file === 'pack.zip') continue
    throw new Error(`нет файла ${path}`)
  }
  const res = detectAndParse(data, c.file)
  if (c.expect === 'ok') {
    if (res.ok) {
      console.log(`OK    ${c.file} → [${res.format}] ${res.sch.width}x${res.sch.height}x${res.sch.length}, блоков ${res.sch.totalBlocks}, палитра ${res.sch.palette.length}`)
    } else {
      fails++
      console.log(`FAIL  ${c.file} — ожидался успех, получена ошибка:`)
      console.log(`      ${res.error}`)
      for (const d of res.details) console.log(`      · ${d}`)
    }
  } else {
    const want = (c.expect as { failIncludes: string }).failIncludes
    if (!res.ok && res.error.toLowerCase().includes(want.toLowerCase())) {
      console.log(`OK    ${c.file} → внятная ошибка: ${res.error.slice(0, 90)}...`)
    } else {
      fails++
      console.log(`FAIL  ${c.file} — ожидалась ошибка с «${want}», получено:`)
      console.log(`      ${res.ok ? 'успех (?!)' : res.error}`)
      if (!res.ok) for (const d of res.details) console.log(`      · ${d}`)
    }
  }
}
console.log(fails === 0 ? '\nВсе edge-кейсы отработали как надо.' : `\n${fails} ПРОВАЛОВ`)
process.exit(fails === 0 ? 0 : 1)
