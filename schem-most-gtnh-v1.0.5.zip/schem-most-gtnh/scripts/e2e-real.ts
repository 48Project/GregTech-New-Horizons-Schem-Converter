/**
 * Real-world fixture calibration (run: bun scripts/e2e-real.ts)
 * Parses every downloaded real .litematic, analyzes the palette against the
 * synthetic GTNH profile, converts with defaults+suggestions, re-parses.
 */
import { readFileSync, writeFileSync, readdirSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'

import { detectAndParse } from '@/lib/mc/formats'
import { parseLevelDat } from '@/lib/mc/leveldat'
import { analyzePalette, type PaletteStatus } from '@/lib/mc/mapper'
import { convertSchematic, type Decision } from '@/lib/mc/convert'
import { parseLegacySchematic } from '@/lib/mc/legacy'

const REAL = join(dirname(import.meta.dir), 'scripts', 'fixtures', 'real')
const OUT = join(REAL, 'out')
mkdirSync(OUT, { recursive: true })

// Профиль: реальный level.dat пользователя (если загружен в upload/),
// иначе синтетический фикстур.
import { existsSync } from 'fs'
const USER_LEVELDAT = join(dirname(import.meta.dir), 'upload', 'level.dat')
const LEVELDAT = existsSync(USER_LEVELDAT) ? USER_LEVELDAT : join(dirname(import.meta.dir), 'scripts', 'fixtures', 'test_level.dat')
console.log('profile level.dat:', LEVELDAT)
const profile = parseLevelDat(new Uint8Array(readFileSync(LEVELDAT)))

const files = readdirSync(REAL).filter((f) => /\.(litematic|schem|schematic)$/.test(f)).sort()
let totalFails = 0

for (const file of files) {
  console.log(`\n### ${file}`)
  const raw = new Uint8Array(readFileSync(join(REAL, file)))
  const parsed = detectAndParse(raw, file)
  if (!parsed.ok) {
    console.error('  PARSE FAILED:', parsed.error)
    totalFails++
    continue
  }
  const sch = parsed.sch
  console.log(`  ${sch.width}x${sch.height}x${sch.length}, ${sch.totalBlocks} blocks, ${sch.regionCount} region(s), "${sch.title}" by ${sch.author ?? '?'}`)

  const analysis = analyzePalette(sch, profile)
  const dist: Record<string, number> = {}
  for (const a of analysis) dist[a.status] = (dist[a.status] ?? 0) + 1
  console.log('  statuses:', JSON.stringify(dist))

  // show interesting entries (not auto/air)
  for (const a of analysis) {
    if (a.status === 'auto' || a.status === 'air') continue
    console.log(`    ${a.status.padEnd(8)} ${a.key}  ->  ${a.targetLabel ?? '???'}  (${a.count}x)  ${a.reason ?? ''}`)
  }

  // convert: default decisions + accept all suggestions
  const decisions: Record<string, Decision> = {}
  const unresolved = analysis.filter((a) => a.status === 'manual')
  for (const u of unresolved) {
    decisions[u.key] = { kind: 'air' } // manual -> air just for the calibration run
  }
  const conv = convertSchematic(sch, analysis, decisions)
  if (conv.unresolved.length) {
    console.error('  UNRESOLVED:', conv.unresolved)
    totalFails++
  }
  const outName = file.replace(/\.(litematic|schem|schematic)$/, '.schematic')
  writeFileSync(join(OUT, outName), conv.file)

  // re-parse and verify (expected solid count = materials sum: air decisions
  // legitimately remove blocks, so compare against conv.totalBlocks, not sch)
  const back = parseLegacySchematic(new Uint8Array(conv.file))
  const okDims =
    back.width === sch.width && back.height === sch.height && back.length === sch.length
  const okBlocks = back.totalBlocks === conv.totalBlocks
  console.log(`  converted: ${conv.materials.length} materials, ${conv.totalBlocks}/${sch.totalBlocks} solid blocks (dropped ${sch.totalBlocks - conv.totalBlocks} by air decisions); re-parse dims=${okDims ? 'OK' : 'FAIL'} blocks=${okBlocks ? 'OK' : 'FAIL'}`)
  if (!okDims || !okBlocks) totalFails++
}

console.log(`\n${files.length} files, ${totalFails} failures`)
if (totalFails > 0) process.exit(1)
console.log('REAL-WORLD CALIBRATION PASSED')
