#!/usr/bin/env python3
"""
Test fixtures for the GTNH schematic converter pipeline.

Generates:
  scripts/fixtures/test_house.litematic       -- single region, 14x9x14:
      vanilla auto-mapped blocks, stateful blocks (log axis, stairs, door, slabs,
      wall torch), 1.8+ blocks that need suggestions (concrete, deepslate, copper,
      sea lantern, polished granite), modded blocks in/out of the pack profile.
  scripts/fixtures/test_multiregion.litematic -- two regions, one with NEGATIVE Size.x
      (tests litematica coordinate flipping), stripped log alias, diorite suggestion.
  scripts/fixtures/test_level.dat             -- synthetic Forge 1.7.10 (GTNH-like)
      world file with FML ItemData ID map: vanilla 1.7.10 ids 0..175 +
      ~140 modded registry entries (chisel/gregtech/IC2/forestry/railcraft/...).

The level.dat is structurally identical to a real GTNH world save level.dat
(gzipped big-endian NBT, Data.FML.ItemData list of {K,V} compounds,
K = "\x01" + registry name for blocks, "\x02" for items).
"""
import os

from litemapy import Schematic, Region, BlockState
from nbt.nbt import NBTFile, TAG_Compound, TAG_String, TAG_Int, TAG_List, TAG_Long

OUT = os.path.join(os.path.dirname(__file__))
os.makedirs(OUT, exist_ok=True)

# --------------------------------------------------------------------------
# 1. test_house.litematic -- the "modern cottage" with every interesting case
# --------------------------------------------------------------------------
W, H, L = 14, 9, 14
r = Region(0, 0, 0, W, H, L)

def put(x, y, z, state):
    r[x, y, z] = state

stone = BlockState("minecraft:stone")
planks = BlockState("minecraft:oak_planks")
cobble = BlockState("minecraft:cobblestone")
glass = BlockState("minecraft:glass")
marble = BlockState("chisel:marble")

# floor: oak planks inside, stone border
for x in range(W):
    for z in range(L):
        border = x < 2 or x > 11 or z < 2 or z > 11
        put(x, 0, z, stone if border else planks)

# water pool instead of floor corner
for x in (12, 13):
    for z in (12, 13):
        put(x, 0, z, BlockState("minecraft:water"))

# marble inlay 2x2 in the middle of the floor; one cell is a GT casing
# (id > 255 in the profile -> exercises the legacy AddBlocks nibble array)
for x in (6, 7):
    for z in (6, 7):
        put(x, 0, z, marble)
put(7, 0, 7, BlockState("gregtech:gt.blockmultiblockcasing"))

# walls y=1..4
for y in range(1, 5):
    for x in range(2, 12):
        put(x, y, 2, cobble)
        put(x, y, 11, cobble)
    for z in range(2, 12):
        put(2, y, z, cobble)
        put(11, y, z, cobble)

# vertical logs in corners (axis=y)
for cx, cz in ((2, 2), (2, 11), (11, 2), (11, 11)):
    for y in range(1, 5):
        put(cx, y, cz, BlockState("minecraft:oak_log", axis="y"))

# windows (north wall z=2)
put(4, 2, 2, glass)
put(9, 2, 2, glass)
put(7, 2, 2, BlockState("minecraft:glass_pane"))

# door (lower+upper, facing south, hinge left)
put(6, 1, 2, BlockState("minecraft:oak_door", half="lower", facing="south", hinge="left", open="false", powered="false"))
put(6, 2, 2, BlockState("minecraft:oak_door", half="upper", facing="south", hinge="left", open="false", powered="false"))

# modern-style stripe on the east wall (blocks that don't exist in 1.7.10)
for z in range(4, 9):
    put(11, 1, z, BlockState("minecraft:white_concrete"))
    put(11, 2, z, BlockState("minecraft:light_blue_concrete"))
    put(11, 3, z, BlockState("minecraft:cut_copper"))

# deepslate pillar outside
for y in (1, 2, 3):
    put(13, y, 0, BlockState("minecraft:deepslate"))

# polished granite boulder by the pool
put(0, 1, 13, BlockState("minecraft:polished_granite"))
put(0, 2, 13, BlockState("minecraft:polished_granite"))

# roof: bottom slabs, top-slab edge row on z=11
for x in range(2, 12):
    for z in range(2, 12):
        put(x, 5, z, BlockState("minecraft:oak_slab", type="top") if z == 11 else BlockState("minecraft:oak_slab", type="bottom"))

# sea lantern as roof lamp
put(6, 5, 6, BlockState("minecraft:sea_lantern"))

# interior horizontal beams (rotation preservation!)
for z in range(4, 9):
    put(4, 4, z, BlockState("minecraft:oak_log", axis="z"))
for x in range(3, 11):
    put(x, 4, 6, BlockState("minecraft:oak_log", axis="x"))

# interior furniture
put(4, 1, 4, BlockState("minecraft:chest", facing="north", type="single"))
put(9, 1, 9, BlockState("gregtech:gt.blockmachines"))
put(5, 1, 5, BlockState("minecraft:torch"))
put(3, 2, 6, BlockState("minecraft:wall_torch", facing="east"))
put(5, 1, 3, BlockState("minecraft:oak_stairs", facing="south", half="bottom", shape="straight"))
put(7, 3, 3, BlockState("minecraft:oak_stairs", facing="east", half="top", shape="straight"))
put(3, 1, 9, BlockState("minecraft:oak_slab", type="bottom"))
put(7, 3, 7, BlockState("twerk:warp_drive"))  # modded, NOT in the pack profile -> manual

# short grass outside (1.20.3+ rename of "grass")
for gx, gz in ((1, 3), (1, 7), (3, 13), (9, 13)):
    put(gx, 1, gz, BlockState("minecraft:short_grass"))

schem = Schematic(
    name="GTNH Test Cottage",
    author="z-ai",
    description="fixture: auto/approx/suggest/modmeta/manual palette cases",
    regions={"Main Region": r},
)
path = os.path.join(OUT, "test_house.litematic")
schem.save(path)
print("written", path)

# same build as a Sponge v2 .schem (for the sponge parser test)
sponge_file = r.to_sponge_nbt()
path = os.path.join(OUT, "test_house.schem")
sponge_file.save(path, gzipped=True)
print("written", path)

# --------------------------------------------------------------------------
# 2. test_multiregion.litematic -- negative-size region + offsets
# --------------------------------------------------------------------------
main = Region(0, 0, 0, 6, 4, 6)
for x in range(6):
    for z in range(6):
        main[x, 0, z] = planks
        if x in (0, 5) or z in (0, 5):
            for y in range(1, 3):
                main[x, y, z] = cobble

# annex to the east: position 9, size x = -4 -> occupies schematic x 6..9
# with a negative size, REGION coordinates run from width+1 .. 0 (litematica semantics)
annex = Region(9, 0, 0, -4, 3, 4)
for x in range(-3, 1):  # region coords -3..0 -> store 0..3 -> schematic 6..9
    for y in range(3):
        for z in range(4):
            if y == 0:
                annex[x, y, z] = BlockState("minecraft:polished_diorite")
            elif x in (-3, 0) or z in (0, 3):
                annex[x, y, z] = marble
annex[-2, 1, 1] = BlockState("minecraft:stripped_birch_log", axis="z")

schem2 = Schematic(
    name="MultiRegion Annex",
    author="z-ai",
    description="fixture: negative region size + stripped log alias",
    regions={"Main": main, "Annex": annex},
)
path = os.path.join(OUT, "test_multiregion.litematic")
schem2.save(path)
print("written", path)

# --------------------------------------------------------------------------
# 3. test_level.dat -- synthetic Forge 1.7.10 GTNH-like ID map
# --------------------------------------------------------------------------
VANILLA_1710 = {
    "minecraft:air": 0, "minecraft:stone": 1, "minecraft:grass": 2, "minecraft:dirt": 3,
    "minecraft:cobblestone": 4, "minecraft:planks": 5, "minecraft:sapling": 6,
    "minecraft:bedrock": 7, "minecraft:flowing_water": 8, "minecraft:water": 9,
    "minecraft:flowing_lava": 10, "minecraft:lava": 11, "minecraft:sand": 12,
    "minecraft:gravel": 13, "minecraft:gold_ore": 14, "minecraft:iron_ore": 15,
    "minecraft:coal_ore": 16, "minecraft:log": 17, "minecraft:leaves": 18,
    "minecraft:sponge": 19, "minecraft:glass": 20, "minecraft:lapis_ore": 21,
    "minecraft:lapis_block": 22, "minecraft:dispenser": 23, "minecraft:sandstone": 24,
    "minecraft:noteblock": 25, "minecraft:bed": 26, "minecraft:golden_rail": 27,
    "minecraft:detector_rail": 28, "minecraft:sticky_piston": 29, "minecraft:web": 30,
    "minecraft:tallgrass": 31, "minecraft:deadbush": 32, "minecraft:piston": 33,
    "minecraft:piston_head": 34, "minecraft:wool": 35, "minecraft:piston_extension": 36,
    "minecraft:yellow_flower": 37, "minecraft:red_flower": 38, "minecraft:brown_mushroom": 39,
    "minecraft:red_mushroom": 40, "minecraft:gold_block": 41, "minecraft:iron_block": 42,
    "minecraft:double_slab": 43, "minecraft:wooden_slab": 44, "minecraft:brick_block": 45,
    "minecraft:tnt": 46, "minecraft:bookshelf": 47, "minecraft:mossy_cobblestone": 48,
    "minecraft:obsidian": 49, "minecraft:torch": 50, "minecraft:fire": 51,
    "minecraft:mob_spawner": 52, "minecraft:oak_stairs": 53, "minecraft:chest": 54,
    "minecraft:redstone_wire": 55, "minecraft:diamond_ore": 56, "minecraft:diamond_block": 57,
    "minecraft:crafting_table": 58, "minecraft:wheat": 59, "minecraft:farmland": 60,
    "minecraft:furnace": 61, "minecraft:lit_furnace": 62, "minecraft:standing_sign": 63,
    "minecraft:wooden_door": 64, "minecraft:ladder": 65, "minecraft:rail": 66,
    "minecraft:stone_stairs": 67, "minecraft:wall_sign": 68, "minecraft:lever": 69,
    "minecraft:stone_pressure_plate": 70, "minecraft:iron_door": 71,
    "minecraft:wooden_pressure_plate": 72, "minecraft:redstone_ore": 73,
    "minecraft:lit_redstone_ore": 74, "minecraft:unlit_redstone_torch": 75,
    "minecraft:redstone_torch": 76, "minecraft:stone_button": 77, "minecraft:snow_layer": 78,
    "minecraft:ice": 79, "minecraft:snow": 80, "minecraft:cactus": 81, "minecraft:clay": 82,
    "minecraft:reeds": 83, "minecraft:jukebox": 84, "minecraft:fence": 85,
    "minecraft:pumpkin": 86, "minecraft:netherrack": 87, "minecraft:soul_sand": 88,
    "minecraft:glowstone": 89, "minecraft:portal": 90, "minecraft:lit_pumpkin": 91,
    "minecraft:cake": 92, "minecraft:unpowered_repeater": 93, "minecraft:powered_repeater": 94,
    "minecraft:stained_glass": 95, "minecraft:trapdoor": 96, "minecraft:monster_egg": 97,
    "minecraft:stonebrick": 98, "minecraft:brown_mushroom_block": 99,
    "minecraft:red_mushroom_block": 100, "minecraft:iron_bars": 101, "minecraft:glass_pane": 102,
    "minecraft:melon_block": 103, "minecraft:pumpkin_stem": 104, "minecraft:melon_stem": 105,
    "minecraft:vine": 106, "minecraft:fence_gate": 107, "minecraft:brick_stairs": 108,
    "minecraft:stone_brick_stairs": 109, "minecraft:mycelium": 110, "minecraft:waterlily": 111,
    "minecraft:nether_brick": 112, "minecraft:nether_brick_fence": 113,
    "minecraft:nether_brick_stairs": 114, "minecraft:nether_wart": 115,
    "minecraft:enchanting_table": 116, "minecraft:brewing_stand": 117, "minecraft:cauldron": 118,
    "minecraft:end_portal": 119, "minecraft:end_portal_frame": 120, "minecraft:end_stone": 121,
    "minecraft:dragon_egg": 122, "minecraft:redstone_lamp": 123, "minecraft:lit_redstone_lamp": 124,
    "minecraft:double_wooden_slab": 125, "minecraft:wooden_slab2": 126, "minecraft:cocoa": 127,
    "minecraft:sandstone_stairs": 128, "minecraft:emerald_ore": 129, "minecraft:ender_chest": 130,
    "minecraft:tripwire_hook": 131, "minecraft:tripwire": 132, "minecraft:emerald_block": 133,
    "minecraft:command_block": 134, "minecraft:beacon": 135, "minecraft:cobblestone_wall": 136,
    "minecraft:flower_pot": 137, "minecraft:carrots": 138, "minecraft:potatoes": 139,
    "minecraft:wooden_button": 140, "minecraft:skull": 141, "minecraft:anvil": 142,
    "minecraft:trapped_chest": 143, "minecraft:light_weighted_pressure_plate": 144,
    "minecraft:heavy_weighted_pressure_plate": 145, "minecraft:unpowered_comparator": 146,
    "minecraft:powered_comparator": 147, "minecraft:daylight_detector": 148,
    "minecraft:redstone_block": 149, "minecraft:quartz_block": 150, "minecraft:hopper": 151,
    "minecraft:quartz_ore": 152, "minecraft:activator_rail": 153, "minecraft:dropper": 154,
    "minecraft:quartz_stairs": 155, "minecraft:stained_hardened_clay": 159,
    "minecraft:stained_glass_pane": 160, "minecraft:log2": 161, "minecraft:leaves2": 162,
    "minecraft:acacia_stairs": 163, "minecraft:dark_oak_stairs": 164, "minecraft:hay_block": 170,
    "minecraft:carpet": 171, "minecraft:hardened_clay": 172, "minecraft:coal_block": 173,
    "minecraft:packed_ice": 174, "minecraft:double_plant": 175,
}

# GTNH-plausible modded entries (1.7.10 style: one registry id, variants = meta)
MODDED = [
    # Chisel
    ("chisel:marble", 176), ("chisel:marble_pillar", 177), ("chisel:limestone", 178),
    ("chisel:granite", 179), ("chisel:diorite", 180), ("chisel:andesite", 181),
    ("chisel:holystone", 182), ("chisel:serpententine", 183), ("chisel:basalt", 184),
    ("chisel:obsidian", 185), ("chisel:ironblock", 186), ("chisel:goldblock", 187),
    ("chisel:quartz", 188), ("chisel:laboratoryblock", 189),
    # GregTech
    ("gregtech:gt.blockmachines", 190), ("gregtech:gt.blockores", 191),
    ("gregtech:gt.bloccasings", 192), ("gregtech:gt.blockreinforced", 193),
    ("gregtech:gt.blockpipes", 194), ("gregtech:gt.blockstones", 195),
    ("gregtech:gt.blockconcretes", 196), ("gregtech:gt.blockfoams", 197),
    ("gregtech:gt.blockmetals", 198), ("gregtech:gt.blockplants", 199),
    ("gregtech:gt.blockwoodplanks", 200), ("gregtech:gt.blockleggings", 201),
    ("gregtech:gt.blockslabs", 202), ("gregtech:gt.blockstairs", 203),
    ("gregtech:gt.blockwindows", 204), ("gregtech:gt.blockcolors", 205),
    ("gregtech:gt.blocklanterns", 206), ("gregtech:gt.blockcables", 207),
    ("gregtech:gt.blockcircuits", 208), ("gregtech:gt.blockasphalt", 209),
    # IC2
    ("IC2:teblock", 210), ("IC2:blockMachine", 211), ("IC2:blockAlloy", 212),
    ("IC2:blockOre", 213), ("IC2:blockCrop", 214), ("IC2:blockRubWood", 215),
    ("IC2:blockScaffold", 216), ("IC2:blockLumin", 217), ("IC2:blockFoam", 218),
    ("IC2:blockPersonal", 219),
    # Forestry
    ("Forestry:blockSoil", 220), ("Forestry:blockResources", 221),
    ("Forestry:blockApiculture", 222), ("Forestry:blockArboriculture", 223),
    ("Forestry:blockLepidopterology", 224), ("Forestry:blockFactory", 225),
    ("Forestry:blockGears", 226), ("Forestry:blockStairs", 227),
    ("Forestry:fences", 228), ("Forestry:podzol", 229),
    # Railcraft
    ("railcraft:tile.railcraft.machine.alpha", 230),
    ("railcraft:tile.railcraft.machine.beta", 231),
    ("railcraft:tile.railcraft.machine.epsilon", 232),
    ("railcraft:tile.railcraft.machine.zeta", 233),
    ("railcraft:tile.railcraft.cube", 234),
    ("railcraft:tile.railcraft.track", 235),
    ("railcraft:tile.railcraft.track.elevator", 236),
    # Thaumcraft
    ("thaumcraft:blockCustomOre", 240), ("thaumcraft:blockMagicalLog", 241),
    ("thaumcraft:blockMagicalLeaves", 242), ("thaumcraft:blockStone", 243),
    ("thaumcraft:blockWood", 244), ("thaumcraft:blockMetalDevice", 245),
    ("thaumcraft:blockTable", 246), ("thaumcraft:blockCosmeticSolid", 247),
    ("thaumcraft:blockCosmeticOpaque", 248), ("thaumcraft:blockTube", 249),
    # EnderIO
    ("EnderIO:blockAlloySmelter", 250), ("EnderIO:blockStirlingGenerator", 251),
    ("EnderIO:blockCapacitorBank", 252), ("EnderIO:blockPowerMonitor", 253),
    ("EnderIO:blockVacuumChest", 254),
    # Applied Energistics 2
    ("appliedenergistics2:tile.BlockDrive", 260),
    ("appliedenergistics2:tile.BlockChest", 261),
    ("appliedenergistics2:tile.BlockController", 262),
    ("appliedenergistics2:tile.BlockCondenser", 263),
    ("appliedenergistics2:tile.BlockEnergyCell", 264),
    # Tinkers Construct
    ("TConstruct:SearedBlock", 270), ("TConstruct:MetalBlock", 271),
    ("TConstruct:SlimeSand", 272), ("TConstruct:deco.stone", 273),
    ("TConstruct:deco.stone.lavabricks", 274),
    # BiblioCraft
    ("BiblioCraft:BiblioFancyWorkbench", 280), ("BiblioCraft:BiblioBookcase", 281),
    ("BiblioCraft:BiblioShelf", 282), ("BiblioCraft:BiblioClock", 283),
    # Twilight Forest
    ("TwilightForest:tile.TFPlanks", 290), ("TwilightForest:tile.TFLog", 291),
    ("TwilightForest:tile.TFLeaves", 292), ("TwilightForest:tile.TFMazestone", 293),
    ("TwilightForest:tile.TFPlant", 294), ("TwilightForest:tile.TFPortal", 295),
    # misc GTNH mods
    ("Witchery:witchery:witchlog", 300), ("BuildCraft|Factory:block refinery", 301),
    ("BuildCraft|Transport:blockPipe", 302), ("ExtraUtilities:colorful", 303),
    ("ExtraUtilities:generator", 304), ("OpenBlocks:elevator", 305),
    ("StevesCarts:modblockcart", 306), ("gendustry:machine", 307),
    ("bartworks:gt.bwMetaGenerated_01", 310), ("bartworks:gt.bwMetaGenerated_02", 311),
    ("bartworks:gt.bwMetaGenerateda", 312), ("gtplusplus:gtplusplus.blockmachines", 320),
    ("gtplusplus:gtplusplus.blockores", 321), ("GoodGenerator:goodgenerator.blockmachines", 330),
    ("miscutils:mucoxide", 331), ("Tropicraft:tile.TropicraftPlanks", 332),
    ("ProjRed|Core:projectred.core.block", 340), ("ProjRed|Exploration:projectred.exploration.ore", 341),
    ("harvestcraft:pam", 350),
    ("chisel:chisel", 353),
    # high GT ids for realism
    ("gregtech:gtplusplus.blockmachines", 1512), ("gregtech:gtplusplus.blockores", 1513),
    ("gregtech:gt.multiblock_casing", 1514), ("gregtech:gt.blockmultiblockcasing", 1515),
    ("dreamcraft:dreamcraft.block", 1601), ("dreamcraft:tile.block", 1602),
    ("codechicken:codechicken.block", 1610),
]

ITEMS = [
    ("minecraft:stick", 280), ("minecraft:iron_ingot", 265), ("minecraft:gold_ingot", 266),
    ("minecraft:diamond", 264), ("gregtech:gt.metaitem.01", 21000),
    ("gregtech:gt.metaitem.02", 21001), ("IC2:itemMugBoots", 20000),
    ("chisel:chisel_iron", 26000),
]

entries = []
for name, bid in VANILLA_1710.items():
    entries.append(("\x01" + name, bid))
for name, bid in MODDED:
    entries.append(("\x01" + name, bid))
for name, iid in ITEMS:
    entries.append(("\x02" + name, iid))
entries.sort(key=lambda kv: kv[1])

item_data = TAG_List(name="ItemData", type=TAG_Compound)
for key, val in entries:
    e = TAG_Compound()
    e.tags.append(TAG_String(name="K", value=key))
    e.tags.append(TAG_Int(name="V", value=val))
    item_data.tags.append(e)

fml = TAG_Compound(name="FML")
fml.tags.append(item_data)

data = TAG_Compound(name="Data")
data.tags.append(TAG_String(name="LevelName", value="GTNH Test World (synthetic)"))
data.tags.append(TAG_Int(name="version", value=19133))
data.tags.append(TAG_Long(name="RandomSeed", value=8173298173245))
data.tags.append(TAG_Int(name="GameType", value=0))
data.tags.append(TAG_String(name="Level", value="default"))
data.tags.append(fml)

root = NBTFile()
root.name = ""
root.tags.append(data)
path = os.path.join(OUT, "test_level.dat")
root.write_file(path)
print("written", path, os.path.getsize(path), "bytes")

# summary
n_blocks = sum(1 for k, _ in entries if k.startswith("\x01"))
print(f"profile: {n_blocks} blocks, {len(VANILLA_1710)} vanilla + {len(MODDED)} modded")
