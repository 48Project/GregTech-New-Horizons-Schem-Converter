// Обёртка для prisma CLI (npm run db:push / db:generate / ...).
// Зачем: относительный file:-путь в .env Prisma на разных платформах
// резолвит по-разному (от схемы, от cwd), а внешняя переменная окружения
// DATABASE_URL может вообще указывать на устаревший файл. Поэтому задаём
// prisma ЯВНЫЙ абсолютный путь до prisma/custom.db.
import { execSync } from 'node:child_process'
import { join, resolve } from 'node:path'
import { mkdirSync } from 'node:fs'

const root = resolve(process.cwd())
const dbDir = join(root, 'prisma')
mkdirSync(dbDir, { recursive: true })

const url = 'file:' + join(dbDir, 'custom.db').split('\\').join('/')
process.env.DATABASE_URL = url

const args = process.argv.slice(2)
if (args.length === 0) {
  console.error('Использование: node scripts/db.mjs <prisma-args>, например: node scripts/db.mjs db push --accept-data-loss')
  process.exit(1)
}

console.log(`[db.mjs] DATABASE_URL = ${url}`)
execSync(`prisma ${args.join(' ')}`, { stdio: 'inherit', env: { ...process.env }, cwd: root })
