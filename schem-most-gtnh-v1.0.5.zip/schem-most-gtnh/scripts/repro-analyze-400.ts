/** Reproduce the /api/analyze 400: run detectAndParse on every fixture + edge cases. */
import { readFileSync, readdirSync } from 'node:fs'
import { join, dirname } from 'node:path'

const ROOT = dirname(new URL(import.meta.url).pathname)
import { detectAndParse } from '../src/lib/mc/formats'

const dirs = [
  join(ROOT, 'fixtures', 'real'),
  join(ROOT, 'fixtures'),
]
const files: string[] = []
for (const d of dirs) {
  for (const f of readdirSync(d)) {
    if (/\.(litematic|schem|schematic)$/.test(f)) files.push(join(d, f))
  }
}

let fails = 0
for (const f of files) {
  const data = new Uint8Array(readFileSync(f))
  const t0 = performance.now()
  const res = detectAndParse(data, f.split(/[\\/]/).pop() ?? 'x')
  const ms = (performance.now() - t0).toFixed(1)
  if (res.ok) {
    console.log(`OK   ${ms.padStart(7)}ms  ${f.split(/[\\/]/).pop()}  [${res.format}] ${res.sch.width}x${res.sch.height}x${res.sch.length}, regions=${res.sch.regionCount}`)
  } else {
    fails++
    console.log(`FAIL ${ms.padStart(7)}ms  ${f.split(/[\\/]/).pop()}`)
    console.log(`     ${res.error}`)
  }
}
console.log(`\n${files.length} files, ${fails} fails`)
