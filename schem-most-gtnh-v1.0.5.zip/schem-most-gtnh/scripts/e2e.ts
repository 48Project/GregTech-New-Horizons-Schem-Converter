/**
 * End-to-end pipeline test (run: bun scripts/e2e.ts)
 *
 * fixture -> detectAndParse -> analyzePalette (with synthetic GTNH profile)
 *   -> decisions -> convertSchematic -> write legacy .schematic
 *   -> parseLegacySchematic -> verify every critical cell (rotation metas!)
 */
import { readFileSync, writeFileSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'

import { detectAndParse } from '@/lib/mc/formats'
import { parseLevelDat } from '@/lib/mc/leveldat'
import { analyzePalette, type PaletteAnalysisItem } from '@/lib/mc/mapper'
import { convertSchematic, type Decision } from '@/lib/mc/convert'
import { parseLegacySchematic } from '@/lib/mc/legacy'
import { stateKey, parseStateKey, cellIndex, type UnifiedSchematic } from '@/lib/mc/model'

const FIX = join(dirname(import.meta.dir), 'scripts', 'fixtures')
const OUT = join(FIX, 'out')
mkdirSync(OUT, { recursive: true })

let failures = 0
let checks = 0
function ok(cond: boolean, label: string, detail?: unknown) {
  checks++
  if (!cond) {
    failures++
    console.error(`  FAIL ${label}`, detail !== undefined ? `-> ${JSON.stringify(detail)}` : '')
  }
}
function section(name: string) {
  console.log(`\n=== ${name} ===`)
}

/* ------------------------------------------------------------------ */
section('1. level.dat profile (synthetic GTNH)')
const levelRaw = new Uint8Array(readFileSync(join(FIX, 'test_level.dat')))
const profile = parseLevelDat(levelRaw)
ok(profile.levelName === 'GTNH Test World (synthetic)', 'level name', profile.levelName)
ok(profile.blockCount === 291, 'block count', profile.blockCount)
ok(profile.blocks['chisel:marble'] === 176, 'chisel:marble id', profile.blocks['chisel:marble'])
ok(profile.blocks['gregtech:gt.blockmachines'] === 190, 'gt.blockmachines id')
ok(profile.blocks['gregtech:gt.blockmultiblockcasing'] === 1515, 'gt casing id > 255')
ok(profile.byId[176] === 'chisel:marble', 'reverse lookup')
console.log(`  profile: ${profile.blockCount} blocks, ${profile.modCount} mods, level "${profile.levelName}"`)

/* ------------------------------------------------------------------ */
section('2. test_house.litematic parse')
const houseRaw = new Uint8Array(readFileSync(join(FIX, 'test_house.litematic')))
const parsed = detectAndParse(houseRaw, 'test_house.litematic')
ok(parsed.ok, 'detectAndParse ok', parsed.ok ? undefined : parsed.error)
if (!parsed.ok) process.exit(1)
const house = parsed.sch
ok(house.format === 'litematic', 'format', house.format)
ok(house.width === 14 && house.height === 9 && house.length === 14, 'dims 14x9x14', [house.width, house.height, house.length])
ok(house.title === 'GTNH Test Cottage', 'title', house.title)
ok(house.author === 'z-ai', 'author', house.author)
ok(house.totalBlocks === 469, 'total blocks 469 (matches litemapy)', house.totalBlocks)

/* ------------------------------------------------------------------ */
section('3. palette analysis')
const analysis = analyzePalette(house, profile)
const byName = new Map<string, PaletteAnalysisItem>()
for (const a of analysis) byName.set(a.key, a)

function itemOf(key: string): PaletteAnalysisItem | undefined {
  return byName.get(stateKey(parseStateKey(key)))
}
function expect(
  key: string,
  status: PaletteAnalysisItem['status'],
  target?: { id: number; meta: number },
) {
  const it = itemOf(key)
  ok(!!it, `palette entry "${key}" exists`, [...byName.keys()])
  if (!it) return
  ok(it.status === status, `${key} status=${status}`, it.status)
  if (target) {
    ok(
      it.target?.id === target.id && it.target?.meta === target.meta,
      `${key} -> ${target.id}:${target.meta}`,
      it.target,
    )
  }
  console.log(`  ${it.status.padEnd(9)} ${it.key}  ->  ${it.targetLabel ?? '???'}  (${it.count}x)  ${it.reason ?? ''}`)
}

// vanilla auto mappings incl. rotations
expect('minecraft:stone', 'auto', { id: 1, meta: 0 })
expect('minecraft:cobblestone', 'auto', { id: 4, meta: 0 })
expect('minecraft:oak_planks', 'auto', { id: 5, meta: 0 })
expect('minecraft:glass', 'auto', { id: 20, meta: 0 })
expect('minecraft:glass_pane', 'auto', { id: 102, meta: 0 }) // side props are connection state
expect('minecraft:oak_log[axis=y]', 'auto', { id: 17, meta: 0 })
expect('minecraft:oak_log[axis=x]', 'auto', { id: 17, meta: 4 })
expect('minecraft:oak_log[axis=z]', 'auto', { id: 17, meta: 8 })
expect('minecraft:oak_stairs[facing=south,half=bottom,shape=straight]', 'auto', { id: 53, meta: 2 })
expect('minecraft:oak_stairs[facing=east,half=top,shape=straight]', 'auto', { id: 53, meta: 4 })
expect('minecraft:oak_slab[type=bottom]', 'auto', { id: 126, meta: 0 })
expect('minecraft:oak_slab[type=top]', 'auto', { id: 126, meta: 8 })
expect('minecraft:chest[facing=north,type=single]', 'auto', { id: 54, meta: 2 })
expect('minecraft:torch', 'auto', { id: 50, meta: 5 })
expect('minecraft:wall_torch[facing=east]', 'auto', { id: 50, meta: 1 })
expect('minecraft:short_grass', 'auto', { id: 31, meta: 1 })
// litemapy normalizes water[level=0] to a prop-less "minecraft:water"
expect('minecraft:water', 'approx', { id: 9, meta: 0 }) // level dropped

// doors: lower meta < 8, upper meta >= 8, same facing bits
const doorLower = itemOf('minecraft:oak_door[facing=south,half=lower,hinge=left,open=false,powered=false]')
ok(!!doorLower && doorLower.target && doorLower.target.id === 64, 'door lower id 64', doorLower?.target)
ok(!!doorLower && doorLower.target !== null && doorLower.target.meta < 8, 'door lower meta < 8', doorLower?.target)
ok(!!doorLower && doorLower.target !== null && doorLower.target.meta === 1, 'door lower meta 1 (south, closed)', doorLower?.target)
const doorUpper = itemOf('minecraft:oak_door[facing=south,half=upper,hinge=left,open=false,powered=false]')
ok(!!doorUpper && doorUpper.target !== null && doorUpper.target.meta === 9, 'door upper meta 9 (8+south, hinge left)', doorUpper?.target)

// suggestions for post-1.7.10 blocks
expect('minecraft:white_concrete', 'suggest', { id: 159, meta: 0 })
expect('minecraft:light_blue_concrete', 'suggest', { id: 159, meta: 3 })
expect('minecraft:cut_copper', 'suggest', { id: 41, meta: 0 })
expect('minecraft:deepslate', 'suggest', { id: 1, meta: 0 })
expect('minecraft:polished_granite', 'suggest', { id: 1, meta: 0 })
expect('minecraft:sea_lantern', 'suggest', { id: 89, meta: 0 })

// modded
expect('chisel:marble', 'modmeta', { id: 176, meta: 0 })
expect('gregtech:gt.blockmachines', 'modmeta', { id: 190, meta: 0 })
expect('gregtech:gt.blockmultiblockcasing', 'modmeta', { id: 1515, meta: 0 })
expect('twerk:warp_drive', 'manual') // not in the pack -> needs a user decision

/* ------------------------------------------------------------------ */
section('4. convert with decisions (twerk -> obsidian)')
const decisions: Record<string, Decision> = {
  'twerk:warp_drive': { kind: 'target', id: 49, meta: 0 },
}
const conv = convertSchematic(house, analysis, decisions)
ok(conv.unresolved.length === 0, 'no unresolved blocks', conv.unresolved)
ok(conv.totalBlocks === 469, 'material total = 469', conv.totalBlocks)
writeFileSync(join(OUT, 'test_house.schematic'), conv.file)
console.log(`  materials (${conv.materials.length} rows):`)

let matSum = 0
for (const m of conv.materials) {
  matSum += m.count
  console.log(`    ${String(m.id).padStart(5)}:${String(m.meta).padEnd(2)} ${m.label.padEnd(38)} ${m.count}`)
}
ok(matSum === 469, 'sum of materials = totalBlocks', matSum)

/* ------------------------------------------------------------------ */
section('5. re-parse the produced legacy .schematic')
const legacyRaw = new Uint8Array(readFileSync(join(OUT, 'test_house.schematic')))
const legacySch = parseLegacySchematic(legacyRaw)
ok(legacySch.format === 'legacy', 'format legacy', legacySch.format)
ok(legacySch.width === 14 && legacySch.height === 9 && legacySch.length === 14, 'dims preserved', [
  legacySch.width, legacySch.height, legacySch.length,
])

function cell(sch: UnifiedSchematic, x: number, y: number, z: number) {
  const p = sch.indices[cellIndex(sch, x, y, z)]
  return sch.format === 'legacy' ? sch.legacyPalette[p] : null
}
function expectCell(label: string, x: number, y: number, z: number, id: number, meta: number) {
  const c = cell(legacySch, x, y, z)
  ok(c?.id === id && c?.meta === meta, `${label} @(${x},${y},${z}) = ${id}:${meta}`, c)
}

// structural + rotation-critical cells
expectCell('stone floor', 0, 0, 5, 1, 0)
expectCell('planks floor', 5, 0, 5, 5, 0)
expectCell('log axis=y (corner)', 2, 1, 2, 17, 0)
expectCell('log axis=x (beam)', 6, 4, 6, 17, 4)
expectCell('log axis=z (beam)', 4, 4, 4, 17, 8)
expectCell('cobble wall', 3, 1, 2, 4, 0)
expectCell('glass window', 4, 2, 2, 20, 0)
expectCell('glass pane', 7, 2, 2, 102, 0)
expectCell('stairs south bottom', 5, 1, 3, 53, 2)
expectCell('stairs east top', 7, 3, 3, 53, 4)
expectCell('slab bottom', 3, 1, 9, 126, 0)
expectCell('slab top (roof edge)', 3, 5, 11, 126, 8)
expectCell('chest facing north', 4, 1, 4, 54, 2)
expectCell('torch standing', 5, 1, 5, 50, 5)
expectCell('wall torch east', 3, 2, 6, 50, 1)
expectCell('water pool', 12, 0, 12, 9, 0)
expectCell('short grass', 1, 1, 3, 31, 1)
expectCell('white concrete -> clay', 11, 1, 4, 159, 0)
expectCell('light_blue concrete -> clay', 11, 2, 4, 159, 3)
expectCell('cut copper -> gold', 11, 3, 4, 41, 0)
expectCell('deepslate -> stone', 13, 1, 0, 1, 0)
expectCell('polished granite -> stone', 0, 1, 13, 1, 0)
expectCell('sea lantern -> glowstone', 6, 5, 6, 89, 0)
expectCell('chisel marble (modded)', 6, 0, 6, 176, 0)
expectCell('GT machine (modded)', 9, 1, 9, 190, 0)
expectCell('GT casing >255 (AddBlocks!)', 7, 0, 7, 1515, 0)
expectCell('t warp_drive -> obsidian', 7, 3, 7, 49, 0)
const dLow = cell(legacySch, 6, 1, 2)
const dUp = cell(legacySch, 6, 2, 2)
ok(dLow?.id === 64 && (dLow.meta & 3) === (dUp!.meta & 3) && (dLow.meta & 7) < 8 && (dUp!.meta & 8) === 8,
  'door lower/upper facing+hinge bits', { dLow, dUp })

/* ------------------------------------------------------------------ */
section('6. multiregion + negative size litematic')
const multiRaw = new Uint8Array(readFileSync(join(FIX, 'test_multiregion.litematic')))
const multiParsed = detectAndParse(multiRaw, 'test_multiregion.litematic')
ok(multiParsed.ok, 'parse ok', multiParsed.ok ? undefined : multiParsed.error)
if (multiParsed.ok) {
  const m = multiParsed.sch
  ok(m.regionCount === 2, 'region count 2', m.regionCount)
  ok(m.width === 10 && m.height === 4 && m.length === 6, 'dims 10x4x6', [m.width, m.height, m.length])
  ok(m.totalBlocks === 117, 'total blocks 117', m.totalBlocks)

  // cell-level parse checks BEFORE conversion (palette states)
  const sMarble = stateKey(parseStateKey('chisel:marble'))
  const sBirch = stateKey(parseStateKey('minecraft:stripped_birch_log[axis=z]'))
  function mcell(x: number, y: number, z: number) {
    const p = m.indices[cellIndex(m, x, y, z)]
    return stateKey(m.palette[p])
  }
  ok(mcell(2, 0, 2) === stateKey(parseStateKey('minecraft:oak_planks')), 'main planks', mcell(2, 0, 2))
  ok(mcell(0, 1, 0) === stateKey(parseStateKey('minecraft:cobblestone')), 'main cobble', mcell(0, 1, 0))
  // negative-size region: annex pos 9 size -4 occupies schematic x 6..9
  ok(mcell(6, 0, 0) === stateKey(parseStateKey('minecraft:polished_diorite')), 'annex floor at x=6', mcell(6, 0, 0))
  ok(mcell(9, 0, 0) === stateKey(parseStateKey('minecraft:polished_diorite')), 'annex floor at x=9', mcell(9, 0, 0))
  ok(mcell(6, 1, 0) === sMarble, 'annex marble wall at x=6', mcell(6, 1, 0))
  ok(mcell(9, 1, 0) === sMarble, 'annex marble wall at x=9', mcell(9, 1, 0))
  ok(mcell(7, 1, 1) === sBirch, 'stripped birch log at x=7 (negative-size flip)', mcell(7, 1, 1))

  // full convert of the multiregion fixture
  const manalysis = analyzePalette(m, profile)
  const mdecisions: Record<string, Decision> = {} // everything has a default target here
  const mconv = convertSchematic(m, manalysis, mdecisions)
  ok(mconv.unresolved.length === 0, 'no unresolved', mconv.unresolved)
  writeFileSync(join(OUT, 'test_multiregion.schematic'), mconv.file)
  const mlegacy = parseLegacySchematic(new Uint8Array(mconv.file))
  function mc(x: number, y: number, z: number) {
    const p = mlegacy.indices[cellIndex(mlegacy, x, y, z)]
    return mlegacy.legacyPalette[p]
  }
  ok(mc(7, 1, 1)?.id === 17 && mc(7, 1, 1)?.meta === 10, 'stripped birch [axis=z] -> 17:10 (birch+z)', mc(7, 1, 1))
  ok(mc(6, 1, 0)?.id === 176, 'marble -> 176 in legacy out', mc(6, 1, 0))
  ok(mc(6, 0, 0)?.id === 1, 'diorite -> stone', mc(6, 0, 0))
  console.log('  multiregion conversion OK ->', mconv.totalBlocks, 'blocks')
}

/* ------------------------------------------------------------------ */
section('7. sponge .schem parse + convert')
const spongeRaw = new Uint8Array(readFileSync(join(FIX, 'test_house.schem')))
const spongeParsed = detectAndParse(spongeRaw, 'test_house.schem')
ok(spongeParsed.ok, 'parse ok', spongeParsed.ok ? undefined : spongeParsed.error)
if (spongeParsed.ok) {
  const s = spongeParsed.sch
  ok(s.format === 'sponge', 'format sponge', s.format)
  ok(s.width === 14 && s.height === 9 && s.length === 14, 'dims', [s.width, s.height, s.length])
  ok(s.totalBlocks === 469, 'total blocks', s.totalBlocks)
  const sanalysis = analyzePalette(s, profile)
  const sconv = convertSchematic(s, sanalysis, decisions)
  ok(sconv.unresolved.length === 0, 'no unresolved', sconv.unresolved)
  writeFileSync(join(OUT, 'test_house_from_sponge.schematic'), sconv.file)
  const slegacy = parseLegacySchematic(new Uint8Array(sconv.file))
  function sc(x: number, y: number, z: number) {
    const p = slegacy.indices[cellIndex(slegacy, x, y, z)]
    return slegacy.legacyPalette[p]
  }
  ok(sc(6, 4, 6)?.id === 17 && sc(6, 4, 6)?.meta === 4, 'sponge log axis=x -> 17:4', sc(6, 4, 6))
  ok(sc(11, 2, 4)?.id === 159 && sc(11, 2, 4)?.meta === 3, 'sponge concrete -> 159:3', sc(11, 2, 4))
  ok(sc(7, 0, 7)?.id === 1515, 'sponge GT casing AddBlocks', sc(7, 0, 7))
  console.log('  sponge conversion OK')
}

/* ------------------------------------------------------------------ */
section('8. legacy input passthrough (round-trip)')
const legacyIn = parseLegacySchematic(legacyRaw)
const lanalysis = analyzePalette(legacyIn, profile)
const lconv = convertSchematic(legacyIn, lanalysis, {})
ok(lconv.unresolved.length === 0, 'legacy passthrough no unresolved', lconv.unresolved)
const l2 = parseLegacySchematic(new Uint8Array(lconv.file))
ok(l2.width === 14 && l2.height === 9 && l2.length === 14, 'legacy->legacy dims')
ok(l2.totalBlocks === 469, 'legacy->legacy total blocks', l2.totalBlocks)
function lc(x: number, y: number, z: number) {
  const p = l2.indices[cellIndex(l2, x, y, z)]
  return l2.legacyPalette[p]
}
ok(lc(7, 0, 7)?.id === 1515, 'legacy->legacy GT casing id', lc(7, 0, 7))
ok(lc(6, 4, 6)?.id === 17 && lc(6, 4, 6)?.meta === 4, 'legacy->legacy log rotation', lc(6, 4, 6))
console.log('  legacy passthrough OK')

/* ------------------------------------------------------------------ */
console.log(`\n${checks} checks, ${failures} failures`)
if (failures > 0) {
  console.error('\n!!! E2E FAILED')
  process.exit(1)
}
console.log('E2E PASSED')
