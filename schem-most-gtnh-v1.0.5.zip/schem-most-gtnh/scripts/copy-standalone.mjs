// Кросс-платформенная замена `cp -r` (Windows не знает cp).
// Копирует статику и public внутрь standalone-сборки Next.js,
// чтобы .next/standalone/server.js можно было запускять напрямую.
import { cpSync, existsSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

const root = process.cwd()
const standalone = join(root, '.next', 'standalone')

if (!existsSync(standalone)) {
  console.error('Нет .next/standalone — сначала выполни `next build`')
  process.exit(1)
}

const staticSrc = join(root, '.next', 'static')
const staticDst = join(standalone, '.next', 'static')
mkdirSync(staticDst, { recursive: true })
cpSync(staticSrc, staticDst, { recursive: true })

const publicSrc = join(root, 'public')
const publicDst = join(standalone, 'public')
if (existsSync(publicSrc)) {
  cpSync(publicSrc, publicDst, { recursive: true })
}

// база SQLite — чтобы standalone-сервер видел профиль
const dbSrc = join(root, 'prisma', 'custom.db')
if (existsSync(dbSrc)) {
  mkdirSync(join(standalone, 'prisma'), { recursive: true })
  cpSync(dbSrc, join(standalone, 'prisma', 'custom.db'))
}

console.log('Готово: .next/standalone содержит статику, public и базу. Запуск: npm run start')
